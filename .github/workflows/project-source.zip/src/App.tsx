'use client'

import {
  useEffect,
  useMemo,
  useRef,
  useState,
  type CSSProperties,
  type FormEvent,
  type ReactNode,
} from 'react'
import {
  ArrowRightIcon,
  ArrowUpRightIcon,
  CheckIcon,
  ChevronDownIcon,
  CloseIcon,
  GlobeIcon,
  LeafIcon,
  MailIcon,
  MapPinIcon,
  MenuIcon,
  PhoneIcon,
  PrintIcon,
  ThreadIcon,
  UploadIcon,
} from './components/Icons'
import { EditableImage } from './components/EditableImage'
import { MediaFrame } from './components/MediaFrame'
import { Reveal } from './components/Reveal'
import {
  companyData,
  type ActionLink,
  type EnquiryField,
  type GalleryFilter,
  type GalleryProduct,
  type ImageAsset,
} from './data/companyData'

const formatIndex = (index: number) => String(index + 1).padStart(2, '0')

function isPlaceholder(value: string) {
  return value.includes('[') && value.includes(']')
}

function SectionHeader({
  eyebrow,
  heading,
  introduction,
  centered = false,
  eyebrowClass = '',
}: {
  eyebrow: string
  heading: string
  introduction?: string
  centered?: boolean
  eyebrowClass?: string
}) {
  return (
    <Reveal
      className={`section__header ${centered ? 'section__header--center' : ''}`}
    >
      <div>
        <span className={`eyebrow ${eyebrowClass}`}>{eyebrow}</span>
        <h2>{heading}</h2>
      </div>
      {introduction && <p>{introduction}</p>}
    </Reveal>
  )
}

function ActionButton({
  action,
  onPrint,
  className = '',
}: {
  action: ActionLink
  onPrint?: () => void
  className?: string
}) {
  const buttonClass = `button button--${action.variant} ${className}`

  if (action.download && onPrint) {
    return (
      <button type="button" className={buttonClass} onClick={onPrint}>
        {action.label}
        <PrintIcon />
      </button>
    )
  }

  const href =
    action.download || isPlaceholder(action.href)
      ? '/company-profile'
      : action.href

  return (
    <a className={buttonClass} href={href}>
      {action.label}
      {action.download ? <PrintIcon /> : <ArrowUpRightIcon />}
    </a>
  )
}

function PlaceholderValue({ value }: { value: string }) {
  return (
    <span className={isPlaceholder(value) ? 'placeholder-value' : undefined}>
      {value}
    </span>
  )
}

function ContactDetailValue({
  label,
  value,
}: {
  label: string
  value: string
}) {
  const normalisedLabel = label.toLowerCase()
  const cleanPhone = value.replace(/[^\d+]/g, '')

  if (normalisedLabel.includes('email')) {
    return (
      <a
        className="contact-link"
        href={`mailto:${companyData.enquiry.emailTo}`}
        aria-label={`Email ESHA Apparels at ${companyData.enquiry.emailTo}`}
      >
        <PlaceholderValue value={value} />
      </a>
    )
  }

  if (normalisedLabel.includes('whatsapp') && !isPlaceholder(value)) {
    return (
      <a
        className="contact-link"
        href={`https://wa.me/${cleanPhone.replace('+', '')}`}
        target="_blank"
        rel="noreferrer"
        aria-label={`Open WhatsApp chat with ESHA Apparels at ${value}`}
      >
        <PlaceholderValue value={value} />
      </a>
    )
  }

  if (normalisedLabel.includes('phone') && !isPlaceholder(value)) {
    return (
      <a
        className="contact-link"
        href={`tel:${cleanPhone}`}
        aria-label={`Call ESHA Apparels at ${value}`}
      >
        <PlaceholderValue value={value} />
      </a>
    )
  }

  return <PlaceholderValue value={value} />
}

type ConciergeOption = {
  label: string
  detail?: string
  next?: string
  href?: string
  tone?: 'primary'
}

type ConciergeStep = {
  eyebrow: string
  message: string
  helper?: string
  options: readonly ConciergeOption[]
}

const conciergeSteps: Record<string, ConciergeStep> = {
  start: {
    eyebrow: 'ESHA Concierge',
    message: 'What are you looking for?',
    helper: 'Choose a path. I’ll take you to the exact section.',
    options: [
      {
        label: 'Compare',
        detail: 'Fast buyer review',
        next: 'comparison',
      },
      {
        label: 'Products',
        detail: 'Categories + gallery',
        next: 'products',
      },
      {
        label: 'Factories',
        detail: 'Capacity + setup',
        next: 'capacity',
      },
      {
        label: 'Quality',
        detail: 'QC + compliance',
        next: 'quality',
      },
      {
        label: 'Export',
        detail: 'Markets + buyers',
        next: 'export',
      },
      {
        label: 'Enquiry',
        detail: 'Send requirements',
        href: '/contact#contact',
        tone: 'primary',
      },
    ],
  },
  comparison: {
    eyebrow: 'Buyer review',
    message: 'Jump to the proof buyers usually check first.',
    helper: 'Capacity, product fit, quality and recognition — no long browsing needed.',
    options: [
      {
        label: 'Company snapshot',
        detail: 'Numbers and positioning',
        href: '/#snapshot',
      },
      {
        label: 'Buyer decision flow',
        detail: 'Best-fit sourcing path',
        href: '/#buyer-decision-flow',
      },
      {
        label: 'Factory setup',
        detail: 'Two facilities and scale',
        href: '/facilities#factories',
      },
      {
        label: 'Quality system',
        detail: 'QC checkpoints',
        href: '/quality-compliance#quality',
      },
      {
        label: 'Award proof',
        detail: 'Reliance recognition',
        href: '/awards#awards',
      },
      {
        label: 'Send enquiry',
        detail: 'Share quantity + category',
        href: '/contact#contact',
        tone: 'primary',
      },
    ],
  },
  capacity: {
    eyebrow: 'Production scale',
    message: '2 factories · 575 machines · up to 250,000 pcs/month.',
    helper: 'Capacity depends on style mix, fabric, workmanship and planning.',
    options: [
      {
        label: 'Open facilities',
        detail: 'Factory details',
        href: '/facilities#factories',
        tone: 'primary',
      },
      {
        label: 'Production process',
        detail: 'Factory workflow',
        href: '/facilities#process',
      },
      {
        label: 'Ask production',
        detail: 'Send requirement',
        href: '/contact#contact',
      },
    ],
  },
  products: {
    eyebrow: 'Product direction',
    message: 'Where should we take you?',
    helper:
      'Commercial women’s western wear, fast-fashion and export-ready woven styles.',
    options: [
      {
        label: 'Categories',
        detail: 'Dresses, tops, co-ords',
        href: '/products#products',
        tone: 'primary',
      },
      {
        label: 'Selected gallery',
        detail: 'Style examples',
        href: '/products#gallery',
      },
      {
        label: 'Fabrics',
        detail: 'Materials + value-adds',
        href: '/products#materials',
      },
      {
        label: 'Enquire style',
        detail: 'Share product brief',
        href: '/contact#contact',
      },
    ],
  },
  quality: {
    eyebrow: 'Buyer assurance',
    message: 'Quality, compliance and responsible manufacturing.',
    helper: 'Choose the evidence area you want to review.',
    options: [
      {
        label: 'Quality system',
        detail: 'QC process',
        href: '/quality-compliance#quality',
        tone: 'primary',
      },
      {
        label: 'Compliance',
        detail: 'Audit readiness',
        href: '/quality-compliance#compliance',
      },
      {
        label: 'Sustainability',
        detail: 'Responsible practices',
        href: '/sustainability#sustainability',
      },
      {
        label: 'Ask for documents',
        detail: 'Contact team',
        href: '/contact#contact',
      },
    ],
  },
  export: {
    eyebrow: 'Export route',
    message: 'Review markets, buyers and export support.',
    helper: 'Jump to the map or supporting market details.',
    options: [
      {
        label: 'Export map',
        detail: 'Global network',
        href: '/export#export-network',
        tone: 'primary',
      },
      {
        label: 'Market support',
        detail: 'Buyer services',
        href: '/export#market-experience',
      },
      {
        label: 'Award proof',
        detail: 'Reliance award',
        href: '/awards#awards',
      },
      {
        label: 'Contact team',
        detail: 'Begin enquiry',
        href: '/contact#contact',
      },
    ],
  },
}

function GuidedConcierge() {
  const [open, setOpen] = useState(false)
  const [stepId, setStepId] = useState('start')
  const [history, setHistory] = useState<string[]>([])
  const step = conciergeSteps[stepId] ?? conciergeSteps.start

  const goToStep = (nextStep: string) => {
    if (!conciergeSteps[nextStep]) return
    setHistory((items) => [...items, stepId])
    setStepId(nextStep)
  }

  const goBack = () => {
    setHistory((items) => {
      const previous = items[items.length - 1]
      if (previous) setStepId(previous)
      return items.slice(0, -1)
    })
  }

  const restart = () => {
    setStepId('start')
    setHistory([])
  }

  return (
    <aside
      className={`concierge ${open ? 'is-open' : ''}`}
      data-concierge
      data-concierge-current={stepId}
    >
      <button
        className="concierge-trigger"
        type="button"
        aria-label="Open ESHA help concierge"
        aria-expanded={open}
        aria-controls="esha-concierge-panel"
        data-concierge-trigger
        onClick={() => setOpen(true)}
      >
        <span className="concierge-trigger__mark" aria-hidden="true">
          <img src="/images/hero/esha-apparels-brand-mark.png" alt="" loading="lazy" />
        </span>
        <span className="concierge-trigger__text">Help</span>
      </button>

      <section
        className="concierge-panel"
        id="esha-concierge-panel"
        aria-label="ESHA buyer help"
        aria-hidden={!open}
      >
        <div className="concierge-panel__top">
          <div>
            <span className="concierge-panel__eyebrow" data-concierge-eyebrow>
              {step.eyebrow}
            </span>
            <strong>Find your path</strong>
          </div>
          <button
            className="concierge-panel__close"
            type="button"
            aria-label="Close help concierge"
            data-concierge-close
            onClick={() => setOpen(false)}
          >
            <CloseIcon />
          </button>
        </div>

        <div className="concierge-panel__body">
          <p className="concierge-panel__message" data-concierge-message>
            {step.message}
          </p>
          {step.helper && (
            <p className="concierge-panel__helper" data-concierge-helper>
              {step.helper}
            </p>
          )}
          <div className="concierge-options" data-concierge-options>
            {step.options.map((option) => {
              const className = `concierge-option ${
                option.tone === 'primary' ? 'concierge-option--primary' : ''
              }`
              const content = (
                <>
                  <span>
                    <strong>{option.label}</strong>
                    {option.detail && <small>{option.detail}</small>}
                  </span>
                  <ArrowRightIcon />
                </>
              )

              if (option.href) {
                return (
                  <a key={option.label} className={className} href={option.href}>
                    {content}
                  </a>
                )
              }

              return (
                <button
                  key={option.label}
                  className={className}
                  type="button"
                  data-concierge-next={option.next}
                  onClick={() => option.next && goToStep(option.next)}
                >
                  {content}
                </button>
              )
            })}
          </div>
        </div>

        <div className="concierge-panel__footer">
          <button
            type="button"
            data-concierge-back
            disabled={!history.length}
            onClick={goBack}
          >
            Back
          </button>
          <button type="button" data-concierge-restart onClick={restart}>
            Start over
          </button>
        </div>
      </section>
    </aside>
  )
}

function ImageStrip({
  images,
  className = '',
  label = 'Editable image slot',
}: {
  images: readonly ImageAsset[]
  className?: string
  label?: string
}) {
  return (
    <div className={`image-strip ${className}`}>
      {images.map((image) => (
        <MediaFrame
          key={image.src}
          src={image.src}
          alt={image.alt}
          label={label}
          note={image.recommendedShot}
          sizes="(max-width: 760px) 76vw, 22vw"
        />
      ))}
    </div>
  )
}

function Header({
  scrolled,
  activePath,
  menuOpen,
  setMenuOpen,
  showBuyerEnquiry = true,
}: {
  scrolled: boolean
  activePath: string
  menuOpen: boolean
  setMenuOpen: (open: boolean) => void
  showBuyerEnquiry?: boolean
}) {
  useEffect(() => {
    document.body.classList.toggle('menu-open', menuOpen)
    return () => document.body.classList.remove('menu-open')
  }, [menuOpen])

  return (
    <header
      className={`site-nav ${scrolled ? 'is-scrolled' : ''} ${
        menuOpen ? 'is-open' : ''
      }`}
    >
      <div className="site-nav__inner container">
        <a className="brand" href="/" onClick={() => setMenuOpen(false)}>
          <span className="brand__name">{companyData.brand.name}</span>
          <span className="brand__descriptor">Garment manufacturing & export</span>
        </a>

        <nav
          className={`site-nav__links ${menuOpen ? 'is-open' : ''}`}
          aria-label="Primary navigation"
        >
          {companyData.navigation.map((item) => {
            return (
              <a
                key={item.href}
                className={activePath === item.href ? 'is-active' : ''}
                href={item.href}
                onClick={() => setMenuOpen(false)}
              >
                {item.label}
              </a>
            )
          })}
        </nav>

        <div className="site-nav__actions">
          <div
            className="language-switch"
            role="group"
            aria-label="Language switcher"
          >
            <button
              className="language-switch__button is-active"
              type="button"
              data-lang-option="en"
              aria-pressed="true"
            >
              EN
            </button>
            <button
              className="language-switch__button"
              type="button"
              data-lang-option="ja"
              aria-pressed="false"
            >
              日本語
            </button>
          </div>
          <a
            className="button button--secondary site-nav__download"
            href="/company-profile"
          >
            <span>Download Profile</span>
            <PrintIcon />
          </a>
          {showBuyerEnquiry && (
            <a className="button button--primary site-nav__cta" href="/contact">
              Buyer Enquiry
            </a>
          )}
          <button
            className="nav-toggle"
            type="button"
            aria-label={menuOpen ? 'Close navigation menu' : 'Open navigation menu'}
            aria-expanded={menuOpen}
            onClick={() => setMenuOpen(!menuOpen)}
          >
            {menuOpen ? <CloseIcon /> : <MenuIcon />}
          </button>
        </div>
      </div>
    </header>
  )
}

type ProfileShellProps = {
  activePath: string
  pageTitle: string
  children: ReactNode
  className?: string
  showFooter?: boolean
  showBuyerEnquiry?: boolean
}

export function ProfileShell({
  activePath,
  pageTitle,
  children,
  className = '',
  showFooter = true,
  showBuyerEnquiry = true,
}: ProfileShellProps) {
  const [scrolled, setScrolled] = useState(false)
  const [menuOpen, setMenuOpen] = useState(false)

  useEffect(() => {
    document.title = `${pageTitle} | ESHA Apparels`
  }, [pageTitle])

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24)
    onScroll()
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  return (
    <>
      <a className="skip-link" href="#main-content">
        Skip to main content
      </a>
      <Header
        scrolled={scrolled}
        activePath={activePath}
        menuOpen={menuOpen}
        setMenuOpen={setMenuOpen}
        showBuyerEnquiry={showBuyerEnquiry}
      />
      <div className={`site-shell ${className}`}>
        <main className="page-transition" id="main-content">
          {children}
        </main>
        {showFooter && <Footer />}
      </div>
      <GuidedConcierge />
    </>
  )
}

export function PageHeader({
  eyebrow,
  title,
  introduction,
  current,
}: {
  eyebrow: string
  title: string
  introduction: string
  image: ImageAsset
  current: string
}) {
  return (
    <section className="page-header" aria-labelledby="page-title">
      <div className="container page-header__content">
        <nav className="breadcrumbs" aria-label="Breadcrumb">
          <a href="/">Home</a>
          <span aria-hidden="true">/</span>
          <span aria-current="page">{current}</span>
        </nav>
        <span className="eyebrow eyebrow--light">{eyebrow}</span>
        <h1 id="page-title">{title}</h1>
        <p>{introduction}</p>
      </div>
    </section>
  )
}

export function HeroSection({ showActions = true }: { showActions?: boolean }) {
  const [lead, accent] = companyData.hero.title.split(' Manufacturing')

  return (
    <section
      className="hero"
      id="home"
      aria-label="Cover — Women’s Fashion Manufacturing at Scale"
    >
      <div className="hero__content">
        <div className="hero__copy-column">
          <div className="hero__topline">
            <span className="eyebrow eyebrow--light">{companyData.hero.eyebrow}</span>
          </div>

          <h1>
            {lead}
            {accent && (
              <>
                {' '}
                <span className="hero__headline-accent">
                  Manufacturing{accent}
                </span>
              </>
            )}
          </h1>

          <div className="hero__intro">
            <div>
              <p className="hero__copy">{companyData.hero.statement}</p>
              {showActions && (
                <div className="hero__actions">
                  {companyData.hero.actions.map((action) => (
                    <ActionButton key={action.label} action={action} />
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="hero__visual-column">
          <img
            className="hero__brand-mark"
            src="/images/hero/esha-apparels-brand-mark.png"
            alt="ESHA Apparels logo"
            loading="eager"
            decoding="async"
          />
        </div>
      </div>

      <a className="hero__scroll" href="/about">
        Explore the company
        <ChevronDownIcon />
      </a>
    </section>
  )
}

export function CompanyIntroduction({
  showEyebrow = true,
}: {
  showEyebrow?: boolean
}) {
  const { introduction } = companyData
  return (
    <section
      className="section section--ivory"
      id="about"
      aria-label="About ESHA Apparels"
    >
      <div className="container intro-grid">
        <Reveal className="intro-copy">
          {showEyebrow && (
            <span className="eyebrow">{introduction.eyebrow}</span>
          )}
          <h2>{introduction.heading}</h2>
          <p className="lead">{introduction.paragraphs[0]}</p>
          <p>{introduction.paragraphs[1]}</p>
          <div className="intro-services">
            {introduction.buyerSupport.map((service) => (
              <span key={service}>{service}</span>
            ))}
          </div>
        </Reveal>

        <Reveal className="intro-visuals" delay={120}>
          <MediaFrame
            className="intro-media"
            src={introduction.images[0].src}
            alt={introduction.images[0].alt}
            label="Company / team image"
            note={introduction.images[0].recommendedShot}
            sizes="(max-width: 760px) 100vw, 52vw"
          />
        </Reveal>
      </div>
    </section>
  )
}

export function PastPresentFutureSection() {
  const { aboutJourney } = companyData

  return (
    <section
      className="section about-journey-section"
      aria-label="ESHA Apparels past, present and future"
    >
      <div className="container">
        <SectionHeader
          eyebrow={aboutJourney.eyebrow}
          heading={aboutJourney.heading}
          introduction={aboutJourney.introduction}
        />
        <div className="about-journey-grid">
          {aboutJourney.items.map((item, index) => (
            <Reveal key={item.id} delay={index * 90}>
              <article className={`about-journey-card about-journey-card--${item.id}`}>
                <span className="about-journey-card__label">{item.label}</span>
                <h3>{item.title}</h3>
                <p>{item.text}</p>
                <ul>
                  {item.highlights.map((highlight) => (
                    <li key={highlight}>{highlight}</li>
                  ))}
                </ul>
              </article>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  )
}

export function ClientAssociationsSection() {
  const { clientAssociations } = companyData

  return (
    <section
      className="section client-associations-section"
      aria-label="Companies ESHA Apparels works with"
    >
      <div className="container">
        <SectionHeader
          eyebrow={clientAssociations.eyebrow}
          heading={clientAssociations.heading}
          introduction={clientAssociations.introduction}
        />
        <div className="client-association-grid">
          {clientAssociations.groups.map((group, index) => (
            <Reveal key={group.id} delay={index * 100}>
              <article className="client-association-panel">
                <div className="client-association-panel__header">
                  <span>{group.title}</span>
                  <p>{group.description}</p>
                </div>
                {group.logos.length > 0 ? (
                  <div className="client-logo-marquee" aria-label={group.title}>
                    <div className="client-logo-track">
                      {[...group.logos, ...group.logos].map((client, logoIndex) => (
                        <figure
                          className="client-logo-card"
                          key={`${client.id}-${logoIndex}`}
                          aria-hidden={logoIndex >= group.logos.length}
                        >
                          <img src={client.logo.src} alt={client.logo.alt} />
                          <figcaption>
                            <span>{client.name}</span>
                            {client.note && <small>{client.note}</small>}
                          </figcaption>
                        </figure>
                      ))}
                    </div>
                  </div>
                ) : (
                  <div className="client-logo-empty">
                    <span>{group.emptyState}</span>
                  </div>
                )}
              </article>
            </Reveal>
          ))}
        </div>
        <p className="client-associations-disclaimer">
          {clientAssociations.disclaimer}
        </p>
      </div>
    </section>
  )
}

export function StatisticStrip() {
  return (
    <section
      id="snapshot"
      className="section stat-section"
      aria-label="ESHA Apparels at a glance"
    >
      <div className="container">
        <Reveal className="stat-section__intro">
          <h2>{companyData.atAGlance.heading}</h2>
          <span className="placeholder-badge">Confirmed commercial snapshot</span>
        </Reveal>
        <div className="stat-grid">
          {companyData.atAGlance.statistics.map((stat, index) => (
            <Reveal key={stat.id} delay={(index % 3) * 70}>
              <article className="stat-card">
                <strong className="stat-card__value">{stat.value}</strong>
                <span className="stat-card__label">{stat.label}</span>
              </article>
            </Reveal>
          ))}
        </div>
        <p className="disclaimer">{companyData.atAGlance.disclaimer}</p>
      </div>
    </section>
  )
}

export function BuyerDecisionFlowSection() {
  const { buyerDecisionFlow } = companyData

  return (
    <section
      id="buyer-decision-flow"
      className="section buyer-decision-section"
      aria-label="Buyer decision flow"
    >
      <div className="container">
        <SectionHeader
          eyebrow={buyerDecisionFlow.eyebrow}
          heading={buyerDecisionFlow.heading}
          introduction={buyerDecisionFlow.introduction}
        />
        <div className="buyer-decision-layout">
          <Reveal className="buyer-decision-summary">
            <span className="buyer-decision-summary__kicker">30-second review</span>
            <h3>From product fit to first brief.</h3>
            <p>
              Use this quick buyer route to confirm whether ESHA Apparels fits the
              category, price, scale and execution profile required for your programme.
            </p>
            <a href="/contact#contact">
              Begin enquiry
              <ArrowUpRightIcon />
            </a>
          </Reveal>
          <div className="buyer-decision-steps">
            {buyerDecisionFlow.steps.map((step, index) => (
              <Reveal key={step.id} delay={(index % 3) * 70}>
                <article className="buyer-decision-card">
                  <div className="buyer-decision-card__top">
                    <span className="buyer-decision-card__number">
                      {formatIndex(index)}
                    </span>
                    <span className="buyer-decision-card__label">{step.label}</span>
                  </div>
                  <h3>{step.title}</h3>
                  <p>{step.description}</p>
                  <a href={step.href}>
                    {step.cta}
                    <ArrowRightIcon />
                  </a>
                </article>
              </Reveal>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}

const factoryCinemagraphScenes = [
  {
    number: '01',
    title: 'Needle Rhythm',
    description:
      'Needle, presser foot and thread move in a measured cadence while the machine remains perfectly composed.',
  },
  {
    number: '02',
    title: 'Fabric & Stitch',
    description:
      'Premium cloth advances almost imperceptibly as precise stitches form one by one.',
  },
  {
    number: '03',
    title: 'Hand & Material',
    description:
      'Fingertips gently settle the fabric, allowing the material to relax naturally.',
  },
  {
    number: '04',
    title: 'Embroidery Detail',
    description:
      'Thread builds restrained surface detail through controlled, repeatable movement.',
  },
  {
    number: '05',
    title: 'Quality Light',
    description:
      'A soft inspection light reveals texture, stitching, buttons, lace and construction.',
  },
  {
    number: '06',
    title: 'Considered Packing',
    description:
      'A folded garment, ribbon and shipment tag settle into their final presentation.',
  },
  {
    number: '07',
    title: 'Finished Form',
    description:
      'The completed garment rests in quiet suspension with only natural fabric movement.',
  },
] as const

export function FactoryCinemagraph() {
  useEffect(() => {
    if (document.querySelector('[data-factory-cinemagraph-ready="true"]')) return

    const existingScript = document.querySelector<HTMLScriptElement>(
      'script[data-factory-cinemagraph-script]',
    )
    if (existingScript) return

    const script = document.createElement('script')
    script.src = '/scripts/factory-cinemagraph.js'
    script.defer = true
    script.dataset.factoryCinemagraphScript = 'true'
    document.body.appendChild(script)
  }, [])

  return (
    <div
      className="factory-cinemagraph"
      data-factory-cinemagraph-shell
      aria-label="Factory cinemagraph — quiet precision in garment manufacturing"
    >
      <div className="factory-cinemagraph__visual">
        <canvas
          className="factory-cinemagraph__canvas"
          data-factory-cinemagraph
          aria-hidden="true"
        />
        <div className="factory-cinemagraph__fallback" aria-hidden="true">
          <svg viewBox="0 0 1200 680" role="presentation">
            <path
              d="M218 168h428c54 0 98 44 98 98v29H610v-28H392v149H218V168Z"
              fill="#353636"
            />
            <circle cx="685" cy="210" r="61" fill="#242525" stroke="#77736d" />
            <path d="M610 291v155M579 446h62" stroke="#ddd4cb" strokeWidth="9" />
            <path d="M602 291v170" stroke="#a4917f" strokeWidth="2" />
            <path d="M114 463h972v116H114z" fill="#9b8573" />
            <path
              d="M114 486c204-22 385 19 573-1 136-15 253-10 399 4"
              fill="none"
              stroke="#d8ccc0"
              strokeOpacity=".55"
              strokeWidth="3"
            />
          </svg>
        </div>
        <span className="factory-cinemagraph__film-label">
          Factory study · quiet precision
        </span>
      </div>

      <div className="factory-cinemagraph__editorial">
        <span className="eyebrow eyebrow--light">Craftsmanship in motion</span>
        <h3>Quiet Precision</h3>
        <p className="factory-cinemagraph__statement">
          A restrained portrait of the details behind every garment.
        </p>

        <div
          className="factory-cinemagraph__captions"
          aria-label="Cinemagraph scenes"
        >
          {factoryCinemagraphScenes.map((scene, index) => (
            <article
              className={`factory-cinemagraph__scene ${
                index === 0 ? 'is-active' : ''
              }`}
              data-factory-cinemagraph-scene
              aria-hidden={index === 0 ? 'false' : 'true'}
              key={scene.number}
            >
              <span>{scene.number}</span>
              <h4>{scene.title}</h4>
              <p>{scene.description}</p>
            </article>
          ))}
        </div>

        <div className="factory-cinemagraph__progress" aria-hidden="true">
          <span className="factory-cinemagraph__counter">
            <strong data-factory-cinemagraph-counter>01</strong>
            <i />
            07
          </span>
          <div className="factory-cinemagraph__dots">
            {factoryCinemagraphScenes.map((scene, index) => (
              <i
                className={index === 0 ? 'is-active' : ''}
                data-factory-cinemagraph-dot
                key={scene.number}
              />
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}

export function FactorySection() {
  const { factories } = companyData
  return (
    <section
      className="section section--taupe"
      id="factories"
      aria-label="Two manufacturing factories"
    >
      <div className="container">
        <SectionHeader
          eyebrow={factories.eyebrow}
          heading={factories.heading}
          introduction={factories.introduction}
        />

        <FactoryCinemagraph />

        <div className="factory-stack">
          {factories.profiles.map((factory) => (
            <Reveal key={factory.id}>
              <article className="factory-card">
                <MediaFrame
                  className="factory-card__media"
                  src={factory.images[0].src}
                  alt={factory.images[0].alt}
                  label={factory.images[0].recommendedShot}
                  note={`Replace with verified ${factory.name} photography`}
                  sizes="(max-width: 760px) 100vw, 55vw"
                />
                <div className="factory-card__content">
                  <div>
                    <span className="factory-card__number">{factory.number}</span>
                    <h3>{factory.name}</h3>
                    <p className="factory-card__note">{factory.introduction}</p>
                    <dl className="data-list">
                      {factory.details.map((detail) => (
                        <div key={detail.label}>
                          <dt>{detail.label}</dt>
                          <dd>
                            <PlaceholderValue value={detail.value} />
                          </dd>
                        </div>
                      ))}
                    </dl>
                  </div>
                </div>
              </article>
            </Reveal>
          ))}
        </div>

        <div className="factory-compare" aria-label="Two-factory system benefits">
          {factories.comparisonPoints.map((point, index) => (
            <div className="factory-compare__item" key={point}>
              <span>{formatIndex(index)}</span>
              {point}
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

export function ProductCategoryGrid() {
  const { productCategories } = companyData
  return (
    <section
      className="section section--ivory"
      id="products"
      aria-label="Product categories"
    >
      <div className="container">
        <SectionHeader
          eyebrow={productCategories.eyebrow}
          heading={productCategories.heading}
          introduction={productCategories.introduction}
        />
        <div className="category-grid">
          {productCategories.items.map((category, index) => (
            <article className="category-card" key={category.id}>
              <EditableImage
                src={category.image.src}
                alt={category.image.alt}
                storageKey={`category-${category.id}`}
                fit="cover"
                label={`${category.name} image`}
                note={category.image.recommendedShot}
              />
              <div className="category-card__shade" />
              <div className="category-card__content">
                <span className="category-card__index">{formatIndex(index)}</span>
                <h3>{category.name}</h3>
                <div className="category-card__details">
                  <p>{category.description}</p>
                  <span>
                    <strong>Fabric directions</strong>
                    {category.fabrics.join(' · ')}
                  </span>
                  <span>
                    <strong>Customisation</strong>
                    {category.customisation}
                  </span>
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  )
}

export function ManufacturingProcess() {
  const { manufacturingSupport } = companyData
  return (
    <section
      className="section section--white"
      id="capabilities"
      aria-label="End-to-end manufacturing support"
    >
      <div className="container">
        <SectionHeader
          eyebrow={manufacturingSupport.eyebrow}
          heading={manufacturingSupport.heading}
          introduction={manufacturingSupport.introduction}
        />
        <div className="process-list">
          {manufacturingSupport.steps.map((step) => (
            <article className="process-step" key={step.id}>
              <div>
                <h3>{step.title}</h3>
                <p>{step.description}</p>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  )
}

export function DevelopmentSection() {
  const { development } = companyData
  return (
    <section
      className="section section--off-white"
      aria-label="Design and product development"
    >
      <div className="container">
        <SectionHeader
          eyebrow={development.eyebrow}
          heading={development.heading}
          introduction={development.introduction}
        />
        <div className="development-layout">
          <Reveal>
            <div className="capability-list">
              {development.capabilities.map((capability, index) => (
                <div className="capability-item" key={capability.id}>
                  <span>{formatIndex(index)}</span>
                  <span className="sr-only">{capability.description}</span>
                  {capability.title}
                </div>
              ))}
            </div>
          </Reveal>
          <div className="development-collage">
            {development.images.map((image, index) => (
              <Reveal key={image.src} delay={index * 80}>
                <MediaFrame
                  src={image.src}
                  alt={image.alt}
                  label={image.recommendedShot}
                  note="Editable image placeholder"
                  sizes="(max-width: 760px) 84vw, 30vw"
                />
              </Reveal>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}

export function MaterialsSection() {
  const { materials } = companyData
  return (
    <section
      id="materials"
      className="section section--taupe"
      aria-label="Fabrics and value additions"
    >
      <div className="container">
        <SectionHeader
          eyebrow={materials.eyebrow}
          heading={materials.heading}
          introduction={materials.introduction}
        />
        <div className="material-layout">
          <Reveal>
            <MediaFrame
              className="material-media"
              src={materials.images[0].src}
              alt={materials.images[0].alt}
              label="Fabric and trim library"
              note={materials.images[0].recommendedShot}
              sizes="(max-width: 760px) 100vw, 42vw"
            />
          </Reveal>
          <Reveal className="material-groups" delay={100}>
            <div className="material-group">
              <span className="eyebrow">Fabric possibilities</span>
              <h3>Natural, fluid and commercially adaptable bases</h3>
              <div className="material-tags">
                {materials.fabricGroups.map((fabric) => (
                  <span className="tag" key={fabric}>
                    {fabric}
                  </span>
                ))}
              </div>
            </div>
            <div className="material-group">
              <span className="eyebrow">Value additions</span>
              <h3>Details that create visible commercial value</h3>
              <div className="material-tags">
                {materials.valueAdditions.map((value) => (
                  <span className="tag" key={value}>
                    {value}
                  </span>
                ))}
              </div>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  )
}

export function ProductionSection() {
  const { production } = companyData
  return (
    <section
      id="process"
      className="section section--white"
      aria-label="Production capability"
    >
      <div className="container">
        <SectionHeader
          eyebrow={production.eyebrow}
          heading={production.heading}
          introduction={production.introduction}
        />
        <Reveal>
          <MediaFrame
            className="production-visual"
            src={production.images[0].src}
            alt={production.images[0].alt}
            label="Approved sample to dispatch"
            note={production.images[0].recommendedShot}
            sizes="100vw"
          />
        </Reveal>
        <ImageStrip
          images={production.images.slice(1)}
          label="Production stage slot"
        />
        <div className="production-steps">
          {production.steps.map((step) => (
            <article className="production-step" key={step.id}>
              <span>{step.number}</span>
              <h3>{step.title}</h3>
            </article>
          ))}
        </div>
        <div className="operational-data" aria-label="Editable operational data">
          {production.operationalData.map((item) => (
            <div className="operational-data__item" key={item.label}>
              <span>{item.label}</span>
              <strong>
                <PlaceholderValue value={item.value} />
              </strong>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

export function QualitySection() {
  const { quality } = companyData
  return (
    <section
      className="section quality-section"
      id="quality"
      aria-label="Quality-control system"
    >
      <div className="container">
        <Reveal className="quality-section__header">
          <div>
            <span className="eyebrow eyebrow--light">{quality.eyebrow}</span>
            <h2>{quality.heading}</h2>
          </div>
          <p>{quality.introduction}</p>
        </Reveal>
        <div className="quality-process-layout">
          <Reveal className="quality-editorial">
            <blockquote className="quality-quote">
              <p>{quality.statement}</p>
            </blockquote>
          </Reveal>
          <Reveal className="quality-process-panel">
            <figure className="media-frame quality-process-media">
              <img
                className="quality-process-image--contain"
                src={quality.processImage.src}
                alt={quality.processImage.alt}
                sizes="(max-width: 760px) 100vw, 64vw"
                loading="lazy"
                decoding="async"
              />
              <figcaption>Quality-control workflow</figcaption>
            </figure>
          </Reveal>
        </div>
      </div>
    </section>
  )
}

export function ComplianceSection() {
  const { compliance } = companyData
  const complianceItems = compliance.items.filter((item) =>
    [
      'responsible-awareness',
      'workplace-standards',
      'buyer-compliance',
      'traceability',
    ].includes(item.id),
  )
  const complianceFields = compliance.verificationFields.filter((field) =>
    ['Compliance certification', 'Social audit', 'Factory audit status'].includes(
      field.label,
    ),
  )

  return (
    <section
      className="section section--off-white compliance-evidence-section"
      id="compliance"
      aria-label="Compliance evidence and buyer requirements"
    >
      <div className="container">
        <Reveal className="compliance-evidence__header">
          <div>
            <span className="eyebrow">Compliance readiness</span>
            <h2>Buyer Requirements, Supported by Verified Evidence</h2>
          </div>
          <p>
            ESHA Apparels can review buyer-specific workplace, audit and
            documentation requirements against current factory capability. All
            credential fields remain clearly marked until evidence is supplied.
          </p>
        </Reveal>
        <div className="compliance-grid">
          {complianceItems.map((item, index) => (
            <article className="compliance-item" key={item.id}>
              <span className="compliance-item__icon" aria-hidden="true">
                {index % 2 === 0 ? <ThreadIcon /> : <CheckIcon />}
              </span>
              <h3>{item.title}</h3>
              <p>{item.description}</p>
            </article>
          ))}
        </div>
        <div className="verification-panel">
          <div className="verification-panel__intro">
            <span className="placeholder-badge">Verification area</span>
            <h3>Evidence-led compliance profile</h3>
            <p>
              Certification and audit information remains clearly marked until
              documentary verification is supplied.
            </p>
          </div>
          <div className="verification-panel__table-wrap">
            <table className="verification-table">
              <caption className="sr-only">
                Evidence-led compliance profile verification fields
              </caption>
              <thead>
                <tr>
                  <th scope="col">Evidence category</th>
                  <th scope="col">Status / documentation</th>
                </tr>
              </thead>
              <tbody>
                {complianceFields.map((field) => (
                  <tr key={field.label}>
                    <th scope="row">{field.label}</th>
                    <td>
                      <PlaceholderValue value={field.value} />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </section>
  )
}

export function SustainabilitySection() {
  const { compliance } = companyData
  const sustainabilityItems = compliance.items.filter((item) =>
    [
      'material-optimisation',
      'production-efficiency',
      'waste-reduction',
      'sustainable-fabrics',
    ].includes(item.id),
  )
  const sustainabilityFields = compliance.verificationFields.filter((field) =>
    [
      'Environmental certification',
      'Sustainability initiative',
      'Waste management',
      'Renewable energy',
      'Water saving',
    ].includes(field.label),
  )

  return (
    <section
      id="sustainability"
      className="section compliance-section"
      aria-label="Sustainability and responsible manufacturing"
    >
      <div className="container">
        <SectionHeader
          eyebrow="Sustainability"
          heading="Responsible Production, Documented with Care"
          introduction="ESHA Apparels approaches resource use, material options and production efficiency pragmatically. Initiatives and outcomes should be supported by verified evidence before publication."
          eyebrowClass="eyebrow--olive"
        />
        <div className="compliance-grid">
          {sustainabilityItems.map((item, index) => (
            <article className="compliance-item" key={item.id}>
              {index % 2 === 0 ? <LeafIcon /> : <ThreadIcon />}
              <h3>{item.title}</h3>
              <p>{item.description}</p>
            </article>
          ))}
        </div>
        <ImageStrip
          images={compliance.images}
          label="Sustainability image slot"
        />
        <div className="verification-panel verification-panel--olive">
          <div className="verification-panel__intro">
            <span className="placeholder-badge">Verified information only</span>
            <h3>Sustainability evidence area</h3>
            <p>
              Add initiatives, measurements and credentials only after supporting
              information is available.
            </p>
          </div>
          <div className="verification-panel__fields">
            {sustainabilityFields.map((field) => (
              <span key={field.label}>
                {field.label}: <PlaceholderValue value={field.value} />
              </span>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}

const exportRouteCoordinates = {
  'market-usa': {
    x: 417.8,
    y: 277.6,
    labelX: 29.5,
    labelY: 33,
    path: 'M 955.3 344.8 C 805 176 565 165 417.8 277.6',
  },
  'market-japan': {
    x: 1099,
    y: 284.5,
    labelX: 81.5,
    labelY: 35,
    path: 'M 955.3 344.8 C 1006 286 1064 260 1099 284.5',
  },
  'market-uk': {
    x: 676.4,
    y: 221.4,
    labelX: 48,
    labelY: 25,
    path: 'M 955.3 344.8 C 878 216 756 176 676.4 221.4',
  },
  'market-south-africa': {
    x: 774.6,
    y: 553.6,
    labelX: 55,
    labelY: 77,
    path: 'M 955.3 344.8 C 884 413 824 500 774.6 553.6',
  },
} as const

export function ExportSection() {
  const { exports } = companyData
  const origin = {
    x: 955.3,
    y: 344.8,
    labelX: 68,
    labelY: 52,
  }
  const routeMarkets = exports.markets.filter(
    (market) => market.id in exportRouteCoordinates,
  )
  const originMarket = exports.markets.find((market) => market.id === 'market-india')
  const defaultMarket = routeMarkets[0] ?? originMarket ?? exports.markets[0]
  const panelMarkets = [defaultMarket, ...routeMarkets.filter((market) => market.id !== defaultMarket.id)]
  const fallbackImage: ImageAsset = {
    src: exports.image.src,
    alt: exports.image.alt,
    recommendedShot: exports.image.recommendedShot,
  }

  return (
    <section
      id="export-network"
      className="section export-section"
      aria-label="Export and buyer experience"
    >
      <div className="container">
        <SectionHeader
          eyebrow={exports.eyebrow}
          heading={exports.heading}
          introduction={exports.introduction}
        />
        <div className="export-network" data-export-network>
          <Reveal>
            <div
              className="export-network__map-card"
              data-export-network-map
              aria-label="Global Export Network map"
            >
              <div className="export-network__map-heading">
                <span className="eyebrow eyebrow--light">Global Export Network</span>
                <p>From our manufacturing facilities in India to trusted international markets.</p>
              </div>
              <figure className="export-map export-network__map" aria-label="Global export route map">
                <svg
                  className="export-network__svg"
                  viewBox="0 0 1400 760"
                  role="img"
                  aria-label="Animated export routes from India to highlighted export markets"
                >
                  <image
                    href={exports.image.src}
                    width="1400"
                    height="760"
                    className="export-network__base-map"
                    preserveAspectRatio="xMidYMid meet"
                  />
                  <g className="export-network__origin">
                    <circle cx={origin.x} cy={origin.y} r="7" />
                    <circle cx={origin.x} cy={origin.y} r="17" />
                    <path d="M 844 418 L 872 430 L 848 450" />
                  </g>
                  {routeMarkets.map((market, index) => {
                    const route = exportRouteCoordinates[
                      market.id as keyof typeof exportRouteCoordinates
                    ]
                    return (
                      <g
                        className={`export-network__route-group${index === 0 ? ' is-active' : ''}`}
                        data-export-market={market.id}
                        role="button"
                        tabIndex={0}
                        aria-label={`${market.country}${market.company ? ` — ${market.company}` : ''}`}
                        key={market.id}
                        style={{ '--route-delay': `${index * 420}ms` } as CSSProperties}
                      >
                        <path
                          className="export-network__route"
                          d={route.path}
                          pathLength="1"
                        />
                        <circle
                          className="export-network__destination-halo"
                          cx={route.x}
                          cy={route.y}
                          r="14"
                        />
                        <circle
                          className="export-network__destination-point"
                          cx={route.x}
                          cy={route.y}
                          r="7"
                        />
                      </g>
                    )
                  })}
                </svg>
                {routeMarkets.map((market, index) => {
                  const route = exportRouteCoordinates[
                    market.id as keyof typeof exportRouteCoordinates
                  ]
                  return (
                    <button
                      className={`export-network__label${index === 0 ? ' is-active' : ''}`}
                      key={market.id}
                      type="button"
                      data-export-market={market.id}
                      aria-label={`${market.country}${market.company ? ` — ${market.company}` : ''}`}
                      style={{
                        '--label-x': `${route.labelX}%`,
                        '--label-y': `${route.labelY}%`,
                      } as CSSProperties}
                    >
                      <span>{market.country}</span>
                      {market.company && <small>{market.company}</small>}
                    </button>
                  )
                })}
              </figure>
            </div>
          </Reveal>
          <Reveal className="export-design-panel" delay={100}>
            <div className="export-design-panel__shell" data-export-design-panel>
              {panelMarkets.map((market, index) => {
                const image = market.image ?? fallbackImage
                return (
                  <article
                    className={`export-design-slide${index === 0 ? ' is-active' : ''}`}
                    data-export-design-slide
                    data-export-market={market.id}
                    key={market.id}
                    aria-hidden={index === 0 ? 'false' : 'true'}
                  >
                    <EditableImage
                      storageKey={`export-design-${market.id}`}
                      src={image.src}
                      alt={image.alt}
                      fit="cover"
                      aspectRatio="4 / 5"
                      className="export-design-image"
                      imageClassName="export-design-image__img"
                      label={`${market.country} garment image`}
                      caption={image.recommendedShot}
                      sizes="(max-width: 760px) 100vw, 34vw"
                    />
                    <div className="export-design-slide__content">
                      <span className="eyebrow eyebrow--light">
                        {market.country} collection
                      </span>
                      <h3>{market.designName ?? '[Design name]'}</h3>
                      <dl>
                        <div>
                          <dt>Fabric</dt>
                          <dd>{market.fabric ?? '[Fabric name]'}</dd>
                        </div>
                        <div>
                          <dt>Market</dt>
                          <dd>{market.country}</dd>
                        </div>
                        <div>
                          <dt>Production</dt>
                          <dd>{market.productionNote ?? market.note}</dd>
                        </div>
                        {market.company && (
                          <div>
                            <dt>Buyer / Company</dt>
                            <dd>{market.company}</dd>
                          </div>
                        )}
                      </dl>
                    </div>
                  </article>
                )
              })}
              <div className="export-design-panel__progress" aria-hidden="true">
                {panelMarkets.map((market, index) => (
                  <span
                    className={index === 0 ? 'is-active' : ''}
                    data-export-design-dot
                    data-export-market={market.id}
                    key={`${market.id}-dot`}
                  />
                ))}
              </div>
            </div>
          </Reveal>
        </div>
        <div className="export-layout export-layout--details" id="market-experience">
          <Reveal delay={160}>
            <span className="eyebrow">Market experience</span>
            <h3>International brief. Market-aware execution.</h3>
            <div className="export-markets">
              {exports.markets.map((market) => (
                <span className="export-market" key={market.id} data-export-market={market.id}>
                  <PlaceholderValue value={market.country} />
                  {market.company && <small>{market.company}</small>}
                </span>
              ))}
            </div>
            <div className="support-list">
              {exports.buyerSupport.map((support) => (
                <span key={support.id}>{support.title}</span>
              ))}
            </div>
            <p className="micro-copy">
              Buyer-support services are confirmed programme by programme. Editable
              verification notes are retained in the central data file.
            </p>
          </Reveal>
        </div>
      </div>
    </section>
  )
}

export function EventsSection() {
  const { events } = companyData
  const groups = [
    {
      title: 'Past Events',
      note: 'Completed participation, recognition and buyer-facing moments.',
      items: events.past,
    },
    {
      title: 'Future Events',
      note: 'Planned opportunities to be added after schedule confirmation.',
      items: events.future,
    },
  ]

  return (
    <section className="section events-section" aria-label="Events">
      <div className="container">
        <SectionHeader
          eyebrow={events.eyebrow}
          heading={events.heading}
          introduction={events.introduction}
        />
        <div className="events-layout">
          {groups.map((group, groupIndex) => (
            <Reveal key={group.title} delay={groupIndex * 100}>
              <article className="events-panel">
                <div className="events-panel__header">
                  <span>{groupIndex === 0 ? '01' : '02'}</span>
                  <div>
                    <h3>{group.title}</h3>
                    <p>{group.note}</p>
                  </div>
                </div>
                <div className="events-list">
                  {group.items.map((event) => (
                    <div className="event-card" key={event.id}>
                      <div className="event-card__top">
                        <span>{event.period}</span>
                        {event.status === 'verification-required' && (
                          <em>Editable placeholder</em>
                        )}
                      </div>
                      <h4>{event.title}</h4>
                      <p>{event.description}</p>
                    </div>
                  ))}
                </div>
              </article>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  )
}

export function AwardSection() {
  const { award } = companyData
  return (
    <section
      id="awards"
      className="section award-section"
      aria-label="Award and recognition"
    >
      <div className="container award-layout">
        <Reveal className="award-content">
          <span className="eyebrow eyebrow--gold">{award.eyebrow}</span>
          <h2>{award.title}</h2>
          <p className="award-category">{award.category}</p>
          <p>{award.description}</p>
        </Reveal>
        <Reveal className="award-visuals" delay={120}>
          <figure className="award-proof award-proof--primary">
            <img
              src={award.images[0].src}
              alt={award.images[0].alt}
              loading="lazy"
              decoding="async"
              sizes="(max-width: 760px) 100vw, 52vw"
            />
            <figcaption>
              <span>Reliance award proof</span>
              <small>{award.images[0].recommendedShot}</small>
            </figcaption>
          </figure>
          <figure className="award-proof award-proof--secondary">
            <img
              src={award.images[1].src}
              alt={award.images[1].alt}
              loading="lazy"
              decoding="async"
              sizes="(max-width: 760px) 100vw, 32vw"
            />
            <figcaption>
              <span>Award ceremony</span>
              <small>{award.images[1].recommendedShot}</small>
            </figcaption>
          </figure>
        </Reveal>
      </div>
    </section>
  )
}

export function BuyerSegmentsSection() {
  const { buyerSegments } = companyData
  return (
    <section
      className="section section--ivory"
      aria-label="Buyer segments we serve"
    >
      <div className="container">
        <SectionHeader
          eyebrow={buyerSegments.eyebrow}
          heading={buyerSegments.heading}
          introduction={buyerSegments.introduction}
          centered
        />
        <div className="buyer-grid">
          {buyerSegments.items.map((item, index) => (
            <article className="buyer-card" key={item.id}>
              <span>{formatIndex(index)}</span>
              <h3>{item.title}</h3>
              <p>{item.description}</p>
            </article>
          ))}
        </div>
        <p className="buyer-note">{buyerSegments.disclaimer}</p>
      </div>
    </section>
  )
}

export function ReasonsSection() {
  const { reasonsToChoose } = companyData
  return (
    <section
      className="section reasons-section"
      aria-label="Why buyers choose ESHA Apparels"
    >
      <div className="container">
        <SectionHeader
          eyebrow={reasonsToChoose.eyebrow}
          heading={reasonsToChoose.heading}
          introduction={reasonsToChoose.introduction}
        />
        <div className="reasons-grid">
          {reasonsToChoose.items.map((item, index) => (
            <article className="reason-item" key={item.id}>
              <span className="reason-item__number">{formatIndex(index)}</span>
              <div>
                <h3>{item.title}</h3>
                <p>{item.description}</p>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  )
}

function ProductLightbox({
  product,
  onClose,
  onEnquire,
}: {
  product: GalleryProduct
  onClose: () => void
  onEnquire: (product: GalleryProduct) => void
}) {
  const closeRef = useRef<HTMLButtonElement>(null)

  useEffect(() => {
    document.body.classList.add('modal-open')
    closeRef.current?.focus()
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') onClose()
    }
    window.addEventListener('keydown', onKeyDown)
    return () => {
      document.body.classList.remove('modal-open')
      window.removeEventListener('keydown', onKeyDown)
    }
  }, [onClose])

  return (
    <div
      className="lightbox"
      role="dialog"
      aria-modal="true"
      aria-labelledby="lightbox-title"
      onMouseDown={(event) => {
        if (event.target === event.currentTarget) onClose()
      }}
    >
      <button
        ref={closeRef}
        type="button"
        className="lightbox__close"
        aria-label="Close product detail"
        onClick={onClose}
      >
        <CloseIcon />
      </button>
      <div className="lightbox__dialog">
        <div className="lightbox__media">
          <EditableImage
            src={product.image.src}
            alt={product.image.alt}
            storageKey={`gallery-${product.id}`}
            fit="contain"
            label={`${product.title} image`}
            note={product.image.recommendedShot}
          />
        </div>
        <div className="lightbox__content">
          <span className="eyebrow">{product.category}</span>
          <h2 id="lightbox-title">{product.title}</h2>
          <p>{product.note}</p>
          <dl className="lightbox__data">
            {[
              ['Style code', product.styleCode],
              ['Fabric', product.fabric],
              ['Available sizes', product.availableSizes],
              ['Approx. FOB', product.approximatePriceRange],
              ['MOQ', product.moq],
              ['Colour options', product.colourOptions],
            ].map(([label, value]) => (
              <div key={label}>
                <dt>{label}</dt>
                <dd>
                  <PlaceholderValue value={value} />
                </dd>
              </div>
            ))}
          </dl>
          <button
            type="button"
            className="button button--primary"
            onClick={() => onEnquire(product)}
          >
            {companyData.gallery.enquiryLabel}
            <ArrowRightIcon />
          </button>
        </div>
      </div>
    </div>
  )
}

export function ProductGallery({
  onEnquire,
  printMode = false,
}: {
  onEnquire?: (product: GalleryProduct) => void
  printMode?: boolean
}) {
  const { gallery } = companyData
  const [filter, setFilter] = useState<GalleryFilter>('All Products')
  const [visibleCount, setVisibleCount] = useState(9)
  const [selectedProduct, setSelectedProduct] = useState<GalleryProduct | null>(
    null,
  )

  const filteredProducts = useMemo(
    () =>
      filter === 'All Products'
        ? gallery.products
        : gallery.products.filter((product) => product.filters.includes(filter)),
    [filter, gallery.products],
  )
  const visibleProducts = printMode
    ? gallery.products
    : filteredProducts.slice(0, visibleCount)

  const changeFilter = (nextFilter: GalleryFilter) => {
    setFilter(nextFilter)
    setVisibleCount(9)
  }

  const enquire = (product: GalleryProduct) => {
    setSelectedProduct(null)
    if (onEnquire) {
      onEnquire(product)
      return
    }

    const style = encodeURIComponent(`${product.styleCode} · ${product.category}`)
    window.location.href = `/contact?style=${style}`
  }

  return (
    <section
      className="section section--ivory"
      id="gallery"
      aria-label="Selected collections and product gallery"
    >
      <div className="container">
        <SectionHeader
          eyebrow={gallery.eyebrow}
          heading={gallery.heading}
          introduction={gallery.introduction}
        />
        {!printMode && (
          <div className="gallery-toolbar" role="group" aria-label="Gallery filters">
            {gallery.filters.map((item) => (
              <button
                className={`gallery-filter ${filter === item ? 'is-active' : ''}`}
                key={item}
                type="button"
                aria-pressed={filter === item}
                onClick={() => changeFilter(item)}
              >
                {item}
              </button>
            ))}
          </div>
        )}
        <div className="gallery-status" aria-live="polite">
          <span>{printMode ? 'Complete selected gallery' : filter}</span>
          <span>
            Showing {visibleProducts.length} of{' '}
            {printMode ? gallery.products.length : filteredProducts.length}
          </span>
        </div>

        {visibleProducts.length > 0 ? (
          <div className="gallery-grid">
            {visibleProducts.map((product) => (
              <article className="product-card" key={product.id}>
                <div className="product-card__media-button">
                  <EditableImage
                    src={product.image.src}
                    alt={product.image.alt}
                    storageKey={`gallery-${product.id}`}
                    fit="contain"
                    label={`${product.title} image`}
                    note={product.image.recommendedShot}
                  />
                  <span className="product-card__style">{product.styleCode}</span>
                  {!printMode && (
                    <button
                      type="button"
                      className="product-card__view"
                      aria-label={`Open details for ${product.title}`}
                      onClick={() => setSelectedProduct(product)}
                    >
                      View details
                    </button>
                  )}
                </div>
                <div className="product-card__content">
                  <div className="product-card__topline">
                    <div>
                      <h3>{product.title}</h3>
                      <span className="product-card__category">
                        {product.category}
                      </span>
                    </div>
                    <span className="product-card__price">
                      {product.approximatePriceRange}
                    </span>
                  </div>
                  <div className="product-card__meta">
                    <span>
                      <strong>Fabric</strong>
                      {product.fabric}
                    </span>
                    <span>
                      <strong>MOQ</strong>
                      {product.moq}
                    </span>
                    <span>
                      <strong>Sizes</strong>
                      {product.availableSizes}
                    </span>
                    <span>
                      <strong>Colours</strong>
                      {product.colourOptions}
                    </span>
                  </div>
                  <p className="product-card__note">{product.note}</p>
                  {!printMode && (
                    <button
                      type="button"
                      className="text-link"
                      onClick={() => enquire(product)}
                    >
                      {gallery.enquiryLabel}
                      <ArrowRightIcon />
                    </button>
                  )}
                </div>
              </article>
            ))}
          </div>
        ) : (
          <div className="gallery-empty">
            <h3>No styles in this filter yet</h3>
            <p>Add products in the central company data file.</p>
          </div>
        )}

        {!printMode && visibleCount < filteredProducts.length && (
          <div className="gallery-load">
            <button
              type="button"
              className="button button--secondary"
              onClick={() => setVisibleCount((count) => count + 12)}
            >
              {gallery.loadMoreLabel}
              <ArrowRightIcon />
            </button>
          </div>
        )}
      </div>

      {!printMode && selectedProduct && (
        <ProductLightbox
          product={selectedProduct}
          onClose={() => setSelectedProduct(null)}
          onEnquire={enquire}
        />
      )}
    </section>
  )
}

export function FAQSection({ printMode = false }: { printMode?: boolean }) {
  const { faqs } = companyData
  return (
    <section
      className="section section--off-white"
      aria-label="Frequently asked buyer questions"
    >
      <div className="container--narrow">
        <SectionHeader
          eyebrow={faqs.eyebrow}
          heading={faqs.heading}
          centered
        />
        <div className="faq-list">
          {faqs.items.map((faq, index) =>
            printMode ? (
              <article className="faq-item faq-item--static" key={faq.id}>
                <div className="faq-item__static-title">
                  <span className="faq-item__number">{formatIndex(index)}</span>
                  <strong>{faq.question}</strong>
                </div>
                <p className="faq-item__answer">{faq.answer}</p>
              </article>
            ) : (
              <details className="faq-item" key={faq.id} open={index === 0}>
                <summary>
                  <span className="faq-item__number">{formatIndex(index)}</span>
                  <span>{faq.question}</span>
                  <span className="faq-item__icon" aria-hidden="true" />
                </summary>
                <p className="faq-item__answer">{faq.answer}</p>
              </details>
            ),
          )}
        </div>
      </div>
    </section>
  )
}

function ContactIcon({ label }: { label: string }) {
  const normalized = label.toLowerCase()
  if (normalized.includes('email')) return <MailIcon />
  if (normalized.includes('phone') || normalized.includes('whatsapp')) {
    return <PhoneIcon />
  }
  if (normalized.includes('website')) return <GlobeIcon />
  return <MapPinIcon />
}

function FormControl({ field }: { field: EnquiryField }) {
  const requiredMark = field.required ? (
    <span aria-hidden="true"> *</span>
  ) : null

  if (field.type === 'textarea') {
    return (
      <div className={`form-field ${field.fullWidth ? 'form-field--full' : ''}`}>
        <label htmlFor={field.id}>
          {field.label}
          {requiredMark}
        </label>
        <textarea
          id={field.id}
          name={field.name}
          placeholder={field.placeholder}
          required={field.required}
        />
        {field.helperText && <small>{field.helperText}</small>}
      </div>
    )
  }

  if (field.type === 'select') {
    return (
      <div className={`form-field ${field.fullWidth ? 'form-field--full' : ''}`}>
        <label htmlFor={field.id}>
          {field.label}
          {requiredMark}
        </label>
        <select id={field.id} name={field.name} required={field.required}>
          {field.options?.map((option) => (
            <option key={option.value || option.label} value={option.value}>
              {option.label}
            </option>
          ))}
        </select>
      </div>
    )
  }

  if (field.type === 'radio') {
    return (
      <fieldset
        className={`form-field form-fieldset ${
          field.fullWidth ? 'form-field--full' : ''
        }`}
      >
        <legend>
          {field.label}
          {requiredMark}
        </legend>
        <div className="radio-row">
          {field.options?.map((option) => {
            const optionId = `${field.id}-${option.value}`
            return (
            <label key={option.value} htmlFor={optionId}>
              <input
                id={optionId}
                type="radio"
                name={field.name}
                value={option.value}
                required={field.required}
              />
              {option.label}
            </label>
            )
          })}
        </div>
      </fieldset>
    )
  }

  if (field.type === 'file') {
    return (
      <div className={`form-field ${field.fullWidth ? 'form-field--full' : ''}`}>
        <label htmlFor={field.id}>
          {field.label}
          {requiredMark}
        </label>
        <label className="upload-field" htmlFor={field.id}>
          <input
            id={field.id}
            type="file"
            name={field.name}
            accept={field.accept}
            required={field.required}
          />
          <span>
            <UploadIcon />
            <strong>Choose a file or drag it here</strong>
            <small>{field.helperText ?? 'PDF, image or requirement sheet'}</small>
          </span>
        </label>
      </div>
    )
  }

  return (
    <div className={`form-field ${field.fullWidth ? 'form-field--full' : ''}`}>
      <label htmlFor={field.id}>
        {field.label}
        {requiredMark}
      </label>
      <input
        id={field.id}
        type={field.type}
        name={field.name}
        placeholder={field.placeholder}
        required={field.required}
      />
      {field.helperText && <small>{field.helperText}</small>}
    </div>
  )
}

function BuyerEnquiryForm({ selectedStyle }: { selectedStyle: string }) {
  const { enquiry } = companyData
  const [submitted, setSubmitted] = useState(false)

  const submit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    const form = event.currentTarget
    const formData = new FormData(form)
    const resolveFieldValue = (field: EnquiryField) => {
      const element = form.elements.namedItem(field.name)

      if (element instanceof HTMLSelectElement) {
        const selectedLabel = element.selectedOptions[0]?.textContent?.trim()
        return selectedLabel && element.value ? selectedLabel : 'Not provided'
      }

      const rawValue = formData.get(field.name)
      return typeof rawValue === 'string' && rawValue.trim()
        ? rawValue.trim()
        : 'Not provided'
    }
    const fieldLines = enquiry.fields.map((field) => {
      const value = resolveFieldValue(field)
      return `${field.label}: ${value}`
    })
    const subjectParts = [
      'ESHA Apparels Buyer Enquiry',
      formData.get('companyName'),
      formData.get('country'),
    ]
      .filter((value): value is string => typeof value === 'string' && value.trim().length > 0)
      .map((value) => value.trim())
    const body = [
      'Hello ESHA Apparels,',
      '',
      'Please review the following buyer enquiry:',
      '',
      selectedStyle ? `Selected style: ${selectedStyle}` : '',
      ...fieldLines,
      '',
      'Submitted from the ESHA Apparels website.',
    ]
      .filter((line) => line !== '')
      .join('\n')

    setSubmitted(true)
    window.location.href = `mailto:${enquiry.emailTo}?subject=${encodeURIComponent(
      subjectParts.join(' · '),
    )}&body=${encodeURIComponent(body)}`
  }

  return (
    <form
      className="enquiry-form"
      onSubmit={submit}
      data-enquiry-email={enquiry.emailTo}
      aria-describedby="enquiry-costing-note"
    >
      <div className="form-header">
        <div>
          <span className="eyebrow">Buyer brief</span>
          <h3>Buyer enquiry essentials</h3>
          <p>Short, practical details for first feasibility review.</p>
        </div>
        <span className="placeholder-badge">Email-ready</span>
      </div>

      {selectedStyle && (
        <div className="form-status" role="status">
          <CheckIcon />
          <span>
            Style added to enquiry: <strong>{selectedStyle}</strong>
          </span>
        </div>
      )}

      {submitted && (
        <div className="form-status" role="status">
          <CheckIcon />
          <span>{enquiry.successMessage}</span>
        </div>
      )}

      <div className="form-grid">
        {enquiry.fields.map((field) => (
          <FormControl key={field.id} field={field} />
        ))}
        <div className="form-field form-field--full consent-field">
          <label>
            <input type="checkbox" required /> {enquiry.consentLabel}
          </label>
        </div>
      </div>
      <p className="form-note" id="enquiry-costing-note">
        {enquiry.costingNote}
      </p>
      <button type="submit" className="button button--primary">
        {enquiry.submitLabel}
        <ArrowRightIcon />
      </button>
    </form>
  )
}

export function EnquirySection({
  selectedStyle = '',
}: {
  selectedStyle?: string
}) {
  const { enquiry, contact } = companyData
  const [queryStyle, setQueryStyle] = useState(selectedStyle)

  useEffect(() => {
    if (selectedStyle) return
    const style = new URLSearchParams(window.location.search).get('style')
    if (style) setQueryStyle(style)
  }, [selectedStyle])

  return (
    <section
      className="section enquiry-section"
      id="contact"
      aria-label="Buyer enquiry"
    >
      <div className="container">
        <div className="enquiry-layout">
          <Reveal className="enquiry-intro">
            <span className="eyebrow eyebrow--light">{enquiry.eyebrow}</span>
            <h2>{enquiry.heading}</h2>
            <p>{enquiry.introduction}</p>
            <div className="contact-list">
              {contact.details.map((detail) => (
                <div className="contact-item" key={detail.label}>
                  <ContactIcon label={detail.label} />
                  <div>
                    <span>{detail.label}</span>
                    <strong>
                      <ContactDetailValue
                        label={detail.label}
                        value={detail.value}
                      />
                    </strong>
                  </div>
                </div>
              ))}
            </div>
            <div className="contact-support">
              <div className="contact-logo-frame">
                <img src={contact.qrCode.src} alt={contact.qrCode.alt} />
              </div>
              <div>
                <span className="eyebrow eyebrow--light">Social channels</span>
                {contact.socialMedia.map((item) => (
                  <p className="contact-social" key={item.label}>
                    {item.label}: <PlaceholderValue value={item.value} />
                  </p>
                ))}
              </div>
            </div>
          </Reveal>
          <Reveal delay={100}>
            <BuyerEnquiryForm key={queryStyle} selectedStyle={queryStyle} />
          </Reveal>
        </div>
      </div>
    </section>
  )
}

export function ClosingSection({
  onPrint,
  plainBlack = false,
}: {
  onPrint?: () => void
  plainBlack?: boolean
}) {
  const { closing } = companyData
  return (
    <section
      className={`section closing-section${plainBlack ? ' closing-section--plain-black' : ''}`}
      aria-label="Let’s build your next collection"
    >
      <figure className="closing-section__media">
        <EditableImage
          src={closing.image.src}
          alt={closing.image.alt}
          storageKey="closing-main"
          fit="cover"
          label="Closing image"
          note={closing.image.recommendedShot}
        />
      </figure>
      <Reveal className="closing-content container--narrow">
        <span className="eyebrow eyebrow--light">A manufacturing conversation</span>
        <h2>{closing.heading}</h2>
        <p>{closing.text}</p>
        <div className="button-row">
          {closing.actions.map((action) => (
            <ActionButton key={action.label} action={action} onPrint={onPrint} />
          ))}
        </div>
      </Reveal>
    </section>
  )
}

function Footer() {
  return (
    <footer className="footer">
      <div className="container">
        <div className="footer-grid">
          <div className="footer-brand">
            <a className="brand" href="/">
              <span className="brand__name">{companyData.brand.name}</span>
              <span className="brand__descriptor">
                Women’s garment manufacturing & export
              </span>
            </a>
            <p>
              {companyData.footer.strapline} Commercial, trend-focused and
              export-ready women’s fashion for buyer programmes.
            </p>
          </div>
          <div>
            <h3>Profile</h3>
            <div className="footer-links">
              {companyData.navigation.slice(0, 5).map((item) => (
                <a href={item.href} key={item.href}>
                  {item.label}
                </a>
              ))}
            </div>
          </div>
          <div>
            <h3>Capabilities</h3>
            <div className="footer-links">
              {companyData.navigation.slice(5).map((item) => (
                <a href={item.href} key={item.href}>
                  {item.label}
                </a>
              ))}
            </div>
          </div>
          <div>
            <h3>Contact placeholders</h3>
            <div className="footer-links">
              {companyData.contact.details.slice(0, 4).map((item) => (
                <span key={item.label}>
                  {item.label}:{' '}
                  <ContactDetailValue label={item.label} value={item.value} />
                </span>
              ))}
            </div>
          </div>
        </div>
        <div className="footer-bottom">
          <span>{companyData.footer.legalLine}</span>
          <span>{companyData.footer.placeholderNotice}</span>
        </div>
      </div>
    </footer>
  )
}

export function HomePathwaysSection() {
  const descriptions: Record<string, string> = {
    '/about': 'Buyer support and the partners we can evaluate.',
    '/facilities': 'Two-factory infrastructure, production flow and operating scale.',
    '/products': 'Women’s western-wear categories, materials and selected styles.',
    '/quality-compliance':
      'Structured checkpoints, verification fields and buyer requirements.',
    '/sustainability':
      'Responsible manufacturing awareness and practical efficiency initiatives.',
    '/export': 'International sourcing support and confirmed Japanese-market experience.',
    '/events': 'Past participation and upcoming buyer-facing event opportunities.',
    '/awards': 'Verified recognition and supporting award evidence.',
    '/contact': 'Share a category, quantity and product requirement.',
  }

  return (
    <section className="section section--off-white page-pathways">
      <div className="container">
        <SectionHeader
          eyebrow="Explore the profile"
          heading="Focused Information for Faster Buyer Review"
          introduction="Move directly to the company information most relevant to your sourcing decision."
        />
        <div className="page-pathways__grid">
          {companyData.navigation
            .filter((item) => item.href !== '/')
            .map((item, index) => (
              <a className="page-pathway" href={item.href} key={item.href}>
                <span>{formatIndex(index)}</span>
                <h3>{item.label}</h3>
                <p>{descriptions[item.href]}</p>
                <ArrowUpRightIcon />
              </a>
            ))}
        </div>
      </div>
    </section>
  )
}

function ProfilePdfSummary() {
  const summaryFacts = [
    ['Specialisation', 'Women’s western wear and fast-fashion garments'],
    ['Production capacity', 'Up to 250,000 pieces per month'],
    ['Manufacturing base', 'Two factories in Sitapura, Jaipur'],
    ['Sewing machines', '575 industrial sewing machines'],
    ['FOB positioning', 'Approx. USD 3–12 per piece'],
    ['Standard MOQ', 'Approx. 700 pieces per style'],
  ]

  return (
    <section
      className="section profile-pdf-summary"
      aria-label="PDF company profile summary"
    >
      <div className="container profile-pdf-summary__grid">
        <div>
          <span className="eyebrow">Company profile summary</span>
          <h2>ESHA Apparels Company Profile</h2>
          <p>
            A concise buyer-facing reference for women’s garment manufacturing,
            export-ready production, two-factory infrastructure, quality checkpoints
            and confirmed commercial positioning.
          </p>
        </div>
        <dl className="profile-pdf-summary__facts">
          {summaryFacts.map(([label, value]) => (
            <div key={label}>
              <dt>{label}</dt>
              <dd>{value}</dd>
            </div>
          ))}
        </dl>
      </div>
    </section>
  )
}

export function CompleteProfilePage() {
  const printProfile = () => window.print()

  return (
    <ProfileShell
      activePath=""
      pageTitle="Complete Company Profile"
      className="complete-profile"
      showFooter={false}
      showBuyerEnquiry={false}
    >
      <div className="profile-download-toolbar">
        <div>
          <span className="eyebrow">Complete profile</span>
          <strong>Review online or save the full profile as a PDF.</strong>
        </div>
        <button
          className="button button--primary"
          type="button"
          onClick={printProfile}
        >
          Print / Save PDF
          <PrintIcon />
        </button>
      </div>
      <HeroSection />
      <ProfilePdfSummary />
      <CompanyIntroduction />
      <PastPresentFutureSection />
      <ClientAssociationsSection />
      <StatisticStrip />
      <FactorySection />
      <MaterialsSection />
      <QualitySection />
      <ComplianceSection />
      <SustainabilitySection />
      <ExportSection />
      <EventsSection />
      <AwardSection />
      <BuyerSegmentsSection />
      <ReasonsSection />
      <ProductGallery printMode />
    </ProfileShell>
  )
}

export default function App() {
  return (
    <ProfileShell activePath="/" pageTitle="Women’s Fashion Manufacturing">
      <HeroSection showActions={false} />
      <BuyerDecisionFlowSection />
      <StatisticStrip />
      <ReasonsSection />
      <HomePathwaysSection />
      <ClosingSection plainBlack />
    </ProfileShell>
  )
}
