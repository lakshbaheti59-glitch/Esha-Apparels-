const DATABASE_NAME = 'esha-apparels-editable-images'
const DATABASE_VERSION = 1
const STORE_NAME = 'images'

export type StoredImageRecord = {
  storageKey: string
  blob: Blob
  fileName: string
  mimeType: string
  updatedAt: number
}

export class ImageStoreError extends Error {
  readonly cause: unknown

  constructor(message: string, cause?: unknown) {
    super(message)
    this.name = 'ImageStoreError'
    this.cause = cause
  }
}

let databasePromise: Promise<IDBDatabase> | null = null

function assertStorageKey(storageKey: string) {
  if (!storageKey.trim()) {
    throw new ImageStoreError('An image storage key cannot be empty.')
  }
}

function openDatabase(): Promise<IDBDatabase> {
  if (typeof indexedDB === 'undefined') {
    return Promise.reject(
      new ImageStoreError('This browser does not provide IndexedDB storage.'),
    )
  }

  if (databasePromise) return databasePromise

  databasePromise = new Promise<IDBDatabase>((resolve, reject) => {
    const request = indexedDB.open(DATABASE_NAME, DATABASE_VERSION)
    let settled = false

    request.onupgradeneeded = () => {
      const database = request.result
      if (!database.objectStoreNames.contains(STORE_NAME)) {
        database.createObjectStore(STORE_NAME, { keyPath: 'storageKey' })
      }
    }

    request.onsuccess = () => {
      const database = request.result

      if (settled) {
        database.close()
        return
      }

      settled = true
      database.onversionchange = () => {
        database.close()
        databasePromise = null
      }
      resolve(database)
    }

    request.onerror = () => {
      if (settled) return
      settled = true
      reject(
        new ImageStoreError(
          'The editable image database could not be opened.',
          request.error,
        ),
      )
    }

    request.onblocked = () => {
      if (settled) return
      settled = true
      reject(
        new ImageStoreError(
          'The editable image database is blocked by another open page.',
        ),
      )
    }
  }).catch((error: unknown) => {
    databasePromise = null
    throw error
  })

  return databasePromise
}

function transactionError(
  message: string,
  transaction: IDBTransaction,
): ImageStoreError {
  return new ImageStoreError(message, transaction.error)
}

export async function getStoredImage(
  storageKey: string,
): Promise<StoredImageRecord | null> {
  assertStorageKey(storageKey)
  const database = await openDatabase()

  return new Promise<StoredImageRecord | null>((resolve, reject) => {
    const transaction = database.transaction(STORE_NAME, 'readonly')
    const request = transaction.objectStore(STORE_NAME).get(storageKey)
    let record: StoredImageRecord | null = null
    let settled = false

    request.onsuccess = () => {
      record = (request.result as StoredImageRecord | undefined) ?? null
    }

    request.onerror = () => {
      if (settled) return
      settled = true
      reject(
        new ImageStoreError(
          `The saved image for "${storageKey}" could not be read.`,
          request.error,
        ),
      )
    }

    transaction.oncomplete = () => {
      if (settled) return
      settled = true
      resolve(record)
    }

    transaction.onerror = () => {
      if (settled) return
      settled = true
      reject(
        transactionError(
          `The saved image for "${storageKey}" could not be read.`,
          transaction,
        ),
      )
    }

    transaction.onabort = transaction.onerror
  })
}

export async function putStoredImage(
  storageKey: string,
  blob: Blob,
  fileName = 'replacement-image',
): Promise<void> {
  assertStorageKey(storageKey)
  const database = await openDatabase()

  const record: StoredImageRecord = {
    storageKey,
    blob,
    fileName,
    mimeType: blob.type,
    updatedAt: Date.now(),
  }

  return new Promise<void>((resolve, reject) => {
    const transaction = database.transaction(STORE_NAME, 'readwrite')
    transaction.objectStore(STORE_NAME).put(record)
    let settled = false

    transaction.oncomplete = () => {
      if (settled) return
      settled = true
      resolve()
    }

    transaction.onerror = () => {
      if (settled) return
      settled = true
      reject(
        transactionError(
          `The replacement image for "${storageKey}" could not be saved.`,
          transaction,
        ),
      )
    }

    transaction.onabort = transaction.onerror
  })
}

export async function deleteStoredImage(storageKey: string): Promise<void> {
  assertStorageKey(storageKey)
  const database = await openDatabase()

  return new Promise<void>((resolve, reject) => {
    const transaction = database.transaction(STORE_NAME, 'readwrite')
    transaction.objectStore(STORE_NAME).delete(storageKey)
    let settled = false

    transaction.oncomplete = () => {
      if (settled) return
      settled = true
      resolve()
    }

    transaction.onerror = () => {
      if (settled) return
      settled = true
      reject(
        transactionError(
          `The replacement image for "${storageKey}" could not be removed.`,
          transaction,
        ),
      )
    }

    transaction.onabort = transaction.onerror
  })
}
