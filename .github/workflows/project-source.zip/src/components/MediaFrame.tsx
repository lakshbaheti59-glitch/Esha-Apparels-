import type { CSSProperties, ImgHTMLAttributes, ReactNode } from 'react'
import { EditableImage } from './EditableImage'

type MediaFrameProps = {
  src: string
  alt: string
  label?: string
  note?: string
  className?: string
  priority?: boolean
  aspect?: CSSProperties['aspectRatio']
  overlay?: ReactNode
  imgClassName?: string
  sizes?: string
} & Pick<ImgHTMLAttributes<HTMLImageElement>, 'onClick'>

export function MediaFrame({
  src,
  alt,
  label,
  note = 'Replace with approved ESHA Apparels photography',
  className = '',
  priority = false,
  aspect,
  overlay,
  onClick,
  imgClassName = '',
  sizes = '(max-width: 768px) 100vw, 50vw',
}: MediaFrameProps) {
  const storageKey = `asset-${src
    .replace(/^\/+/, '')
    .replace(/\.[^/.]+$/, '')
    .replace(/[^a-z0-9]+/gi, '-')
    .replace(/^-|-$/g, '')
    .toLowerCase()}`

  return (
    <div
      className={`media-frame ${className}`}
      style={aspect ? { aspectRatio: aspect } : undefined}
    >
      <EditableImage
        className="media-frame__editable"
        imageClassName={imgClassName}
        storageKey={storageKey}
        src={src}
        alt={alt}
        priority={priority}
        fit={imgClassName.includes('contain') ? 'contain' : 'cover'}
        sizes={sizes}
        imgProps={{ onClick }}
      />
      {label && (
        <div className="media-frame__caption">
          <span>{label}</span>
          <small>{note}</small>
        </div>
      )}
      {overlay}
    </div>
  )
}
