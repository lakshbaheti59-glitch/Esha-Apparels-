'use client'

import {
  useCallback,
  useEffect,
  useId,
  useRef,
  useState,
  type CSSProperties,
  type ImgHTMLAttributes,
  type ReactNode,
} from 'react'
import {
  deleteStoredImage,
  getStoredImage,
  putStoredImage,
} from '../lib/imageStore'

const ACCEPTED_FILE_TYPES =
  '.jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp'
const ACCEPTED_MIME_TYPES = new Set([
  'image/jpeg',
  'image/jpg',
  'image/png',
  'image/webp',
])
const ACCEPTED_EXTENSIONS = new Set(['jpg', 'jpeg', 'png', 'webp'])

type EditableImageSource = 'fallback' | 'replacement'

export type EditableImageChange = {
  storageKey: string
  source: EditableImageSource
  file?: File
}

export type EditableImageProps = {
  /** Required stable, page-independent ID, for example "factory-one-exterior". */
  storageKey: string
  /** The bundled image shown until a buyer-approved replacement is selected. */
  fallbackSrc?: string
  /** Convenience alias for fallbackSrc. */
  src?: string
  alt: string
  fit?: 'cover' | 'contain'
  aspectRatio?: CSSProperties['aspectRatio']
  objectPosition?: CSSProperties['objectPosition']
  className?: string
  imageClassName?: string
  style?: CSSProperties
  imageStyle?: CSSProperties
  label?: ReactNode
  caption?: ReactNode
  note?: ReactNode
  overlay?: ReactNode
  replaceLabel?: string
  removeLabel?: string
  imageButtonLabel?: string
  disabled?: boolean
  priority?: boolean
  sizes?: string
  imgProps?: Omit<
    ImgHTMLAttributes<HTMLImageElement>,
    'src' | 'alt' | 'className' | 'style' | 'sizes'
  >
  onChange?: (change: EditableImageChange) => void
}

function isAcceptedImage(file: File) {
  const mimeType = file.type.toLowerCase()
  const extension = file.name.split('.').pop()?.toLowerCase() ?? ''

  if (ACCEPTED_MIME_TYPES.has(mimeType)) return true
  return mimeType === '' && ACCEPTED_EXTENSIONS.has(extension)
}

function readableStorageError(action: 'load' | 'save' | 'remove') {
  if (action === 'load') {
    return 'Saved image replacements are unavailable in this browser. You can still choose an image for this session.'
  }

  if (action === 'save') {
    return 'The preview is active, but this browser could not save it for the next visit.'
  }

  return 'The original image is restored for this visit, but the saved replacement could not be removed.'
}

const visuallyHiddenStyle: CSSProperties = {
  position: 'absolute',
  width: 1,
  height: 1,
  padding: 0,
  margin: -1,
  overflow: 'hidden',
  clip: 'rect(0, 0, 0, 0)',
  whiteSpace: 'nowrap',
  border: 0,
}

export function EditableImage({
  storageKey,
  fallbackSrc,
  src,
  alt,
  fit = 'cover',
  aspectRatio,
  objectPosition = 'center',
  className = '',
  imageClassName = '',
  style,
  imageStyle,
  label,
  caption,
  note,
  overlay,
  replaceLabel = 'Replace',
  removeLabel = 'Remove',
  imageButtonLabel,
  disabled = false,
  priority = false,
  sizes = '100vw',
  imgProps,
  onChange,
}: EditableImageProps) {
  const inputRef = useRef<HTMLInputElement>(null)
  const objectUrlRef = useRef<string | null>(null)
  const operationRef = useRef(0)
  const statusId = useId()
  const errorId = useId()
  const [replacementSrc, setReplacementSrc] = useState<string | null>(null)
  const [hasReplacement, setHasReplacement] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  const [status, setStatus] = useState('Loading saved image…')
  const [error, setError] = useState('')

  const revokeObjectUrl = useCallback(() => {
    if (!objectUrlRef.current) return
    URL.revokeObjectURL(objectUrlRef.current)
    objectUrlRef.current = null
  }, [])

  const showBlob = useCallback(
    (blob: Blob) => {
      const nextUrl = URL.createObjectURL(blob)
      revokeObjectUrl()
      objectUrlRef.current = nextUrl
      setReplacementSrc(nextUrl)
    },
    [revokeObjectUrl],
  )

  const showFallback = useCallback(() => {
    revokeObjectUrl()
    setReplacementSrc(null)
    setHasReplacement(false)
  }, [revokeObjectUrl])

  useEffect(() => {
    const operation = ++operationRef.current
    let cancelled = false

    showFallback()
    setError('')
    setIsLoading(true)
    setStatus('Loading saved image…')

    if (!storageKey.trim()) {
      setError('EditableImage requires a non-empty, unique storageKey.')
      setStatus('Using the supplied image.')
      setIsLoading(false)
      return () => {
        cancelled = true
      }
    }

    void getStoredImage(storageKey)
      .then((record) => {
        if (cancelled || operation !== operationRef.current) return

        if (record?.blob) {
          showBlob(record.blob)
          setHasReplacement(true)
          setStatus('Saved replacement loaded from this browser.')
        } else {
          setStatus('Using the supplied image. Select it or choose Replace to update.')
        }
      })
      .catch(() => {
        if (cancelled || operation !== operationRef.current) return
        setError(readableStorageError('load'))
        setStatus('Using the supplied image.')
      })
      .finally(() => {
        if (cancelled || operation !== operationRef.current) return
        setIsLoading(false)
      })

    return () => {
      cancelled = true
    }
  }, [showBlob, showFallback, storageKey])

  useEffect(
    () => () => {
      revokeObjectUrl()
    },
    [revokeObjectUrl],
  )

  const openPicker = useCallback(() => {
    if (disabled) return
    inputRef.current?.click()
  }, [disabled])

  const handleFileChange = useCallback(
    (event: React.ChangeEvent<HTMLInputElement>) => {
      const file = event.currentTarget.files?.[0]
      event.currentTarget.value = ''
      if (!file) return

      if (!isAcceptedImage(file)) {
        setError(
          `"${file.name}" is not supported. Choose a JPG, JPEG, PNG or WebP image.`,
        )
        setStatus('Image was not changed.')
        return
      }

      const operation = ++operationRef.current
      showBlob(file)
      setHasReplacement(true)
      setIsLoading(false)
      setError('')
      setStatus('Replacement selected. Saving in this browser…')
      onChange?.({ storageKey, source: 'replacement', file })

      void putStoredImage(storageKey, file, file.name)
        .then(() => {
          if (operation !== operationRef.current) return
          setStatus('Replacement saved in this browser.')
        })
        .catch(() => {
          if (operation !== operationRef.current) return
          setError(readableStorageError('save'))
          setStatus('Replacement is available for this session.')
        })
    },
    [onChange, showBlob, storageKey],
  )

  const handleRemove = useCallback(() => {
    if (disabled || !hasReplacement) return

    const operation = ++operationRef.current
    showFallback()
    setError('')
    setStatus('Original image restored. Removing saved replacement…')
    onChange?.({ storageKey, source: 'fallback' })

    void deleteStoredImage(storageKey)
      .then(() => {
        if (operation !== operationRef.current) return
        setStatus('Original image restored.')
      })
      .catch(() => {
        if (operation !== operationRef.current) return
        setError(readableStorageError('remove'))
        setStatus('Original image restored for this session.')
      })
  }, [disabled, hasReplacement, onChange, showFallback, storageKey])

  const handleImageError = useCallback(
    (event: React.SyntheticEvent<HTMLImageElement>) => {
      imgProps?.onError?.(event)

      if (hasReplacement) {
        ++operationRef.current
        showFallback()
        setError(
          'The selected image could not be displayed, so the supplied image was restored.',
        )
        setStatus('Using the supplied image.')
        void deleteStoredImage(storageKey).catch(() => undefined)
        onChange?.({ storageKey, source: 'fallback' })
        return
      }

      setError('The supplied fallback image could not be displayed.')
      setStatus('Image unavailable.')
    },
    [hasReplacement, imgProps, onChange, showFallback, storageKey],
  )

  const suppliedSrc = src ?? fallbackSrc ?? ''
  const source = replacementSrc ?? suppliedSrc
  const pickerLabel =
    imageButtonLabel ??
    `${hasReplacement ? 'Replace' : 'Choose a replacement for'}: ${alt}`

  return (
    <figure
      className={`editable-image ${hasReplacement ? 'has-replacement' : ''} ${className}`}
      style={{
        position: 'relative',
        margin: 0,
        color: 'var(--color-soft-black, #292724)',
        ...style,
      }}
      aria-busy={isLoading}
    >
      <button
        className="editable-image__trigger"
        type="button"
        onClick={openPicker}
        disabled={disabled}
        aria-label={pickerLabel}
        aria-describedby={`${statusId} ${errorId}`}
        style={{
          position: 'relative',
          display: 'block',
          width: '100%',
          padding: 0,
          overflow: 'hidden',
          border: 0,
          borderRadius: 0,
          background: 'var(--color-taupe-pale, #EEE7E0)',
          cursor: disabled ? 'not-allowed' : 'pointer',
          aspectRatio,
        }}
      >
        <img
          {...imgProps}
          className={imageClassName}
          src={source}
          alt={alt}
          sizes={sizes}
          loading={priority ? 'eager' : (imgProps?.loading ?? 'lazy')}
          fetchPriority={
            priority ? 'high' : (imgProps?.fetchPriority ?? 'auto')
          }
          decoding={imgProps?.decoding ?? 'async'}
          onError={handleImageError}
          style={{
            display: 'block',
            width: '100%',
            height: aspectRatio ? '100%' : 'auto',
            objectFit: fit,
            objectPosition,
            ...imageStyle,
          }}
        />
        {overlay && (
          <span
            aria-hidden="true"
            style={{ position: 'absolute', inset: 0, pointerEvents: 'none' }}
          >
            {overlay}
          </span>
        )}
        <span className="editable-image__prompt" aria-hidden="true">
          {hasReplacement ? 'Replace image' : 'Choose image'}
        </span>
      </button>

      <input
        ref={inputRef}
        type="file"
        accept={ACCEPTED_FILE_TYPES}
        onChange={handleFileChange}
        disabled={disabled}
        aria-label={`Choose a JPG, PNG or WebP replacement for ${alt}`}
        tabIndex={-1}
        style={visuallyHiddenStyle}
      />

      <div
        className="editable-image__controls"
        aria-label="Image editing controls"
      >
        <button
          className="editable-image__control editable-image__control--primary"
          type="button"
          onClick={openPicker}
          disabled={disabled}
          style={{
            cursor: disabled ? 'not-allowed' : 'pointer',
          }}
        >
          {replaceLabel}
        </button>
        <button
          className="editable-image__control"
          type="button"
          onClick={handleRemove}
          disabled={disabled || !hasReplacement}
          aria-disabled={disabled || !hasReplacement}
          style={{
            opacity: disabled || !hasReplacement ? 0.55 : 1,
            cursor:
              disabled || !hasReplacement ? 'not-allowed' : 'pointer',
          }}
        >
          {removeLabel}
        </button>
      </div>

      {(label || caption || note) && (
        <figcaption className="editable-image__caption">
          {label && <strong>{label}</strong>}
          {(caption || note) && <small>{caption ?? note}</small>}
        </figcaption>
      )}

      <p
        className="sr-only"
        id={statusId}
        role="status"
        aria-live="polite"
      >
        {status}
      </p>
      {error && (
        <p
          className="editable-image__error"
          id={errorId}
          role="alert"
        >
          {error}
        </p>
      )}
      {!error && <span className="sr-only" id={errorId} />}
    </figure>
  )
}
