/**
 * ESHA Apparels — central company-profile content source
 *
 * EDITING GUIDE
 * 1. Search this file for "[" to find every item that still needs verification.
 * 2. Replace image files in /public/images while keeping the paths below unchanged,
 *    or update the relevant `src` value here.
 * 3. Do not remove brackets from a placeholder until the information is verified.
 * 4. Keep all commercial figures qualified as approximate or "up to" where shown.
 */

export type VerificationStatus = "confirmed" | "verification-required";
export type ButtonVariant = "primary" | "secondary" | "light";
export type FormFieldType =
  | "text"
  | "email"
  | "tel"
  | "url"
  | "select"
  | "date"
  | "textarea"
  | "file"
  | "radio";

export interface ImageAsset {
  src: string;
  alt: string;
  recommendedShot: string;
}

export interface ActionLink {
  label: string;
  href: string;
  variant: ButtonVariant;
  download?: boolean;
}

export interface EditableField {
  label: string;
  value: string;
  status?: VerificationStatus;
}

export interface Statistic {
  id: string;
  value: string;
  label: string;
  detail?: string;
}

export interface BuyerDecisionStep {
  id: string;
  label: string;
  title: string;
  description: string;
  href: string;
  cta: string;
}

export interface TimelineCard {
  id: string;
  label: string;
  title: string;
  text: string;
  highlights: readonly string[];
}

export interface ClientLogo {
  id: string;
  name: string;
  logo: ImageAsset;
  note?: string;
}

export interface ClientLogoGroup {
  id: "national" | "international";
  title: string;
  description: string;
  logos: readonly ClientLogo[];
  emptyState?: string;
}

export interface EventItem {
  id: string;
  title: string;
  period: string;
  description: string;
  status: VerificationStatus;
}

export interface FactoryProfile {
  id: "factory-one" | "factory-two";
  number: string;
  name: string;
  introduction: string;
  details: readonly EditableField[];
  images: readonly ImageAsset[];
}

export interface ProductCategory {
  id: string;
  name: string;
  description: string;
  fabrics: readonly string[];
  customisation: string;
  image: ImageAsset;
  layout: "feature" | "portrait" | "landscape" | "split";
}

export interface ProcessStep {
  id: string;
  number: string;
  title: string;
  description: string;
}

export interface CapabilityItem {
  id: string;
  title: string;
  description: string;
}

export interface QualityCheckpoint {
  id: string;
  title: string;
  description: string;
}

export interface ComplianceItem {
  id: string;
  title: string;
  description: string;
}

export interface ExportMarket {
  id: string;
  country: string;
  status: VerificationStatus;
  note: string;
  company?: string;
  designName?: string;
  fabric?: string;
  productionNote?: string;
  image?: ImageAsset;
}

export interface BuyerSupportCapability {
  id: string;
  title: string;
  verification: string;
  status: VerificationStatus;
}

export type GalleryFilter =
  | "All Products"
  | "Dresses"
  | "Tops"
  | "Tunics"
  | "Co-ords"
  | "Skirts"
  | "Bottoms"
  | "Printed"
  | "Solid"
  | "Lace"
  | "Embroidered"
  | "Casual";

export interface GalleryProduct {
  id: string;
  title: string;
  image: ImageAsset;
  filters: readonly Exclude<GalleryFilter, "All Products">[];
  styleCode: string;
  category: string;
  fabric: string;
  availableSizes: string;
  approximatePriceRange: string;
  moq: string;
  colourOptions: string;
  note: string;
}

export interface FAQItem {
  id: string;
  question: string;
  answer: string;
}

export interface SelectOption {
  label: string;
  value: string;
}

export interface EnquiryField {
  id: string;
  name: string;
  label: string;
  type: FormFieldType;
  placeholder?: string;
  required: boolean;
  options?: readonly SelectOption[];
  accept?: string;
  helperText?: string;
  fullWidth?: boolean;
}

export interface CompanyProfileData {
  brand: {
    name: string;
    legalName: string;
    industry: string;
    specialisation: string;
    positioning: string;
    commercialRange: string;
    monthlyCapacity: string;
    sewingMachines: string;
    standardMoq: string;
    infrastructure: string;
    exportExperience: string;
  };
  seo: {
    title: string;
    description: string;
    keywords: readonly string[];
    canonicalUrl: string;
    openGraphImage: string;
    favicon: string;
  };
  imageFolders: readonly string[];
  navigation: readonly {
    label: string;
    href: string;
  }[];
  pageBanners: {
    about: ImageAsset;
    facilities: ImageAsset;
    products: ImageAsset;
    events: ImageAsset;
    qualityCompliance: ImageAsset;
    sustainability: ImageAsset;
    exportExperience: ImageAsset;
    awards: ImageAsset;
    contact: ImageAsset;
  };
  hero: {
    eyebrow: string;
    title: string;
    statement: string;
    statistics: readonly Statistic[];
    actions: readonly ActionLink[];
    image: ImageAsset;
    optionalVideo: {
      src: string;
      poster: string;
      label: string;
    };
  };
  introduction: {
    eyebrow: string;
    heading: string;
    paragraphs: readonly string[];
    buyerSupport: readonly string[];
    images: readonly ImageAsset[];
  };
  aboutJourney: {
    eyebrow: string;
    heading: string;
    introduction: string;
    items: readonly TimelineCard[];
  };
  clientAssociations: {
    eyebrow: string;
    heading: string;
    introduction: string;
    groups: readonly ClientLogoGroup[];
    disclaimer: string;
  };
  atAGlance: {
    heading: string;
    statistics: readonly Statistic[];
    disclaimer: string;
  };
  buyerDecisionFlow: {
    eyebrow: string;
    heading: string;
    introduction: string;
    steps: readonly BuyerDecisionStep[];
  };
  factories: {
    eyebrow: string;
    heading: string;
    introduction: string;
    profiles: readonly FactoryProfile[];
    comparisonPoints: readonly string[];
  };
  productCategories: {
    eyebrow: string;
    heading: string;
    introduction: string;
    items: readonly ProductCategory[];
  };
  manufacturingSupport: {
    eyebrow: string;
    heading: string;
    introduction: string;
    steps: readonly ProcessStep[];
  };
  development: {
    eyebrow: string;
    heading: string;
    introduction: string;
    capabilities: readonly CapabilityItem[];
    images: readonly ImageAsset[];
  };
  materials: {
    eyebrow: string;
    heading: string;
    introduction: string;
    fabricGroups: readonly string[];
    valueAdditions: readonly string[];
    images: readonly ImageAsset[];
    disclaimer: string;
  };
  production: {
    eyebrow: string;
    heading: string;
    introduction: string;
    steps: readonly ProcessStep[];
    operationalData: readonly EditableField[];
    images: readonly ImageAsset[];
  };
  quality: {
    eyebrow: string;
    heading: string;
    introduction: string;
    statement: string;
    processImage: ImageAsset;
    checkpoints: readonly QualityCheckpoint[];
    editableFields: readonly EditableField[];
    images: readonly ImageAsset[];
  };
  compliance: {
    eyebrow: string;
    heading: string;
    introduction: string;
    items: readonly ComplianceItem[];
    verificationFields: readonly EditableField[];
    images: readonly ImageAsset[];
  };
  exports: {
    eyebrow: string;
    heading: string;
    introduction: string;
    markets: readonly ExportMarket[];
    buyerSupport: readonly BuyerSupportCapability[];
    image: ImageAsset;
  };
  events: {
    eyebrow: string;
    heading: string;
    introduction: string;
    past: readonly EventItem[];
    future: readonly EventItem[];
  };
  award: {
    eyebrow: string;
    title: string;
    category: string;
    description: string;
    images: readonly ImageAsset[];
  };
  buyerSegments: {
    eyebrow: string;
    heading: string;
    introduction: string;
    items: readonly {
      id: string;
      title: string;
      description: string;
    }[];
    disclaimer: string;
  };
  reasonsToChoose: {
    eyebrow: string;
    heading: string;
    introduction: string;
    items: readonly {
      id: string;
      title: string;
      description: string;
    }[];
  };
  gallery: {
    eyebrow: string;
    heading: string;
    introduction: string;
    filters: readonly GalleryFilter[];
    products: readonly GalleryProduct[];
    enquiryLabel: string;
    loadMoreLabel: string;
  };
  faqs: {
    eyebrow: string;
    heading: string;
    items: readonly FAQItem[];
  };
  enquiry: {
    eyebrow: string;
    heading: string;
    introduction: string;
    emailTo: string;
    fields: readonly EnquiryField[];
    costingNote: string;
    consentLabel: string;
    submitLabel: string;
    successMessage: string;
  };
  contact: {
    heading: string;
    details: readonly EditableField[];
    socialMedia: readonly EditableField[];
    qrCode: ImageAsset;
  };
  closing: {
    heading: string;
    text: string;
    actions: readonly ActionLink[];
    image: ImageAsset;
  };
  downloads: {
    printLabel: string;
    downloadLabel: string;
    downloadPath: string;
  };
  footer: {
    strapline: string;
    legalLine: string;
    placeholderNotice: string;
  };
}

export const companyData: CompanyProfileData = {
  // VERIFIED CORE COMPANY INFORMATION
  brand: {
    name: "ESHA Apparels",
    legalName: "ESHA Apparels",
    industry: "Women’s garment manufacturing and export",
    specialisation: "Women’s western wear and fast-fashion garments",
    positioning:
      "Commercial, trend-focused, scalable and export-ready women’s fashion",
    commercialRange:
      "Approximately USD 3–12 FOB per piece, depending on style, fabric, workmanship and order volume",
    monthlyCapacity: "Up to 250,000 pieces",
    sewingMachines: "575 sewing machines",
    standardMoq:
      "Approximately 700 pieces per style, subject to fabric, design and order requirements",
    infrastructure: "Two manufacturing factories",
    exportExperience:
      "Experience supplying international buyers, including the Japanese market",
  },

  // EDIT: replace bracketed SEO URLs once the production domain and assets are ready.
  seo: {
    title: "ESHA Apparels | Women’s Fashion Manufacturing at Scale",
    description:
      "ESHA Apparels manufactures and exports commercial, trend-focused women’s western wear with two-factory infrastructure, 575 sewing machines and capacity of up to 250,000 pieces per month.",
    keywords: [
      "women’s garment manufacturer",
      "women’s apparel exporter",
      "women’s western wear",
      "fashion manufacturing",
      "garment export",
    ],
    canonicalUrl: "[Production website URL]",
    openGraphImage: "/images/hero/esha-apparels-open-graph.jpg",
    favicon: "/images/company/esha-apparels-favicon.svg",
  },

  imageFolders: [
    "/images/hero",
    "/images/company",
    "/images/factory-one",
    "/images/factory-two",
    "/images/products",
    "/images/fabrics",
    "/images/process",
    "/images/quality",
    "/images/award",
    "/images/team",
    "/images/export",
    "/images/contact",
  ],

  navigation: [
    { label: "Home", href: "/" },
    { label: "About", href: "/about" },
    { label: "Facilities", href: "/facilities" },
    { label: "Products", href: "/products" },
    { label: "Quality & Compliance", href: "/quality-compliance" },
    { label: "Sustainability", href: "/sustainability" },
    { label: "Export", href: "/export" },
    { label: "Events", href: "/events" },
    { label: "Awards", href: "/awards" },
    { label: "Contact", href: "/contact" },
  ],

  // EDIT: replace these route-specific banners independently from section imagery.
  pageBanners: {
    about: {
      src: "/images/company/company-studio.svg",
      alt: "Editable ESHA Apparels company and design studio banner",
      recommendedShot: "Wide team, office or design-studio photograph",
    },
    facilities: {
      src: "/images/factory-one/exterior.svg",
      alt: "Editable ESHA Apparels manufacturing facilities banner",
      recommendedShot: "Wide factory exterior or production-floor photograph",
    },
    products: {
      src: "/images/products/product-dress-01.svg",
      alt: "Editable ESHA Apparels women’s product categories banner",
      recommendedShot: "Wide garment campaign or collection photograph",
    },
    events: {
      src: "/images/team/closing-team-factory.jpg",
      alt: "Editable ESHA Apparels event, trade fair or buyer meeting banner",
      recommendedShot: "Wide event, trade fair, buyer meeting or award photograph",
    },
    qualityCompliance: {
      src: "/images/quality/measurement-check.svg",
      alt: "Editable ESHA Apparels quality and compliance banner",
      recommendedShot: "Wide measurement, stitching or inspection photograph",
    },
    sustainability: {
      src: "/images/factory-one/cutting-floor.svg",
      alt: "Editable ESHA Apparels responsible manufacturing banner",
      recommendedShot: "Wide material-optimisation or responsible-production image",
    },
    exportExperience: {
      src: "/images/export/export-map.svg",
      alt: "Editable ESHA Apparels export experience banner",
      recommendedShot: "Wide export, packing or international-sourcing image",
    },
    awards: {
      src: "/images/award/reliance-award-2022-23.svg",
      alt: "Editable Reliance Best Vendor Award banner",
      recommendedShot: "Wide award ceremony or certificate photograph",
    },
    contact: {
      src: "/images/contact/contact-atelier.svg",
      alt: "Editable ESHA Apparels buyer enquiry banner",
      recommendedShot: "Wide team, garment collection or buyer-meeting photograph",
    },
  },

  hero: {
    eyebrow: "Women’s garment manufacturing & export",
    title: "Women’s Fashion Manufacturing at Scale",
    statement:
      "From trend-focused product development to dependable bulk production, ESHA Apparels helps fashion businesses bring commercially relevant women’s collections to market.",
    statistics: [
      {
        id: "hero-capacity",
        value: "Up to 250,000",
        label: "Pieces monthly capacity",
      },
      {
        id: "hero-factories",
        value: "2",
        label: "Manufacturing factories",
      },
      {
        id: "hero-specialisation",
        value: "Women’s",
        label: "Western wear specialisation",
      },
      {
        id: "hero-export",
        value: "Export",
        label: "Focused production",
      },
    ],
    actions: [
      {
        label: "Explore Our Facilities",
        href: "/facilities",
        variant: "light",
      },
      {
        label: "Start a Buyer Enquiry",
        href: "/contact",
        variant: "primary",
      },
    ],
    image: {
      src: "/images/hero/hero-main.jpg",
      alt: "Recommended hero garment campaign or ESHA Apparels factory image",
      recommendedShot:
        "High-resolution portrait garment campaign, production floor or team image with clear space for text",
    },
    optionalVideo: {
      src: "[Add local hero background video path]",
      poster: "/images/hero/hero-video-poster.jpg",
      label: "Optional short garment or factory background film",
    },
  },

  introduction: {
    eyebrow: "Company profile",
    heading: "Built for Fashion. Structured for Scale.",
    paragraphs: [
      "ESHA Apparels is a women’s garment manufacturer and exporter focused on western wear, trend-driven collections and scalable production.",
      "Our operations are structured to help buyers move from a product brief to export-ready bulk production through coordinated development, commercial review and manufacturing support.",
    ],
    buyerSupport: [
      "Product development",
      "Fabric and trim selection",
      "Sampling",
      "Costing",
      "Bulk manufacturing",
      "Quality control",
      "Packing",
      "Export coordination",
    ],
    images: [
      {
        src: "/images/company/company-team.jpg",
        alt: "Recommended ESHA Apparels team photograph",
        recommendedShot: "Leadership, merchandising or cross-functional team",
      },
      {
        src: "/images/company/company-office.jpg",
        alt: "Recommended ESHA Apparels office photograph",
        recommendedShot: "Office, merchandising or buyer meeting area",
      },
      {
        src: "/images/company/company-factory-exterior.jpg",
        alt: "Recommended ESHA Apparels factory exterior photograph",
        recommendedShot: "Verified factory exterior with signage if available",
      },
      {
        src: "/images/company/company-design-studio.jpg",
        alt: "Recommended ESHA Apparels design studio photograph",
        recommendedShot: "Design, fabric review or product development workspace",
      },
    ],
  },

  aboutJourney: {
    eyebrow: "Past · Present · Future",
    heading: "A Company Built Through Consistent Progress",
    introduction:
      "ESHA Apparels’ profile is shaped by a practical manufacturing history, a stronger present-day production base and a future focused on becoming an even more valuable sourcing partner for international buyers.",
    items: [
      {
        id: "past",
        label: "Past",
        title: "Established with a hi-fashion manufacturing foundation",
        text:
          "The business profile records ESHA Apparels as an India-based hi-fashion garment manufacturer with year of inception 2007, working with domestic buyers and export markets including USA and Europe.",
        highlights: [
          "Year of inception: 2007",
          "India-based hi-fashion garment manufacturer",
          "Professional textile-industry team",
          "Two dedicated manufacturing units and one showroom",
        ],
      },
      {
        id: "present",
        label: "Present",
        title: "A stronger, buyer-ready manufacturing partner",
        text:
          "Today, ESHA Apparels combines women’s fashion specialisation with two Sitapura, Jaipur factories, a 50,000 sq. ft. manufacturing footprint, scalable monthly capacity and recognition from Reliance for vendor performance.",
        highlights: [
          "Women’s western wear and fast-fashion focus",
          "Two factories with up to 250,000 pieces monthly capacity",
          "575 sewing machines supporting scalable production",
          "Reliance Best Vendor recognition",
        ],
      },
      {
        id: "future",
        label: "Future",
        title: "Focused on sharper development and wider buyer confidence",
        text:
          "Looking ahead, ESHA Apparels is positioned to keep strengthening product development, quality documentation, buyer communication and responsible manufacturing practices for buyers who need commercial fashion with dependable execution.",
        highlights: [
          "Stronger trend-to-sample development support",
          "More structured buyer communication and documentation",
          "Expanded repeat-order and range-development support",
          "Practical progress in responsible manufacturing",
        ],
      },
    ],
  },

  clientAssociations: {
    eyebrow: "Buyer associations",
    heading: "Companies We Work With",
    introduction:
      "ESHA Apparels has worked with recognised national and international retail, catalogue and fashion-related companies. Logo usage should be reviewed before final publication.",
    groups: [
      {
        id: "national",
        title: "National Companies",
        description:
          "Selected national buyer and retail associations shared for the ESHA Apparels profile.",
        logos: [
          {
            id: "ethnicity",
            name: "Ethnicity",
            logo: {
              src: "/images/clients/ethnicity-logo.png",
              alt: "Ethnicity logo",
              recommendedShot: "National buyer logo",
            },
          },
          {
            id: "reliance-retail",
            name: "Reliance Retail",
            logo: {
              src: "/images/clients/reliance-retail-logo.svg",
              alt: "Reliance Retail logo",
              recommendedShot: "National buyer logo",
            },
          },
          {
            id: "dmart",
            name: "D-Mart",
            logo: {
              src: "/images/clients/dmart-logo.png",
              alt: "D-Mart logo",
              recommendedShot: "National buyer logo",
            },
          },
          {
            id: "firstcry",
            name: "FirstCry",
            logo: {
              src: "/images/clients/firstcry-logo.png",
              alt: "FirstCry logo",
              recommendedShot: "National buyer logo",
            },
          },
          {
            id: "siyarams",
            name: "Siyaram's",
            logo: {
              src: "/images/clients/siyarams-logo.webp",
              alt: "Siyaram's logo",
              recommendedShot: "National buyer logo",
            },
          },
          {
            id: "style-union",
            name: "Style Union",
            logo: {
              src: "/images/clients/style-union-logo.svg",
              alt: "Style Union logo",
              recommendedShot: "National buyer logo",
            },
          },
        ],
      },
      {
        id: "international",
        title: "International Companies",
        description:
          "Selected international buyer associations for export-oriented garment programmes.",
        logos: [
          {
            id: "amerimark-direct",
            name: "AmeriMark Direct LLC",
            logo: {
              src: "/images/clients/amerimark-direct-logo.png",
              alt: "AmeriMark Direct logo",
              recommendedShot: "International buyer logo",
            },
            note: "USA",
          },
          {
            id: "kmart",
            name: "Kmart",
            logo: {
              src: "/images/clients/kmart-logo.svg",
              alt: "Kmart logo",
              recommendedShot: "International buyer logo",
            },
            note: "USA",
          },
          {
            id: "eric-jay-ltd",
            name: "Eric Jay Ltd.",
            logo: {
              src: "/images/clients/eric-jay-ltd-wordmark.svg",
              alt: "Eric Jay Ltd. wordmark placeholder",
              recommendedShot:
                "Placeholder wordmark; replace with approved official logo if supplied",
            },
            note: "USA / Global",
          },
          {
            id: "marubeni",
            name: "Marubeni",
            logo: {
              src: "/images/clients/marubeni-logo.svg",
              alt: "Marubeni logo",
              recommendedShot: "International buyer logo",
            },
            note: "Japan",
          },
          {
            id: "primark",
            name: "Primark",
            logo: {
              src: "/images/clients/primark-wordmark.svg",
              alt: "Primark wordmark",
              recommendedShot:
                "European buyer logo; replace with approved official logo if supplied",
            },
            note: "Europe / UK",
          },
          {
            id: "peacocks",
            name: "Peacocks",
            logo: {
              src: "/images/clients/peacocks-wordmark.svg",
              alt: "Peacocks wordmark",
              recommendedShot:
                "European buyer logo; replace with approved official logo if supplied",
            },
            note: "Europe / UK",
          },
          {
            id: "george",
            name: "George",
            logo: {
              src: "/images/clients/george-wordmark.svg",
              alt: "George wordmark",
              recommendedShot:
                "European buyer logo; replace with approved official logo if supplied",
            },
            note: "Europe / UK",
          },
        ],
      },
    ],
    disclaimer:
      "Logo usage should be reviewed before publication. Add or remove company logos only after relationship and usage approval are confirmed.",
  },

  atAGlance: {
    heading: "ESHA Apparels at a Glance",
    statistics: [
      {
        id: "glance-factories",
        value: "2",
        label: "Manufacturing factories",
      },
      {
        id: "glance-capacity",
        value: "Up to 250,000",
        label: "Pieces per month",
      },
      {
        id: "glance-sewing-machines",
        value: "575",
        label: "Sewing machines",
      },
      {
        id: "glance-price",
        value: "USD 3–12",
        label: "Approximate FOB product range",
      },
      {
        id: "glance-moq",
        value: "Approx. 700",
        label: "Pieces per style standard MOQ",
      },
      {
        id: "glance-export",
        value: "International",
        label: "Export experience",
      },
      {
        id: "glance-focus",
        value: "Women’s fashion",
        label: "Manufacturing specialisation",
      },
    ],
    disclaimer:
      "Final pricing, MOQ and lead time depend on fabric availability, design complexity, order volume and finishing requirements.",
  },

  buyerDecisionFlow: {
    eyebrow: "Buyer decision flow",
    heading: "Evaluate ESHA Apparels in 30 Seconds",
    introduction:
      "A concise route through the information buyers usually check first: product fit, commercial range, production scale, quality process, export readiness and the next enquiry step.",
    steps: [
      {
        id: "decision-products",
        label: "What we make",
        title: "Women’s western wear and fast-fashion garments",
        description:
          "Dresses, tops, blouses, tunics, co-ords, skirts, bottoms, printed garments, lace-detail styles and value-added commercial fashion.",
        href: "/products",
        cta: "View product categories",
      },
      {
        id: "decision-commercial",
        label: "Commercial fit",
        title: "USD 3–12 approximate FOB positioning",
        description:
          "Pricing is reviewed against fabric, workmanship, order quantity, packing and finishing so buyers can assess feasibility early.",
        href: "/contact#contact",
        cta: "Share requirements",
      },
      {
        id: "decision-scale",
        label: "Scale",
        title: "Up to 250,000 pieces per month",
        description:
          "Two manufacturing factories and 575 sewing machines support scalable buyer programmes, subject to style mix and production planning.",
        href: "/facilities",
        cta: "Review facilities",
      },
      {
        id: "decision-quality",
        label: "Quality confidence",
        title: "Checks built through production",
        description:
          "Fabric review, pre-production alignment, in-line checks, finishing inspection and packing verification support controlled execution.",
        href: "/quality-compliance",
        cta: "See quality system",
      },
      {
        id: "decision-export",
        label: "Export readiness",
        title: "International sourcing support",
        description:
          "Export-oriented coordination supports buyer specifications, order tracking, packing instructions, documentation and market expectations.",
        href: "/export",
        cta: "Open export network",
      },
      {
        id: "decision-enquiry",
        label: "Next step",
        title: "Send a focused buyer enquiry",
        description:
          "Share product category, approximate quantity, buyer type and message so the ESHA Apparels team can evaluate the programme.",
        href: "/contact#contact",
        cta: "Start buyer enquiry",
      },
    ],
  },

  factories: {
    eyebrow: "Manufacturing infrastructure",
    heading: "Two Factories. One Integrated Production System.",
    introduction:
      "ESHA Apparels operates two dedicated manufacturing units in Sitapura, Jaipur, supported by one showroom. The business profile describes the manufacturing infrastructure as global-standard units equipped with modern machinery and technology.",
    profiles: [
      {
        id: "factory-one",
        number: "01",
        name: "Factory One",
        introduction:
          "Factory One is located in the E.P.I.P Garment Zone at Sitapura, Jaipur.",
        details: [
          {
            label: "Address",
            value: "G1-165, E.P.I.P, Garment Zone, Sitapura, Jaipur",
            status: "confirmed",
          },
          {
            label: "Area",
            value: "22,000 sq. ft.",
            status: "confirmed",
          },
          {
            label: "Unit type",
            value: "Dedicated manufacturing unit",
            status: "confirmed",
          },
          {
            label: "City",
            value: "Jaipur, India",
            status: "confirmed",
          },
        ],
        images: [
          {
            src: "/images/factory-one/factory-one-exterior.jpg",
            alt: "Recommended Factory One exterior photograph",
            recommendedShot: "Factory exterior",
          },
          {
            src: "/images/factory-one/factory-one-cutting-floor.jpg",
            alt: "Recommended Factory One cutting floor photograph",
            recommendedShot: "Cutting floor",
          },
          {
            src: "/images/factory-one/factory-one-production-line.jpg",
            alt: "Recommended Factory One stitching line photograph",
            recommendedShot: "Stitching lines",
          },
          {
            src: "/images/factory-one/factory-one-finishing-section.jpg",
            alt: "Recommended Factory One finishing section photograph",
            recommendedShot: "Finishing section",
          },
          {
            src: "/images/factory-one/factory-one-packing-area.jpg",
            alt: "Recommended Factory One packing area photograph",
            recommendedShot: "Packing area",
          },
        ],
      },
      {
        id: "factory-two",
        number: "02",
        name: "Factory Two",
        introduction:
          "Factory Two is located in Sitapura, near Bombay Hospital, Jaipur.",
        details: [
          {
            label: "Address",
            value: "1282, Sitapura, near Bombay Hospital, Jaipur",
            status: "confirmed",
          },
          {
            label: "Area",
            value: "28,000 sq. ft.",
            status: "confirmed",
          },
          {
            label: "Unit type",
            value: "Dedicated manufacturing unit",
            status: "confirmed",
          },
          {
            label: "City",
            value: "Jaipur, India",
            status: "confirmed",
          },
        ],
        images: [
          {
            src: "/images/factory-two/factory-two-exterior.jpg",
            alt: "Recommended Factory Two exterior photograph",
            recommendedShot: "Factory exterior",
          },
          {
            src: "/images/factory-two/factory-two-production-floor.jpg",
            alt: "Recommended Factory Two production floor photograph",
            recommendedShot: "Production floor",
          },
          {
            src: "/images/factory-two/factory-two-sampling-department.jpg",
            alt: "Recommended Factory Two sampling department photograph",
            recommendedShot: "Sampling department",
          },
          {
            src: "/images/factory-two/factory-two-inspection-area.jpg",
            alt: "Recommended Factory Two inspection area photograph",
            recommendedShot: "Inspection area",
          },
          {
            src: "/images/factory-two/factory-two-dispatch-area.jpg",
            alt: "Recommended Factory Two dispatch area photograph",
            recommendedShot: "Dispatch area",
          },
        ],
      },
    ],
    comparisonPoints: [
      "Two dedicated manufacturing units",
      "One showroom",
      "Combined production area of 50,000 sq. ft.",
      "Sitapura, Jaipur manufacturing base",
      "Dedicated production planning",
      "Parallel order handling",
      "Flexible style allocation",
      "Quality standardisation",
      "Production-risk management",
    ],
  },

  productCategories: {
    eyebrow: "Product portfolio",
    heading: "Commercial Women’s Fashion, Developed for Your Market",
    introduction:
      "ESHA Apparels supports a broad women’s western-wear portfolio. Fabric, styling, construction and value additions are evaluated against the buyer brief, order quantity and production requirements.",
    items: [
      {
        id: "dresses",
        name: "Dresses",
        description:
          "Commercial day, casual and collection-led dress concepts developed around the buyer’s silhouette and market brief.",
        fabrics: ["Cotton", "Rayon", "Viscose", "Printed woven fabrics"],
        customisation:
          "Length, sleeve, neckline, print, trim and construction details can be reviewed for custom development.",
        image: {
          src: "/images/products/category-dresses.jpg",
          alt: "Recommended women’s dress category photograph",
          recommendedShot: "Full-length portrait dress image",
        },
        layout: "feature",
      },
      {
        id: "tops-blouses",
        name: "Tops and blouses",
        description:
          "Versatile woven tops and blouses suited to retail and coordinated range development.",
        fabrics: ["Cotton dobby", "Cotton slub", "Viscose", "Textured fabrics"],
        customisation:
          "Necklines, sleeves, plackets, trims and surface details can be adapted to the approved brief.",
        image: {
          src: "/images/products/category-tops-and-blouses.jpg",
          alt: "Recommended women’s tops and blouses category photograph",
          recommendedShot: "Editorial portrait or styled flat lay",
        },
        layout: "portrait",
      },
      {
        id: "tunics",
        name: "Tunics",
        description:
          "Relaxed and structured tunic options with commercially adaptable proportions and detailing.",
        fabrics: ["Cotton", "Cotton flax", "Rayon", "Lightweight summer fabrics"],
        customisation:
          "Length, side openings, yokes, sleeves and decorative elements can be developed to specification.",
        image: {
          src: "/images/products/category-tunics.jpg",
          alt: "Recommended women’s tunic category photograph",
          recommendedShot: "Portrait garment image showing silhouette",
        },
        layout: "landscape",
      },
      {
        id: "coord-sets",
        name: "Co-ord sets",
        description:
          "Coordinated tops and bottoms designed as commercially cohesive sets or separable range pieces.",
        fabrics: ["Cotton", "Viscose", "Linen blends", "Printed woven fabrics"],
        customisation:
          "Top-to-bottom proportion, colour, print placement and mix-and-match options can be reviewed.",
        image: {
          src: "/images/products/category-co-ord-sets.jpg",
          alt: "Recommended women’s co-ord set category photograph",
          recommendedShot: "Full coordinated outfit",
        },
        layout: "split",
      },
      {
        id: "skirts",
        name: "Skirts",
        description:
          "Commercial skirt silhouettes ranging from clean everyday styles to tiered and printed options.",
        fabrics: ["Cotton", "Rayon", "Viscose", "Textured fabrics"],
        customisation:
          "Length, waistband, volume, panel, tier and closure options can be evaluated.",
        image: {
          src: "/images/products/category-skirts.jpg",
          alt: "Recommended women’s skirt category photograph",
          recommendedShot: "Movement-led portrait or detailed flat lay",
        },
        layout: "portrait",
      },
      {
        id: "bottoms",
        name: "Bottoms",
        description:
          "Women’s woven bottoms developed for coordinated collections and everyday commercial ranges.",
        fabrics: ["Cotton", "Cotton flax", "Linen blends", "Textured fabrics"],
        customisation:
          "Fit, rise, leg shape, waistband and pocket construction can be developed from the buyer brief.",
        image: {
          src: "/images/products/category-bottoms.jpg",
          alt: "Recommended women’s bottoms category photograph",
          recommendedShot: "Full-length styling image showing fit",
        },
        layout: "landscape",
      },
      {
        id: "casual-western-wear",
        name: "Casual western wear",
        description:
          "Easy, trend-aware styles developed for commercially relevant everyday collections.",
        fabrics: ["Cotton slub", "Rayon", "Viscose", "Lightweight summer fabrics"],
        customisation:
          "Silhouette, wash, colour, print and trim direction can be aligned to buyer requirements.",
        image: {
          src: "/images/products/category-casual-western-wear.jpg",
          alt: "Recommended casual western wear category photograph",
          recommendedShot: "Lifestyle or clean lookbook image",
        },
        layout: "feature",
      },
      {
        id: "occasion-commercial",
        name: "Occasion-inspired commercial styles",
        description:
          "Elevated but commercially considered styles using detail, proportion and value addition.",
        fabrics: ["Viscose", "Textured fabrics", "Printed woven fabrics"],
        customisation:
          "Detail level, construction and workmanship can be cost-engineered for the agreed positioning.",
        image: {
          src: "/images/products/category-occasion-inspired.jpg",
          alt: "Recommended occasion-inspired commercial style photograph",
          recommendedShot: "Elevated portrait with workmanship visible",
        },
        layout: "feature",
      },
      {
        id: "tiered-garments",
        name: "Tiered garments",
        description:
          "Dresses, skirts and tunics developed with controlled volume, gathering and tier construction.",
        fabrics: ["Cotton", "Rayon", "Viscose", "Lightweight summer fabrics"],
        customisation:
          "Tier count, placement, fullness, length and seam detailing can be adjusted to the style.",
        image: {
          src: "/images/products/category-tiered-garments.jpg",
          alt: "Recommended tiered women’s garment photograph",
          recommendedShot: "Movement image clearly showing tier construction",
        },
        layout: "landscape",
      },
      {
        id: "printed-garments",
        name: "Printed garments",
        description:
          "Print-led dresses, tops, tunics, skirts and sets coordinated to the buyer’s collection direction.",
        fabrics: ["Printed woven fabrics", "Cotton", "Rayon", "Viscose"],
        customisation:
          "Print selection, scale, colourway and placement are subject to sourcing, MOQ and approval.",
        image: {
          src: "/images/products/category-printed-garments.jpg",
          alt: "Recommended printed women’s garment photograph",
          recommendedShot: "Colour-accurate image with print scale visible",
        },
        layout: "split",
      },
      {
        id: "lace-detail-garments",
        name: "Lace-detail garments",
        description:
          "Commercial silhouettes enhanced with considered lace placement and feminine detailing.",
        fabrics: ["Cotton", "Cotton dobby", "Rayon", "Textured fabrics"],
        customisation:
          "Lace type, placement, width, colour and construction can be developed subject to availability.",
        image: {
          src: "/images/products/category-lace-detail-garments.jpg",
          alt: "Recommended lace-detail women’s garment photograph",
          recommendedShot: "Close editorial crop showing lace workmanship",
        },
        layout: "portrait",
      },
      {
        id: "embroidered-value-added",
        name: "Embroidered and value-added styles",
        description:
          "Styles incorporating embroidery or selected surface details to build commercial visual value.",
        fabrics: ["Cotton", "Viscose", "Linen blends", "Textured fabrics"],
        customisation:
          "Motif, placement, thread, trim and workmanship are reviewed against cost and production needs.",
        image: {
          src: "/images/products/category-embroidered-value-added.jpg",
          alt: "Recommended embroidered or value-added garment photograph",
          recommendedShot: "Detail-led image showing embroidery quality",
        },
        layout: "feature",
      },
    ],
  },

  manufacturingSupport: {
    eyebrow: "End-to-end support",
    heading: "From Buyer Brief to Shipment Coordination",
    introduction:
      "A clear development and manufacturing workflow helps align product, quality, price and delivery requirements before bulk execution.",
    steps: [
      {
        id: "buyer-enquiry",
        number: "01",
        title: "Buyer enquiry and brief",
        description:
          "Review product category, design direction, quantity and order needs.",
      },
      {
        id: "trend-discussion",
        number: "02",
        title: "Trend and product discussion",
        description:
          "Align the commercial direction, target customer and range priorities.",
      },
      {
        id: "fabric-sourcing",
        number: "03",
        title: "Fabric and trim sourcing",
        description:
          "Evaluate suitable materials and components against design, availability and cost.",
      },
      {
        id: "design-interpretation",
        number: "04",
        title: "Design interpretation",
        description:
          "Translate references, sketches or specifications into a manufacturable style direction.",
      },
      {
        id: "costing-review",
        number: "05",
        title: "Costing and commercial review",
        description:
          "Review fabric, workmanship, quantity, packing and target positioning.",
      },
      {
        id: "sampling-fit",
        number: "06",
        title: "Sampling and fit development",
        description:
          "Develop samples and incorporate agreed fit or construction corrections.",
      },
      {
        id: "order-confirmation",
        number: "07",
        title: "Order confirmation",
        description:
          "Confirm approved specifications, commercials, quantity and timeline.",
      },
      {
        id: "pre-production",
        number: "08",
        title: "Pre-production approval",
        description:
          "Align approved references, materials, measurements and packing instructions.",
      },
      {
        id: "manufacturing",
        number: "09",
        title: "Cutting and manufacturing",
        description:
          "Plan and execute bulk production against approved specifications.",
      },
      {
        id: "inline-quality",
        number: "10",
        title: "In-line quality checks",
        description:
          "Monitor measurements and workmanship during production so issues can be addressed early.",
      },
      {
        id: "final-inspection",
        number: "11",
        title: "Final inspection",
        description:
          "Review finished goods and relevant packing requirements before release.",
      },
      {
        id: "shipment-coordination",
        number: "12",
        title: "Packing and shipment coordination",
        description:
          "Coordinate approved packing, order documentation and export handover requirements.",
      },
    ],
  },

  development: {
    eyebrow: "Design & product development",
    heading: "Commercial Development Beyond the Finished Sketch",
    introduction:
      "ESHA Apparels can support the interpretation and development of women’s fashion briefs. The scope of creative and technical support is agreed for each programme and does not replace a buyer’s specialist trend-forecasting function.",
    capabilities: [
      {
        id: "reference-development",
        title: "Buyer reference development",
        description:
          "Interpret supplied references while respecting the agreed product brief and ownership requirements.",
      },
      {
        id: "mood-board",
        title: "Mood-board interpretation",
        description:
          "Translate visual direction into practical silhouette, material and detail discussions.",
      },
      {
        id: "trend-suggestions",
        title: "Trend-based design suggestions",
        description:
          "Offer commercially considered product suggestions within ESHA Apparels’ women’s wear focus.",
      },
      {
        id: "fabric-print",
        title: "Fabric and print coordination",
        description:
          "Coordinate suitable fabric and print directions subject to sourcing and approval.",
      },
      {
        id: "lace-trim",
        title: "Lace and trim development",
        description:
          "Review decorative components against construction, availability, MOQ and price.",
      },
      {
        id: "silhouette-adaptation",
        title: "Silhouette adaptation",
        description:
          "Adjust proportion and styling for the target range and technical feasibility.",
      },
      {
        id: "sample-development",
        title: "Sample development",
        description:
          "Create physical development samples from an agreed brief or specification.",
      },
      {
        id: "fit-corrections",
        title: "Fit corrections",
        description:
          "Incorporate approved measurement and construction comments during sampling.",
      },
      {
        id: "cost-engineering",
        title: "Cost engineering",
        description:
          "Explore practical material or construction options against the target positioning.",
      },
      {
        id: "value-addition",
        title: "Commercial value addition",
        description:
          "Use selected details to create visual interest without losing commercial focus.",
      },
      {
        id: "range-development",
        title: "Range development",
        description:
          "Coordinate related silhouettes, fabrics or details across a collection brief.",
      },
    ],
    images: [
      {
        src: "/images/process/development-sketches.jpg",
        alt: "Recommended product-development sketches photograph",
        recommendedShot: "Verified sketches or technical development pages",
      },
      {
        src: "/images/process/development-mood-board.jpg",
        alt: "Recommended fashion mood-board photograph",
        recommendedShot: "Mood board with no confidential buyer material",
      },
      {
        src: "/images/fabrics/development-fabric-swatches.jpg",
        alt: "Recommended development fabric swatches photograph",
        recommendedShot: "Colour-accurate fabric and print swatches",
      },
      {
        src: "/images/process/development-sample-room.jpg",
        alt: "Recommended sample-room photograph",
        recommendedShot: "Sample development activity",
      },
      {
        src: "/images/process/development-before-after.jpg",
        alt: "Recommended before-and-after product development example",
        recommendedShot: "Approved non-confidential reference and developed sample",
      },
    ],
  },

  materials: {
    eyebrow: "Fabrics & value additions",
    heading: "A Material Library Built Around the Product Brief",
    introduction:
      "Potential fabric and workmanship directions are reviewed for suitability, sourcing conditions, commercial target and production requirements.",
    fabricGroups: [
      "Cotton",
      "Cotton slub",
      "Cotton dobby",
      "Cotton flax",
      "Cotton salli",
      "Rayon",
      "Viscose",
      "Linen blends",
      "Printed woven fabrics",
      "Textured fabrics",
      "Lightweight summer fabrics",
      "Buyer-nominated fabrics",
    ],
    valueAdditions: [
      "Cotton lace",
      "Embroidery",
      "Frills",
      "Tiering",
      "Pintucks",
      "Gathers",
      "Smocking",
      "Fabric mixing",
      "Contrast panels",
      "Decorative buttons",
      "Trims",
      "Elasticated construction",
      "Surface detailing",
    ],
    images: [
      {
        src: "/images/fabrics/fabric-cotton-texture.jpg",
        alt: "Recommended cotton fabric close-up",
        recommendedShot: "Colour-accurate cotton texture macro",
      },
      {
        src: "/images/fabrics/fabric-printed-woven.jpg",
        alt: "Recommended printed woven fabric close-up",
        recommendedShot: "Print and weave shown at useful scale",
      },
      {
        src: "/images/fabrics/value-add-lace.jpg",
        alt: "Recommended cotton lace close-up",
        recommendedShot: "Lace construction and edge detail",
      },
      {
        src: "/images/fabrics/value-add-embroidery.jpg",
        alt: "Recommended embroidery close-up",
        recommendedShot: "Embroidery workmanship macro",
      },
      {
        src: "/images/fabrics/value-add-trims.jpg",
        alt: "Recommended garment trims photograph",
        recommendedShot: "Curated trims and decorative components",
      },
      {
        src: "/images/fabrics/value-add-tiering.jpg",
        alt: "Recommended tiered garment detail photograph",
        recommendedShot: "Seam, gathering and tier workmanship",
      },
    ],
    disclaimer:
      "Fabric, trim and value-addition availability may vary according to season, sourcing conditions, order quantity and buyer requirements.",
  },

  production: {
    eyebrow: "Production capability",
    heading: "From Approved Sample to Scalable Production",
    introduction:
      "Bulk production is organised around the approved product specification, material readiness, manufacturing plan and quality requirements.",
    steps: [
      {
        id: "fabric-inspection",
        number: "01",
        title: "Fabric inspection",
        description: "Review incoming fabric against applicable requirements.",
      },
      {
        id: "pattern-development",
        number: "02",
        title: "Pattern development",
        description: "Prepare or refine production patterns from approved inputs.",
      },
      {
        id: "marker-planning",
        number: "03",
        title: "Marker planning",
        description: "Plan marker placement for production requirements.",
      },
      {
        id: "cutting",
        number: "04",
        title: "Cutting",
        description: "Cut approved fabric according to the production marker.",
      },
      {
        id: "bundling",
        number: "05",
        title: "Bundling",
        description: "Organise cut components for controlled line movement.",
      },
      {
        id: "stitching",
        number: "06",
        title: "Stitching",
        description: "Assemble garments against approved construction details.",
      },
      {
        id: "inline-checking",
        number: "07",
        title: "In-line checking",
        description: "Check workmanship and relevant measurements during sewing.",
      },
      {
        id: "thread-trimming",
        number: "08",
        title: "Thread trimming",
        description: "Remove loose threads and prepare garments for finishing.",
      },
      {
        id: "finishing",
        number: "09",
        title: "Finishing",
        description: "Complete applicable finishing operations.",
      },
      {
        id: "measurement-inspection",
        number: "10",
        title: "Measurement inspection",
        description: "Verify relevant garment measurements against the approved reference.",
      },
      {
        id: "final-quality-check",
        number: "11",
        title: "Final quality check",
        description: "Review finished garments against agreed requirements.",
      },
      {
        id: "packing",
        number: "12",
        title: "Packing",
        description: "Pack goods according to confirmed buyer instructions.",
      },
      {
        id: "dispatch",
        number: "13",
        title: "Dispatch",
        description: "Coordinate completed goods for the agreed shipment handover.",
      },
    ],
    // EDIT: replace each bracketed value with verified operational data.
    operationalData: [
      {
        label: "Cutting tables",
        value: "[Number of cutting tables]",
        status: "verification-required",
      },
      {
        label: "Sewing machines",
        value: "575",
        status: "confirmed",
      },
      {
        label: "Production lines",
        value: "[Number of production lines]",
        status: "verification-required",
      },
      {
        label: "Daily output",
        value: "[Daily output]",
        status: "verification-required",
      },
      {
        label: "Sampling capacity",
        value: "[Sampling capacity]",
        status: "verification-required",
      },
      {
        label: "Lead time",
        value: "[Lead-time information]",
        status: "verification-required",
      },
    ],
    images: [
      {
        src: "/images/process/production-fabric-inspection.jpg",
        alt: "Recommended fabric inspection photograph",
        recommendedShot: "Fabric inspection activity",
      },
      {
        src: "/images/process/production-marker-cutting.jpg",
        alt: "Recommended marker planning and cutting photograph",
        recommendedShot: "Marker or cutting table",
      },
      {
        src: "/images/process/production-stitching-line.jpg",
        alt: "Recommended garment stitching line photograph",
        recommendedShot: "Active production line",
      },
      {
        src: "/images/process/production-inline-check.jpg",
        alt: "Recommended in-line garment check photograph",
        recommendedShot: "In-line workmanship review",
      },
      {
        src: "/images/process/production-finishing.jpg",
        alt: "Recommended garment finishing photograph",
        recommendedShot: "Finishing activity",
      },
      {
        src: "/images/process/production-packing-dispatch.jpg",
        alt: "Recommended packing and dispatch photograph",
        recommendedShot: "Finished packing or dispatch preparation",
      },
    ],
  },

  quality: {
    eyebrow: "Quality-control system",
    heading: "Quality Built into Every Stage",
    introduction:
      "Quality checkpoints are integrated through material review, pre-production alignment, manufacturing, finishing and packing.",
    statement:
      "Our quality processes are structured to identify and correct issues during production, rather than relying only on final inspection.",
    processImage: {
      src: "/images/quality/quality-control-process.jpeg",
      alt: "ESHA Apparels quality-control process flow from order receiving to shipment dispatch",
      recommendedShot:
        "Replace with the latest approved quality-control process chart if updated",
    },
    checkpoints: [
      {
        id: "qc-fabric",
        title: "Fabric inspection",
        description: "Review fabric against applicable order requirements.",
      },
      {
        id: "qc-pre-production",
        title: "Pre-production review",
        description:
          "Align approved references, construction, measurements and materials.",
      },
      {
        id: "qc-approved-sample",
        title: "Approved sample reference",
        description:
          "Use the applicable approved sample and comments as production references.",
      },
      {
        id: "qc-measurement",
        title: "Measurement verification",
        description: "Check relevant measurements during and after production.",
      },
      {
        id: "qc-inline",
        title: "In-line inspection",
        description: "Monitor workmanship while garments move through production.",
      },
      {
        id: "qc-workmanship",
        title: "Workmanship checking",
        description:
          "Review sewing, construction and applicable value-added details.",
      },
      {
        id: "qc-finishing",
        title: "Finishing inspection",
        description: "Check applicable finishing and presentation requirements.",
      },
      {
        id: "qc-final-random",
        title: "Final random inspection",
        description:
          "Conduct final inspection according to the agreed procedure.",
      },
      {
        id: "qc-packing",
        title: "Packing verification",
        description: "Review packing against confirmed buyer instructions.",
      },
      {
        id: "qc-documentation",
        title: "Documentation review",
        description: "Check applicable order and quality documentation.",
      },
    ],
    // EDIT: publish standards and partners only after documentary verification.
    editableFields: [
      {
        label: "AQL standard",
        value: "[AQL standard used]",
        status: "verification-required",
      },
      {
        label: "Testing partners",
        value: "[Testing partners]",
        status: "verification-required",
      },
      {
        label: "Inspection procedures",
        value: "[Inspection procedures]",
        status: "verification-required",
      },
      {
        label: "Buyer requirements",
        value: "[Buyer-specific quality requirements]",
        status: "verification-required",
      },
      {
        label: "Quality team",
        value: "[Quality team structure]",
        status: "verification-required",
      },
    ],
    images: [
      {
        src: "/images/quality/quality-stitching-check.jpg",
        alt: "Recommended garment stitching quality check photograph",
        recommendedShot: "Close-up workmanship review",
      },
      {
        src: "/images/quality/quality-measurement-check.jpg",
        alt: "Recommended garment measurement check photograph",
        recommendedShot: "Measurement verification with clear reference points",
      },
      {
        src: "/images/quality/quality-finishing-inspection.jpg",
        alt: "Recommended garment finishing inspection photograph",
        recommendedShot: "Finishing inspection activity",
      },
      {
        src: "/images/quality/quality-packing-verification.jpg",
        alt: "Recommended garment packing verification photograph",
        recommendedShot: "Packing method or carton verification",
      },
    ],
  },

  compliance: {
    eyebrow: "Compliance & responsible manufacturing",
    heading: "Responsible Production, Documented with Care",
    introduction:
      "ESHA Apparels maintains an awareness of responsible manufacturing expectations and can review buyer-specific compliance and documentation needs. Verified certifications and audit details should be added below before publication.",
    items: [
      {
        id: "responsible-awareness",
        title: "Responsible manufacturing awareness",
        description:
          "Consider responsible production expectations within operational planning.",
      },
      {
        id: "workplace-standards",
        title: "Workplace standards",
        description:
          "Support the review of applicable workplace requirements and verified records.",
      },
      {
        id: "buyer-compliance",
        title: "Buyer-specific compliance support",
        description:
          "Evaluate buyer compliance requirements against current factory capability and documentation.",
      },
      {
        id: "material-optimisation",
        title: "Material optimisation",
        description:
          "Consider material use and marker planning within production requirements.",
      },
      {
        id: "production-efficiency",
        title: "Production efficiency",
        description:
          "Plan workflow and allocation with attention to operational efficiency.",
      },
      {
        id: "waste-reduction",
        title: "Waste-reduction initiatives",
        description:
          "Add verified waste-reduction activity and measurable outcomes when available.",
      },
      {
        id: "sustainable-fabrics",
        title: "Sustainable fabric options",
        description:
          "Review available material options where sourcing, MOQ and buyer requirements permit.",
      },
      {
        id: "traceability",
        title: "Traceability and documentation support",
        description:
          "Support applicable traceability and documentation requests where available.",
      },
    ],
    // EDIT: do not add logos until the corresponding evidence and files are supplied.
    verificationFields: [
      {
        label: "Compliance certification",
        value: "[Compliance certification]",
        status: "verification-required",
      },
      {
        label: "Social audit",
        value: "[Social audit]",
        status: "verification-required",
      },
      {
        label: "Environmental certification",
        value: "[Environmental certification]",
        status: "verification-required",
      },
      {
        label: "Factory audit status",
        value: "[Factory audit status]",
        status: "verification-required",
      },
      {
        label: "Sustainability initiative",
        value: "[Sustainability initiative]",
        status: "verification-required",
      },
      {
        label: "Waste management",
        value: "[Waste management system]",
        status: "verification-required",
      },
      {
        label: "Renewable energy",
        value: "[Renewable energy usage]",
        status: "verification-required",
      },
      {
        label: "Water saving",
        value: "[Water-saving programme]",
        status: "verification-required",
      },
    ],
    images: [
      {
        src: "/images/process/compliance-responsible-production.jpg",
        alt: "Recommended responsible manufacturing photograph",
        recommendedShot:
          "Verified workplace, material optimisation or waste-reduction activity",
      },
    ],
  },

  exports: {
    eyebrow: "Export & buyer experience",
    heading: "Designed for International Sourcing Requirements",
    introduction:
      "ESHA Apparels has experience supporting export-oriented production for international buyers, including the Japanese market. Product specifications, quality expectations, documentation and commercial timelines are reviewed for each programme.",
    markets: [
      {
        id: "market-india",
        country: "India",
        status: "confirmed",
        note: "Manufacturing base / origin market",
        company: "ESHA Apparels",
        designName: "Manufacturing Origin",
        fabric: "Women’s woven fashion",
        productionNote: "Design, sampling and bulk production base",
        image: {
          src: "/images/products/product-coord-01.jpg",
          alt: "Representative ESHA Apparels women’s co-ord garment for India manufacturing origin",
          recommendedShot:
            "Replace with a verified garment or factory-linked product image for India origin",
        },
      },
      {
        id: "market-usa",
        country: "USA",
        status: "verification-required",
        note: "Highlighted buyer/export market; confirm status before publication",
        company: "AmeriMark Direct LLC · Kmart · Eric Jay Ltd.",
        designName: "Commercial Woven Dress",
        fabric: "Printed woven fabric",
        productionNote: "Export-oriented buyer programme",
        image: {
          src: "/images/products/product-dress-02.jpg",
          alt: "Representative women’s woven dress for USA export market",
          recommendedShot:
            "Replace with approved USA-market garment image and verified product details",
        },
      },
      {
        id: "market-japan",
        country: "Japan",
        status: "confirmed",
        note: "Confirmed export-market experience",
        company: "Marubeni",
        designName: "Printed Cotton Midi Dress",
        fabric: "Cotton Slub",
        productionNote: "Bulk export programme",
        image: {
          src: "/images/products/product-dress-01.jpg",
          alt: "Representative printed cotton midi dress for Japan export market",
          recommendedShot:
            "Replace with approved Japan-market garment image and verified product details",
        },
      },
      {
        id: "market-uk",
        country: "UK",
        status: "verification-required",
        note: "Highlighted Europe / UK market; confirm status before publication",
        company: "Primark · Peacocks · George",
        designName: "Retail Range Top",
        fabric: "Viscose / Cotton blend",
        productionNote: "Commercial retail range review",
        image: {
          src: "/images/products/product-top-01.jpg",
          alt: "Representative women’s top for UK and Europe export market",
          recommendedShot:
            "Replace with approved UK-market garment image and verified product details",
        },
      },
      {
        id: "market-south-africa",
        country: "South Africa",
        status: "verification-required",
        note: "Highlighted buyer/export market; confirm status before publication",
        company: "[Buyer / company name]",
        designName: "Casual Western Tunic",
        fabric: "Rayon",
        productionNote: "Buyer-market programme to be verified",
        image: {
          src: "/images/products/product-tunic-01.jpg",
          alt: "Representative women’s tunic for South Africa export market",
          recommendedShot:
            "Replace with approved South Africa-market garment image and verified product details",
        },
      },
      {
        id: "market-placeholder-03",
        country: "[Country]",
        status: "verification-required",
        note: "[Add only after export history is verified]",
        company: "[Buyer / company name]",
        designName: "[Design name]",
        fabric: "[Fabric name]",
        productionNote: "[Production note]",
        image: {
          src: "/images/products/product-skirt-01.jpg",
          alt: "Placeholder garment image for future export market",
          recommendedShot:
            "Replace with approved garment image after export market is verified",
        },
      },
      {
        id: "market-placeholder-04",
        country: "[Country]",
        status: "verification-required",
        note: "[Add only after export history is verified]",
        company: "[Buyer / company name]",
        designName: "[Design name]",
        fabric: "[Fabric name]",
        productionNote: "[Production note]",
        image: {
          src: "/images/products/product-bottom-01.jpg",
          alt: "Placeholder garment image for future export market",
          recommendedShot:
            "Replace with approved garment image after export market is verified",
        },
      },
    ],
    // EDIT: confirm each service operationally before changing its status.
    buyerSupport: [
      {
        id: "support-english",
        title: "English-language communication",
        verification: "[Confirm current availability]",
        status: "verification-required",
      },
      {
        id: "support-sampling",
        title: "Sampling coordination",
        verification: "[Confirm current process]",
        status: "verification-required",
      },
      {
        id: "support-tracking",
        title: "Order tracking",
        verification: "[Confirm current process]",
        status: "verification-required",
      },
      {
        id: "support-packing",
        title: "Packing instructions",
        verification: "[Confirm current capability]",
        status: "verification-required",
      },
      {
        id: "support-labelling",
        title: "Labelling requirements",
        verification: "[Confirm current capability]",
        status: "verification-required",
      },
      {
        id: "support-barcode",
        title: "Barcode and tag support",
        verification: "[Confirm current capability]",
        status: "verification-required",
      },
      {
        id: "support-documents",
        title: "Export documentation coordination",
        verification: "[Confirm current process]",
        status: "verification-required",
      },
      {
        id: "support-quality-manual",
        title: "Buyer-specific quality manuals",
        verification: "[Confirm current capability]",
        status: "verification-required",
      },
      {
        id: "support-product-data",
        title: "Product data sharing",
        verification: "[Confirm current capability]",
        status: "verification-required",
      },
    ],
    image: {
      src: "/images/export/export-world-map-natural-india-usa-japan.svg",
      alt: "World map highlighting India, USA, Japan, UK and South Africa for ESHA Apparels export and buyer-market focus",
      recommendedShot:
        "Full world map artwork highlighting India, USA, Japan, UK and South Africa; add countries only after verification",
    },
  },

  events: {
    eyebrow: "Events",
    heading: "Past Participation and Upcoming Opportunities",
    introduction:
      "Use this page to present trade fairs, buyer meetings, sourcing events, award ceremonies and future participation plans in one clear buyer-facing view.",
    past: [
      {
        id: "past-event-reliance-award",
        title: "Reliance vendor recognition",
        period: "2022–2023",
        description:
          "ESHA Apparels received Reliance Best Vendor / Best Vendor Performance recognition, supporting the company’s profile as a dependable garment manufacturing partner.",
        status: "confirmed",
      },
    ],
    future: [
      {
        id: "future-event-india-apparel-accessories-fair-2026",
        title: "India Apparel & Accessories Fair 2026",
        period: "29–31 July 2026",
        description:
          "ESHA Apparels will participate in the India Apparel & Accessories Fair 2026 at Shinjuku Sumitomo Building Triangle Square, Tokyo, Japan. Visit Booth No. 11 to discuss women’s garment manufacturing, export-ready production and upcoming buyer requirements.",
        status: "confirmed",
      },
    ],
  },

  award: {
    eyebrow: "Award & recognition",
    title: "Reliance Best Vendor Award 2022–23",
    category: "Best Vendor Performance 2022–2023 · Mass-Wovens Category",
    description:
      "ESHA Apparels was recognised by Reliance for vendor performance during the 2022–2023 period. This recognition supports ESHA Apparels’ positioning as a dependable women’s garment manufacturing partner for buyer-led programmes.",
    images: [
      {
        src: "/images/award/reliance-best-vendor-award-2022-23.jpeg",
        alt: "Reliance Best Vendor Performance 2022–2023 award trophy and certificate for ESHA Apparels",
        recommendedShot: "Reliance award trophy and certificate",
      },
      {
        src: "/images/award/reliance-award-team-ceremony.jpg",
        alt: "ESHA Apparels team member holding the Reliance award at the ceremony",
        recommendedShot: "Award ceremony photograph",
      },
    ],
  },

  buyerSegments: {
    eyebrow: "Buyer segments",
    heading: "Manufacturing Solutions for Different Stages of Growth",
    introduction:
      "ESHA Apparels can evaluate programmes from established sourcing organisations and commercially ready developing businesses.",
    items: [
      {
        id: "retail-chains",
        title: "Retail chains",
        description: "Category and collection programmes assessed by brief.",
      },
      {
        id: "fashion-brands",
        title: "Fashion brands",
        description: "Brand-led women’s wear development and production.",
      },
      {
        id: "importers",
        title: "Importers",
        description: "Export-oriented product and order coordination.",
      },
      {
        id: "distributors",
        title: "Distributors",
        description: "Commercial ranges evaluated for the target market.",
      },
      {
        id: "buying-houses",
        title: "Buying houses",
        description: "Specification-led development and manufacturing support.",
      },
      {
        id: "wholesalers",
        title: "Wholesalers",
        description: "Scalable commercial fashion programmes.",
      },
      {
        id: "department-stores",
        title: "Department stores",
        description: "Buyer-specific category opportunities reviewed by range.",
      },
      {
        id: "ecommerce",
        title: "E-commerce fashion businesses",
        description: "Trend-focused product briefs assessed for feasible volume.",
      },
      {
        id: "emerging-brands",
        title: "Emerging brands",
        description:
          "Commercially viable orders reviewed against standard MOQ and development needs.",
      },
    ],
    disclaimer:
      "Order feasibility depends on product type, quantity and development requirements. This list describes buyer types ESHA Apparels can evaluate; it does not imply an existing supply relationship with every segment.",
  },

  reasonsToChoose: {
    eyebrow: "Why ESHA Apparels",
    heading: "Built Around Buyer Decisions, Not Just Capacity",
    introduction:
      "A buyer-focused manufacturing proposition built around price fit, category depth, repeatable scale and controlled execution.",
    items: [
      {
        id: "reason-two-factories",
        title: "Factory allocation clarity",
        description:
          "The two-factory setup helps allocate styles, schedules and order flow without presenting unverified factory specialisations.",
      },
      {
        id: "reason-capacity",
        title: "Repeat-order scale",
        description:
          "Two factories, 575 sewing machines and monthly capacity up to 250,000 pieces support planned repeat programmes where style mix and line planning allow.",
      },
      {
        id: "reason-specialisation",
        title: "Women’s category focus",
        description:
          "Development, sampling and production conversations stay centred on women’s western wear, fast-fashion silhouettes, prints, lace, tiering and value-added details.",
      },
      {
        id: "reason-positioning",
        title: "Price discipline from the start",
        description:
          "USD 3–12 FOB positioning is reviewed against fabric, workmanship, quantity and packing so buyers can assess commercial fit early.",
      },
      {
        id: "reason-development",
        title: "Development to approved sample",
        description:
          "Buyer references are interpreted through fabric, trim, fit and costing review before moving toward approved samples.",
      },
      {
        id: "reason-export",
        title: "Export communication",
        description:
          "Sampling coordination, order tracking, packing instructions, labelling requirements and documentation support are managed programme by programme.",
      },
      {
        id: "reason-quality",
        title: "Quality before final inspection",
        description:
          "Fabric review, pre-production alignment, in-line checks, finishing and packing checks help catch issues during production.",
      },
      {
        id: "reason-feasibility",
        title: "Commercial feasibility discipline",
        description:
          "MOQ, lead time and price are qualified against fabric availability, design complexity, order volume and finishing needs before commitment.",
      },
    ],
  },

  gallery: {
    eyebrow: "Selected collections",
    heading: "A Flexible Gallery for Current Product Development",
    introduction:
      "Replace the labelled placeholders with approved garment photography and verified style details. The data structure can be extended to 50–100 or more products without changing the field format.",
    filters: [
      "All Products",
      "Dresses",
      "Tops",
      "Tunics",
      "Co-ords",
      "Skirts",
      "Bottoms",
      "Printed",
      "Solid",
      "Lace",
      "Embroidered",
      "Casual",
    ],
    // EDIT: every gallery record below is a placeholder, not a live product claim.
    products: [
      {
        id: "gallery-product-001",
        title: "[Product name 01]",
        image: {
          src: "/images/products/product-dress-01.jpg",
          alt: "Placeholder for women’s printed dress style 01",
          recommendedShot: "Portrait garment photograph showing full silhouette",
        },
        filters: ["Dresses", "Printed", "Casual"],
        styleCode: "[Style code 01]",
        category: "Dresses",
        fabric: "[Fabric]",
        availableSizes: "[Available sizes]",
        approximatePriceRange: "[Approximate FOB price range]",
        moq: "[MOQ]",
        colourOptions: "[Colour options]",
        note: "[Short product note]",
      },
      {
        id: "gallery-product-002",
        title: "[Product name 02]",
        image: {
          src: "/images/products/product-top-01.jpg",
          alt: "Placeholder for women’s solid top style 01",
          recommendedShot: "Portrait or on-model top photograph",
        },
        filters: ["Tops", "Solid", "Casual"],
        styleCode: "[Style code 02]",
        category: "Tops",
        fabric: "[Fabric]",
        availableSizes: "[Available sizes]",
        approximatePriceRange: "[Approximate FOB price range]",
        moq: "[MOQ]",
        colourOptions: "[Colour options]",
        note: "[Short product note]",
      },
      {
        id: "gallery-product-003",
        title: "[Product name 03]",
        image: {
          src: "/images/products/product-tunic-01.jpg",
          alt: "Placeholder for women’s lace-detail tunic style 01",
          recommendedShot: "Portrait garment photograph with trim visible",
        },
        filters: ["Tunics", "Lace", "Solid"],
        styleCode: "[Style code 03]",
        category: "Tunics",
        fabric: "[Fabric]",
        availableSizes: "[Available sizes]",
        approximatePriceRange: "[Approximate FOB price range]",
        moq: "[MOQ]",
        colourOptions: "[Colour options]",
        note: "[Short product note]",
      },
      {
        id: "gallery-product-004",
        title: "[Product name 04]",
        image: {
          src: "/images/products/product-coord-01.jpg",
          alt: "Placeholder for women’s printed co-ord set style 01",
          recommendedShot: "Full outfit image showing both coordinated pieces",
        },
        filters: ["Co-ords", "Printed"],
        styleCode: "[Style code 04]",
        category: "Co-ords",
        fabric: "[Fabric]",
        availableSizes: "[Available sizes]",
        approximatePriceRange: "[Approximate FOB price range]",
        moq: "[MOQ]",
        colourOptions: "[Colour options]",
        note: "[Short product note]",
      },
      {
        id: "gallery-product-005",
        title: "[Product name 05]",
        image: {
          src: "/images/products/product-skirt-01.jpg",
          alt: "Placeholder for women’s tiered skirt style 01",
          recommendedShot: "Portrait or movement image showing skirt shape",
        },
        filters: ["Skirts", "Printed", "Casual"],
        styleCode: "[Style code 05]",
        category: "Skirts",
        fabric: "[Fabric]",
        availableSizes: "[Available sizes]",
        approximatePriceRange: "[Approximate FOB price range]",
        moq: "[MOQ]",
        colourOptions: "[Colour options]",
        note: "[Short product note]",
      },
      {
        id: "gallery-product-006",
        title: "[Product name 06]",
        image: {
          src: "/images/products/product-bottom-01.jpg",
          alt: "Placeholder for women’s solid bottom style 01",
          recommendedShot: "Full-length image showing fit and leg shape",
        },
        filters: ["Bottoms", "Solid", "Casual"],
        styleCode: "[Style code 06]",
        category: "Bottoms",
        fabric: "[Fabric]",
        availableSizes: "[Available sizes]",
        approximatePriceRange: "[Approximate FOB price range]",
        moq: "[MOQ]",
        colourOptions: "[Colour options]",
        note: "[Short product note]",
      },
      {
        id: "gallery-product-007",
        title: "[Product name 07]",
        image: {
          src: "/images/products/product-dress-02.jpg",
          alt: "Placeholder for women’s embroidered dress style 02",
          recommendedShot: "Portrait image with embroidery detail visible",
        },
        filters: ["Dresses", "Embroidered"],
        styleCode: "[Style code 07]",
        category: "Dresses",
        fabric: "[Fabric]",
        availableSizes: "[Available sizes]",
        approximatePriceRange: "[Approximate FOB price range]",
        moq: "[MOQ]",
        colourOptions: "[Colour options]",
        note: "[Short product note]",
      },
      {
        id: "gallery-product-008",
        title: "[Product name 08]",
        image: {
          src: "/images/products/product-top-02.jpg",
          alt: "Placeholder for women’s printed blouse style 02",
          recommendedShot: "Clean on-model or flat-lay image",
        },
        filters: ["Tops", "Printed"],
        styleCode: "[Style code 08]",
        category: "Tops",
        fabric: "[Fabric]",
        availableSizes: "[Available sizes]",
        approximatePriceRange: "[Approximate FOB price range]",
        moq: "[MOQ]",
        colourOptions: "[Colour options]",
        note: "[Short product note]",
      },
      {
        id: "gallery-product-009",
        title: "[Product name 09]",
        image: {
          src: "/images/products/product-tunic-02.jpg",
          alt: "Placeholder for women’s embroidered tunic style 02",
          recommendedShot: "Full garment image with embroidery in focus",
        },
        filters: ["Tunics", "Embroidered", "Casual"],
        styleCode: "[Style code 09]",
        category: "Tunics",
        fabric: "[Fabric]",
        availableSizes: "[Available sizes]",
        approximatePriceRange: "[Approximate FOB price range]",
        moq: "[MOQ]",
        colourOptions: "[Colour options]",
        note: "[Short product note]",
      },
      {
        id: "gallery-product-010",
        title: "[Product name 10]",
        image: {
          src: "/images/products/product-coord-02.jpg",
          alt: "Placeholder for women’s solid co-ord set style 02",
          recommendedShot: "Full coordinated outfit in a portrait frame",
        },
        filters: ["Co-ords", "Solid", "Casual"],
        styleCode: "[Style code 10]",
        category: "Co-ords",
        fabric: "[Fabric]",
        availableSizes: "[Available sizes]",
        approximatePriceRange: "[Approximate FOB price range]",
        moq: "[MOQ]",
        colourOptions: "[Colour options]",
        note: "[Short product note]",
      },
      {
        id: "gallery-product-011",
        title: "[Product name 11]",
        image: {
          src: "/images/products/product-skirt-02.jpg",
          alt: "Placeholder for women’s lace-detail skirt style 02",
          recommendedShot: "Portrait image with lace placement visible",
        },
        filters: ["Skirts", "Lace"],
        styleCode: "[Style code 11]",
        category: "Skirts",
        fabric: "[Fabric]",
        availableSizes: "[Available sizes]",
        approximatePriceRange: "[Approximate FOB price range]",
        moq: "[MOQ]",
        colourOptions: "[Colour options]",
        note: "[Short product note]",
      },
      {
        id: "gallery-product-012",
        title: "[Product name 12]",
        image: {
          src: "/images/products/product-bottom-02.jpg",
          alt: "Placeholder for women’s printed bottom style 02",
          recommendedShot: "Full-length image showing print and fit",
        },
        filters: ["Bottoms", "Printed"],
        styleCode: "[Style code 12]",
        category: "Bottoms",
        fabric: "[Fabric]",
        availableSizes: "[Available sizes]",
        approximatePriceRange: "[Approximate FOB price range]",
        moq: "[MOQ]",
        colourOptions: "[Colour options]",
        note: "[Short product note]",
      },
      {
        id: "gallery-product-013",
        title: "[Product name 13]",
        image: {
          src: "/images/products/product-dress-03.jpg",
          alt: "Placeholder for women’s lace-detail dress style 03",
          recommendedShot: "Editorial portrait with garment detail preserved",
        },
        filters: ["Dresses", "Lace"],
        styleCode: "[Style code 13]",
        category: "Dresses",
        fabric: "[Fabric]",
        availableSizes: "[Available sizes]",
        approximatePriceRange: "[Approximate FOB price range]",
        moq: "[MOQ]",
        colourOptions: "[Colour options]",
        note: "[Short product note]",
      },
      {
        id: "gallery-product-014",
        title: "[Product name 14]",
        image: {
          src: "/images/products/product-top-03.jpg",
          alt: "Placeholder for women’s embroidered top style 03",
          recommendedShot: "Portrait crop showing surface workmanship",
        },
        filters: ["Tops", "Embroidered"],
        styleCode: "[Style code 14]",
        category: "Tops",
        fabric: "[Fabric]",
        availableSizes: "[Available sizes]",
        approximatePriceRange: "[Approximate FOB price range]",
        moq: "[MOQ]",
        colourOptions: "[Colour options]",
        note: "[Short product note]",
      },
      {
        id: "gallery-product-016",
        title: "[Product name 16]",
        image: {
          src: "/images/products/product-casual-tunic-01.jpg",
          alt: "Placeholder for women’s casual solid tunic style 01",
          recommendedShot: "Relaxed on-model image showing silhouette",
        },
        filters: ["Tunics", "Solid", "Casual"],
        styleCode: "[Style code 16]",
        category: "Tunics",
        fabric: "[Fabric]",
        availableSizes: "[Available sizes]",
        approximatePriceRange: "[Approximate FOB price range]",
        moq: "[MOQ]",
        colourOptions: "[Colour options]",
        note: "[Short product note]",
      },
    ],
    enquiryLabel: "Enquire About This Style",
    loadMoreLabel: "View More Products",
  },

  faqs: {
    eyebrow: "Buyer questions",
    heading: "Frequently Asked Questions",
    items: [
      {
        id: "faq-moq",
        question: "What is your minimum order quantity?",
        answer:
          "Our standard MOQ is approximately 700 pieces per style. Final feasibility depends on fabric, design, colour split and order requirements.",
      },
      {
        id: "faq-price",
        question: "What is your approximate price range?",
        answer:
          "Our approximate FOB positioning is USD 3–12 per piece, depending on style, fabric, workmanship, packing and order volume.",
      },
      {
        id: "faq-references",
        question: "Can you develop products from references or sketches?",
        answer:
          "Yes. We can evaluate buyer references, sketches or specifications for development, subject to technical feasibility and agreed ownership requirements.",
      },
      {
        id: "faq-sourcing",
        question: "Can you source fabrics and trims?",
        answer:
          "Fabric and trim options can be reviewed against the design, season, sourcing conditions and quantity.",
      },
      {
        id: "faq-capacity",
        question: "What is your monthly production capacity?",
        answer:
          "ESHA Apparels has capacity of up to 250,000 pieces per month across two factories, supported by 575 sewing machines and subject to style mix and production planning.",
      },
      {
        id: "faq-repeat-orders",
        question: "Can you handle repeat orders?",
        answer:
          "Repeat orders can be evaluated against fabric availability, line planning, approved specifications and the required delivery window.",
      },
      {
        id: "faq-exclusive",
        question: "Do you manufacture buyer-exclusive styles?",
        answer:
          "Exclusive product development can be considered subject to a clear written agreement, commercial feasibility and ownership terms.",
      },
      {
        id: "faq-markets",
        question: "What markets do you export to?",
        answer:
          "ESHA Apparels has international export experience, including the Japanese market. Additional verified markets will be added to this profile.",
      },
      {
        id: "faq-quality",
        question: "How do you manage quality control?",
        answer:
          "Quality checkpoints cover fabric, pre-production review, in-line inspection, measurements, finishing, final inspection and packing verification.",
      },
      {
        id: "faq-costing",
        question: "What information is required for costing?",
        answer:
          "Please share the product category, design direction, fabric or material notes where available, size range, quantity, colour split, packing and delivery requirements.",
      },
      {
        id: "faq-visits",
        question: "Can buyers visit the factories?",
        answer:
          "Factory meeting requests can be reviewed in advance. Visit timing, location and access details are confirmed directly with ESHA Apparels.",
      },
    ],
  },

  enquiry: {
    eyebrow: "Start a buyer enquiry",
    heading: "Share the Essentials for Costing Review",
    introduction:
      "Share the product category, approximate quantity, target market and key requirements so the ESHA Apparels team can evaluate commercial feasibility.",
    emailTo: "lakshbaheti59@gmail.com",
    fields: [
      {
        id: "buyer-name",
        name: "buyerName",
        label: "Buyer name",
        type: "text",
        placeholder: "Your full name",
        required: true,
      },
      {
        id: "company-name",
        name: "companyName",
        label: "Company name",
        type: "text",
        placeholder: "Your business or brand",
        required: true,
      },
      {
        id: "country",
        name: "country",
        label: "Country",
        type: "text",
        placeholder: "Country",
        required: true,
      },
      {
        id: "email",
        name: "email",
        label: "Email",
        type: "email",
        placeholder: "name@company.com",
        required: true,
      },
      {
        id: "phone",
        name: "phone",
        label: "Phone or WhatsApp",
        type: "tel",
        placeholder: "Include country code",
        required: false,
      },
      {
        id: "buyer-type",
        name: "buyerType",
        label: "Buyer type",
        type: "select",
        required: true,
        options: [
          { label: "Select buyer type", value: "" },
          { label: "Retail chain", value: "retail-chain" },
          { label: "Fashion brand", value: "fashion-brand" },
          { label: "Importer", value: "importer" },
          { label: "Distributor", value: "distributor" },
          { label: "Buying house", value: "buying-house" },
          { label: "Wholesaler", value: "wholesaler" },
          { label: "Department store", value: "department-store" },
          { label: "E-commerce business", value: "ecommerce" },
          { label: "Emerging brand", value: "emerging-brand" },
          { label: "[Other buyer type]", value: "other" },
        ],
      },
      {
        id: "product-category",
        name: "productCategory",
        label: "Product category",
        type: "select",
        required: true,
        options: [
          { label: "Select product category", value: "" },
          { label: "Dresses", value: "dresses" },
          { label: "Tops and blouses", value: "tops-blouses" },
          { label: "Tunics", value: "tunics" },
          { label: "Co-ord sets", value: "coord-sets" },
          { label: "Skirts", value: "skirts" },
          { label: "Bottoms", value: "bottoms" },
          { label: "Casual western wear", value: "casual-western-wear" },
          { label: "[Other product category]", value: "other" },
        ],
      },
      {
        id: "estimated-quantity",
        name: "estimatedOrderQuantity",
        label: "Estimated order quantity",
        type: "text",
        placeholder: "Approx. pieces per style or total order",
        required: true,
        helperText:
          "Standard MOQ is approximately 700 pieces per style, subject to requirements.",
      },
      {
        id: "shipment-window",
        name: "shipmentWindow",
        label: "Expected shipment window",
        type: "text",
        placeholder: "Month, season or approximate timing",
        required: false,
        helperText:
          "Approximate timing is enough; final lead time is reviewed after design and material details.",
      },
      {
        id: "message",
        name: "message",
        label: "Message",
        type: "textarea",
        placeholder:
          "Describe category, style direction, quantity split, target market, size range and key workmanship or packing needs",
        required: true,
        fullWidth: true,
      },
    ],
    costingNote:
      "Detailed costing is prepared after reviewing the product category, design, workmanship, quantity, size and colour split, packing and order requirements.",
    consentLabel:
      "I confirm that I am authorised to share this enquiry and agree to be contacted about it.",
    submitLabel: "Send Buyer Enquiry",
    successMessage:
      "Your email app should now open with the enquiry details prepared for ESHA Apparels.",
  },

  // EDIT: replace all bracketed contact values before public launch.
  contact: {
    heading: "Contact ESHA Apparels",
    details: [
      {
        label: "Business email",
        value: "PB@ESHA.BIZ; Pradeep.eshaapparels@gmail.com",
        status: "confirmed",
      },
      {
        label: "WhatsApp",
        value: "+91-9214446669",
        status: "confirmed",
      },
      {
        label: "Phone",
        value: "+91-9214446669",
        status: "confirmed",
      },
      {
        label: "Office address",
        value: "G1-165, E.P.I.P, Garment Zone, Sitapura, Jaipur",
        status: "confirmed",
      },
      {
        label: "Factory One address",
        value: "G1-165, E.P.I.P, Garment Zone, Sitapura, Jaipur",
        status: "confirmed",
      },
      {
        label: "Factory Two address",
        value: "1282, Sitapura near Bombay Hospital, Jaipur",
        status: "confirmed",
      },
    ],
    socialMedia: [
      {
        label: "LinkedIn",
        value: "[LinkedIn URL]",
        status: "verification-required",
      },
      {
        label: "Instagram",
        value: "[Instagram URL]",
        status: "verification-required",
      },
      {
        label: "Other social media",
        value: "[Social media URL]",
        status: "verification-required",
      },
    ],
    qrCode: {
      src: "/images/hero/esha-apparels-brand-mark.png",
      alt: "ESHA Apparels logo",
      recommendedShot: "Company logo for buyer contact section",
    },
  },

  closing: {
    heading: "Let’s Build Your Next Collection",
    text: "Whether you are developing a new range, expanding an existing category or looking for a scalable manufacturing partner, ESHA Apparels is ready to evaluate your requirements.",
    actions: [
      {
        label: "Send a Product Brief",
        href: "/contact",
        variant: "primary",
      },
      {
        label: "Request the Complete Profile",
        href: "/contact",
        variant: "secondary",
      },
      {
        label: "Book a Factory Meeting",
        href: "/contact",
        variant: "secondary",
      },
      {
        label: "Download Company Profile",
        href: "[Company profile PDF path]",
        variant: "light",
        download: true,
      },
    ],
    image: {
      src: "/images/team/closing-team-factory.jpg",
      alt: "Recommended ESHA Apparels garment, team or factory closing image",
      recommendedShot:
        "Wide team, garment collection or factory image with clear text area",
    },
  },

  downloads: {
    printLabel: "Print Profile",
    downloadLabel: "Download Company Profile",
    downloadPath: "[Company profile PDF path]",
  },

  footer: {
    strapline: "Women’s fashion manufacturing at scale.",
    legalLine: `© ${new Date().getFullYear()} ESHA Apparels. [Add verified legal notice.]`,
    placeholderNotice:
      "Items shown in square brackets are editable placeholders and must be verified before publication.",
  },
};
