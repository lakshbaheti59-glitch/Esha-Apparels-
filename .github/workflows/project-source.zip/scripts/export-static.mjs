import { writeFile } from 'node:fs/promises'
import { resolve } from 'node:path'

const baseUrl = process.env.ESHA_EXPORT_URL ?? 'http://localhost:3000'

const pages = [
  ['/', 'index.html'],
  ['/about', 'about.html'],
  ['/facilities', 'facilities.html'],
  ['/products', 'products.html'],
  ['/quality-compliance', 'quality-compliance.html'],
  ['/sustainability', 'sustainability.html'],
  ['/export', 'export.html'],
  ['/events', 'events.html'],
  ['/awards', 'awards.html'],
  ['/contact', 'contact.html'],
  ['/company-profile', 'company-profile.html'],
]

const routeFiles = new Map(pages)

const staticEnhancements = String.raw`
<script>
(() => {
  const menuButton = document.querySelector('.nav-toggle');
  const navigation = document.querySelector('.site-nav__links');
  menuButton?.addEventListener('click', () => {
    const open = !navigation?.classList.contains('is-open');
    navigation?.classList.toggle('is-open', open);
    document.querySelector('.site-nav')?.classList.toggle('is-open', open);
    document.body.classList.toggle('menu-open', open);
    menuButton.setAttribute('aria-expanded', String(open));
    menuButton.setAttribute('aria-label', open ? 'Close navigation menu' : 'Open navigation menu');
  });

  const japaneseTranslations = {
    "Skip to main content": "メインコンテンツへ移動",
    "Garment manufacturing & export": "アパレル製造・輸出",
    "Women’s garment manufacturing & export": "婦人服の製造・輸出",
    "Home": "ホーム",
    "About": "会社概要",
    "Facilities": "工場設備",
    "Products": "商品カテゴリー",
    "Quality & Compliance": "品質・コンプライアンス",
    "Sustainability": "サステナビリティ",
    "Export": "輸出",
    "Events": "イベント",
    "Awards": "受賞歴",
    "Contact": "お問い合わせ",
    "Download Profile": "会社案内をダウンロード",
    "Buyer Enquiry": "バイヤーお問い合わせ",
    "Close navigation menu": "ナビゲーションを閉じる",
    "Open navigation menu": "ナビゲーションを開く",
    "Women’s Fashion": "婦人服ファッション",
    "Manufacturing": "製造",
    "at Scale": "量産対応",
    "From trend-focused product development to dependable bulk production, ESHA Apparels helps fashion businesses bring commercially relevant women’s collections to market.": "トレンドを意識した商品開発から安定した量産まで、ESHA Apparelsは商業性の高い婦人服コレクションを市場に届けるファッションビジネスを支援します。",
    "Explore the company": "会社情報を見る",
    "Buyer decision flow": "バイヤー判断フロー",
    "Evaluate ESHA Apparels in 30 Seconds": "30秒で確認できるESHA Apparelsの要点",
    "A concise route through the information buyers usually check first: product fit, commercial range, production scale, quality process, export readiness and the next enquiry step.": "バイヤーが最初に確認する商品適合性、価格帯、生産規模、品質プロセス、輸出対応力、次の問い合わせ手順を簡潔に整理しています。",
    "30-second review": "30秒レビュー",
    "From product fit to first brief.": "商品適合性から初回ブリーフまで。",
    "Use this quick buyer route to confirm whether ESHA Apparels fits the category, price, scale and execution profile required for your programme.": "この簡潔な導線で、ESHA Apparelsがお客様のプログラムに必要なカテゴリー、価格、規模、実行体制に合うかをご確認いただけます。",
    "Begin enquiry": "問い合わせを開始",
    "What we make": "製造品目",
    "Women’s western wear and fast-fashion garments": "婦人向けウェスタンウェアとファストファッション衣料",
    "Dresses, tops, blouses, tunics, co-ords, skirts, bottoms, printed garments, lace-detail styles and value-added commercial fashion.": "ドレス、トップス、ブラウス、チュニック、セットアップ、スカート、ボトムス、プリント商品、レース使い、付加価値ディテールのある商業向けファッションに対応します。",
    "View product categories": "商品カテゴリーを見る",
    "Commercial fit": "商業適合性",
    "USD 3–12 approximate FOB positioning": "FOB約3〜12米ドルの価格帯",
    "Pricing is reviewed against fabric, workmanship, order quantity, packing and finishing so buyers can assess feasibility early.": "価格は生地、仕様、注文数量、梱包、仕上げ条件に照らして確認し、バイヤーが早い段階で実現性を判断できるようにします。",
    "Share requirements": "要件を共有",
    "Scale": "生産規模",
    "Up to 250,000 pieces per month": "月産最大250,000枚",
    "Two manufacturing factories and 575 sewing machines support scalable buyer programmes, subject to style mix and production planning.": "2つの製造工場と575台のミシンにより、スタイル構成と生産計画に応じて、拡張性のあるバイヤープログラムを支援します。",
    "Review facilities": "工場設備を見る",
    "Quality confidence": "品質面の安心感",
    "Checks built through production": "生産工程に組み込まれた確認体制",
    "Fabric review, pre-production alignment, in-line checks, finishing inspection and packing verification support controlled execution.": "生地確認、量産前のすり合わせ、ライン内チェック、仕上げ検品、梱包確認により、管理された実行を支えます。",
    "See quality system": "品質体制を見る",
    "Export readiness": "輸出対応力",
    "International sourcing support": "海外調達向けサポート",
    "Export-oriented coordination supports buyer specifications, order tracking, packing instructions, documentation and market expectations.": "輸出を前提とした調整により、バイヤー仕様、注文進行管理、梱包指示、書類対応、市場要件を支援します。",
    "Open export network": "輸出ネットワークを見る",
    "Next step": "次のステップ",
    "Send a focused buyer enquiry": "具体的なバイヤー問い合わせを送る",
    "Share product category, approximate quantity, buyer type and message so the ESHA Apparels team can evaluate the programme.": "商品カテゴリー、概算数量、バイヤー種別、メッセージを共有いただくことで、ESHA Apparelsチームがプログラムの対応可能性を確認できます。",
    "Start buyer enquiry": "バイヤー問い合わせを開始",
    "ESHA Apparels at a Glance": "ESHA Apparels 概要",
    "Confirmed commercial snapshot": "確認済みの事業概要",
    "Manufacturing factories": "製造工場",
    "Pieces per month": "月間生産枚数",
    "Sewing machines": "ミシン台数",
    "Approximate FOB product range": "FOB価格帯の目安",
    "Pieces per style standard MOQ": "1型あたりの標準MOQ",
    "Export experience": "輸出実績",
    "Women’s fashion": "婦人服ファッション",
    "Manufacturing specialisation": "製造専門領域",
    "Final pricing, MOQ and lead time depend on fabric availability, design complexity, order volume and finishing requirements.": "最終的な価格、MOQ、納期は、生地の調達状況、デザインの複雑さ、注文数量、仕上げ仕様により異なります。",
    "Why ESHA Apparels": "ESHA Apparelsが選ばれる理由",
    "Commercial Fashion Capability with Manufacturing Depth": "商業ファッションを支える製造力",
    "A commercially focused manufacturing proposition built around product, scale and dependable execution.": "商品性、量産対応力、確かな実行力を軸にした、商業性重視の製造提案です。",
    "Two-factory setup": "2工場体制",
    "Integrated infrastructure for coordinated production planning.": "連携した生産計画を支える統合型インフラ。",
    "Up to 250,000 pieces monthly": "月産最大250,000枚",
    "Scalable capacity for commercially viable programmes.": "商業的に成立するプログラムに対応できる生産規模。",
    "Women’s fashion specialisation": "婦人服に特化",
    "Focused experience in women’s western and fast fashion.": "婦人向けウェスタンウェアとファストファッションでの専門経験。",
    "Competitive product positioning": "競争力のある価格帯",
    "Approximate USD 3–12 FOB range, dependent on order requirements.": "注文条件により異なりますが、FOB約3〜12米ドルの価格帯に対応。",
    "Trend-focused development": "トレンドを意識した開発",
    "Commercial interpretation from brief to approved sample.": "商品企画から承認サンプルまで、商業性を意識して形にします。",
    "Export-market understanding": "輸出市場への理解",
    "International buyer experience, including the Japanese market.": "日本市場を含む海外バイヤーとの取引経験。",
    "Structured quality control": "体系的な品質管理",
    "Checkpoints designed to identify issues during production.": "生産中に問題を発見し修正するためのチェック体制。",
    "Built Around Buyer Decisions, Not Just Capacity": "生産能力だけでなく、バイヤーの判断軸に応える体制",
    "A buyer-focused manufacturing proposition built around price fit, category depth, repeatable scale and controlled execution.": "価格適合性、カテゴリーへの理解、継続生産に対応できる規模、そして管理された実行力を軸にしたバイヤー向けの製造提案です。",
    "Factory allocation clarity": "工場配分の明確化",
    "The two-factory setup helps allocate styles, schedules and order flow without presenting unverified factory specialisations.": "2工場体制により、未確認の工場別専門領域を主張することなく、スタイル、スケジュール、注文フローの配分を行いやすくしています。",
    "Repeat-order scale": "リピートオーダーに対応する規模",
    "Two factories, 575 sewing machines and monthly capacity up to 250,000 pieces support planned repeat programmes where style mix and line planning allow.": "2工場、575台のミシン、月産最大250,000枚の体制により、スタイル構成とライン計画が合う場合、計画的なリピートプログラムを支援できます。",
    "Women’s category focus": "婦人服カテゴリーへの集中",
    "Development, sampling and production conversations stay centred on women’s western wear, fast-fashion silhouettes, prints, lace, tiering and value-added details.": "開発、サンプル、生産の検討は、婦人向けウェスタンウェア、ファストファッションのシルエット、プリント、レース、ティアード仕様、付加価値ディテールを中心に進めます。",
    "Price discipline from the start": "初期段階からの価格設計",
    "USD 3–12 FOB positioning is reviewed against fabric, workmanship, quantity and packing so buyers can assess commercial fit early.": "FOB約3〜12米ドルの価格帯は、生地、仕様、数量、梱包条件と照らし合わせて確認し、バイヤーが早い段階で商業的な適合性を判断できるようにします。",
    "Development to approved sample": "承認サンプルまでの開発対応",
    "Buyer references are interpreted through fabric, trim, fit and costing review before moving toward approved samples.": "バイヤーの参考資料は、生地、付属、フィット、コスト確認を通じて解釈し、承認サンプルへ進めます。",
    "Export communication": "輸出向けコミュニケーション",
    "Sampling coordination, order tracking, packing instructions, labelling requirements and documentation support are managed programme by programme.": "サンプル調整、注文進行管理、梱包指示、ラベル要件、書類対応は、プログラムごとに確認しながら進めます。",
    "Quality before final inspection": "最終検品前からの品質管理",
    "Fabric review, pre-production alignment, in-line checks, finishing and packing checks help catch issues during production.": "生地確認、量産前確認、ライン内チェック、仕上げ、梱包確認により、生産中に問題を把握しやすくします。",
    "Commercial feasibility discipline": "商業的実現性の確認",
    "MOQ, lead time and price are qualified against fabric availability, design complexity, order volume and finishing needs before commitment.": "MOQ、納期、価格は、生地の調達状況、デザインの複雑さ、注文数量、仕上げ要件に照らして確認したうえで進めます。",
    "Explore the profile": "プロフィールを見る",
    "Focused Information for Faster Buyer Review": "バイヤーが素早く確認できる情報設計",
    "Move directly to the company information most relevant to your sourcing decision.": "調達判断に必要な会社情報へすぐにアクセスできます。",
    "Let’s Build Your Next Collection": "次のコレクションを一緒に形にしましょう",
    "Whether you are developing a new range, expanding an existing category or looking for a scalable manufacturing partner, ESHA Apparels is ready to evaluate your requirements.": "新しいレンジの開発、既存カテゴリーの拡大、量産対応できる製造パートナーの検討など、ESHA Apparelsはお客様の要件を確認し対応可能性を評価します。",
    "Send a Product Brief": "商品ブリーフを送る",
    "Request the Complete Profile": "完全版プロフィールを依頼",
    "Book a Factory Meeting": "工場面談を予約",
    "Download Company Profile": "会社案内をダウンロード",
    "About Us": "会社概要",
    "Company profile": "会社プロフィール",
    "Built for Fashion. Structured for Scale.": "ファッションに強く、量産に適した体制。",
    "Meet ESHA Apparels, understand how we support buyers, and see the commercial relationships our manufacturing model is designed to evaluate.": "ESHA Apparelsの概要、バイヤー支援の内容、当社の製造体制が対応できる商業的な関係性をご確認ください。",
    "ESHA Apparels is a women’s garment manufacturer and exporter focused on western wear, trend-driven collections and scalable production.": "ESHA Apparelsは、ウェスタンウェア、トレンド型コレクション、量産対応に注力する婦人服メーカー・輸出企業です。",
    "Our operations are structured to help buyers move from a product brief to export-ready bulk production through coordinated development, commercial review and manufacturing support.": "当社の業務体制は、商品ブリーフから輸出対応の量産まで、開発・商業面の確認・製造支援を連携して進められるよう設計されています。",
    "Product development": "商品開発",
    "Fabric and trim selection": "生地・付属選定",
    "Sampling": "サンプル作成",
    "Costing": "原価・価格確認",
    "Bulk manufacturing": "量産",
    "Quality control": "品質管理",
    "Packing": "梱包",
    "Export coordination": "輸出調整",
    "Past · Present · Future": "過去・現在・未来",
    "A Company Built Through Consistent Progress": "着実な歩みで成長してきた会社",
    "ESHA Apparels’ profile is shaped by a practical manufacturing history, a stronger present-day production base and a future focused on becoming an even more valuable sourcing partner for international buyers.": "ESHA Apparelsは、実務に根ざした製造の歴史、現在の強い生産基盤、そして海外バイヤーにとってより価値ある調達パートナーを目指す将来像によって形づくられています。",
    "Past": "過去",
    "Established with a hi-fashion manufacturing foundation": "ファッション性の高い製造基盤からスタート",
    "The business profile records ESHA Apparels as an India-based hi-fashion garment manufacturer with year of inception 2007, working with domestic buyers and export markets including USA and Europe.": "会社プロフィールでは、ESHA Apparelsは2007年創業のインド拠点ハイファッション衣料メーカーとして、国内バイヤーおよび米国・欧州を含む輸出市場に対応してきた企業として記載されています。",
    "Year of inception: 2007": "創業年：2007年",
    "India-based hi-fashion garment manufacturer": "インドを拠点とするハイファッション衣料メーカー",
    "Professional textile-industry team": "繊維業界の専門チーム",
    "Two dedicated manufacturing units and one showroom": "2つの専用製造ユニットと1つのショールーム",
    "Present": "現在",
    "A stronger, buyer-ready manufacturing partner": "より強固でバイヤー対応力のある製造パートナー",
    "Today, ESHA Apparels combines women’s fashion specialisation with two Sitapura, Jaipur factories, a 50,000 sq. ft. manufacturing footprint, scalable monthly capacity and recognition from Reliance for vendor performance.": "現在、ESHA Apparelsは婦人服への専門性、ジャイプール・シタプラの2工場、合計50,000平方フィートの製造スペース、拡張性のある月間生産能力、そしてRelianceによるベンダーパフォーマンス評価を備えています。",
    "Future": "未来",
    "Focused on sharper development and wider buyer confidence": "より精度の高い開発と、さらなるバイヤー信頼の獲得へ",
    "Looking ahead, ESHA Apparels is positioned to keep strengthening product development, quality documentation, buyer communication and responsible manufacturing practices for buyers who need commercial fashion with dependable execution.": "今後もESHA Apparelsは、確実な実行力を求めるバイヤーに向けて、商品開発、品質書類、バイヤーとのコミュニケーション、責任ある製造への取り組みを強化していきます。",
    "Buyer associations": "取引・関係先",
    "Companies We Work With": "取引・関係のある企業",
    "ESHA Apparels has worked with recognised national and international retail, catalogue and fashion-related companies. Logo usage should be reviewed before final publication.": "ESHA Apparelsは、国内外の小売、カタログ、ファッション関連企業との実績があります。ロゴ使用については公開前に確認してください。",
    "National Companies": "国内企業",
    "Selected national buyer and retail associations shared for the ESHA Apparels profile.": "ESHA Apparelsのプロフィールに掲載する国内バイヤー・小売関連企業です。",
    "International Companies": "海外企業",
    "Selected international buyer associations for export-oriented garment programmes.": "輸出向け衣料プログラムに関連する海外バイヤー企業です。",
    "Europe / UK": "欧州 / 英国",
    "Logo usage should be reviewed before publication. Add or remove company logos only after relationship and usage approval are confirmed.": "公開前にロゴ使用の可否を確認してください。関係性と使用許可が確認された場合のみ、企業ロゴを追加・削除してください。",
    "Buyer segments": "対応可能なバイヤー層",
    "Manufacturing Solutions for Different Stages of Growth": "成長段階に応じた製造ソリューション",
    "ESHA Apparels can evaluate programmes from established sourcing organisations and commercially ready developing businesses.": "ESHA Apparelsは、既存の調達組織から商業的に準備の整った成長企業まで、各種プログラムの対応可能性を評価できます。",
    "Order feasibility depends on product type, quantity and development requirements. This list describes buyer types ESHA Apparels can evaluate; it does not imply an existing supply relationship with every segment.": "対応可否は商品タイプ、数量、開発要件により異なります。このリストはESHA Apparelsが評価可能なバイヤータイプを示すもので、すべてのカテゴリーへの既存供給関係を意味するものではありません。",
    "Product Categories": "商品カテゴリー",
    "Women’s western wear": "婦人向けウェスタンウェア",
    "Commercial Product Categories for Buyer Programmes": "バイヤープログラム向け商品カテゴリー",
    "Explore the women’s product categories, fabric directions, value additions and editable selected-style gallery.": "婦人服カテゴリー、生地方向性、付加価値ディテール、編集可能な選定スタイルギャラリーをご確認ください。",
    "Fabrics & value additions": "生地・付加価値加工",
    "A Material Library Built Around the Product Brief": "商品ブリーフに基づく素材ライブラリー",
    "Potential fabric and workmanship directions are reviewed for suitability, sourcing conditions, commercial target and production requirements.": "生地や仕様の方向性は、適性、調達状況、目標価格、生産要件に照らして確認します。",
    "Fabric possibilities": "対応可能な生地例",
    "Natural, fluid and commercially adaptable bases": "自然な風合いと商業性を備えた素材ベース",
    "Value additions": "付加価値ディテール",
    "Details that create visible commercial value": "見た目の価値を高めるディテール",
    "Selected collections": "選定コレクション",
    "A Flexible Gallery for Current Product Development": "現在の商品開発に使える柔軟なギャラリー",
    "Replace the labelled placeholders with approved garment photography and verified style details. The data structure can be extended to 50–100 or more products without changing the field format.": "ラベル付きプレースホルダーを承認済みの商品写真と確認済みスタイル情報に差し替えてください。データ構造は形式を変えずに50〜100点以上の商品へ拡張できます。",
    "All Products": "すべての商品",
    "Dresses": "ドレス",
    "Tops": "トップス",
    "Tops and blouses": "トップス・ブラウス",
    "Tunics": "チュニック",
    "Co-ords": "セットアップ",
    "Co-ord sets": "セットアップ",
    "Skirts": "スカート",
    "Bottoms": "ボトムス",
    "Printed": "プリント",
    "Solid": "無地",
    "Lace": "レース",
    "Embroidered": "刺繍",
    "Casual": "カジュアル",
    "Casual western wear": "カジュアルウェスタンウェア",
    "Showing": "表示中",
    "View details": "詳細を見る",
    "Enquire About This Style": "このスタイルについて問い合わせる",
    "Sustainability": "サステナビリティ",
    "Responsible manufacturing": "責任ある製造",
    "Practical Progress, Supported by Verified Information": "確認済み情報に基づく実践的な取り組み",
    "Responsible Production, Documented with Care": "丁寧に記録された責任ある生産",
    "ESHA Apparels approaches resource use, material options and production efficiency pragmatically. Initiatives and outcomes should be supported by verified evidence before publication.": "ESHA Apparelsは、資源利用、素材選択、生産効率に実務的に取り組んでいます。取り組みや成果は、公開前に確認済みの証拠で裏付ける必要があります。",
    "Material optimisation": "素材の最適化",
    "Production efficiency": "生産効率",
    "Waste-reduction initiatives": "廃棄削減の取り組み",
    "Sustainable fabric options": "サステナブル素材の選択肢",
    "Quality and Compliance": "品質・コンプライアンス",
    "Controlled production": "管理された生産",
    "Quality Built into Every Stage": "すべての工程に組み込まれた品質管理",
    "Quality-control system": "品質管理システム",
    "Quality checkpoints are integrated through material review, pre-production alignment, manufacturing, finishing and packing.": "品質チェックポイントは、素材確認、量産前確認、製造、仕上げ、梱包の各工程に組み込まれています。",
    "Our quality processes are structured to identify and correct issues during production, rather than relying only on final inspection.": "当社の品質プロセスは、最終検品だけに頼るのではなく、生産中に問題を発見し修正できるよう設計されています。",
    "Compliance readiness": "コンプライアンス対応準備",
    "Buyer Requirements, Supported by Verified Evidence": "確認済みエビデンスに基づくバイヤー要件対応",
    "ESHA Apparels can review buyer-specific workplace, audit and documentation requirements against current factory capability. All credential fields remain clearly marked until evidence is supplied.": "ESHA Apparelsは、バイヤー固有の職場基準、監査、書類要件を現在の工場能力に照らして確認できます。証拠が提出されるまでは、認証項目は明確に未確認として表示されます。",
    "Export Experience": "輸出実績",
    "International sourcing": "国際調達",
    "Designed for International Sourcing Requirements": "国際調達要件に対応する体制",
    "Export & buyer experience": "輸出・バイヤー対応経験",
    "ESHA Apparels has experience supporting export-oriented production for international buyers, including the Japanese market. Product specifications, quality expectations, documentation and commercial timelines are reviewed for each programme.": "ESHA Apparelsは、日本市場を含む海外バイヤー向けの輸出生産を支援してきた経験があります。商品仕様、品質要件、書類、商業スケジュールはプログラムごとに確認します。",
    "Global Export Network": "世界への輸出ネットワーク",
    "GLOBAL EXPORT NETWORK": "世界への輸出ネットワーク",
    "From our manufacturing facilities in India to trusted international markets.": "インドの製造拠点から、信頼ある海外市場へ。",
    "Animated export routes from India to highlighted export markets": "インドから主要輸出市場への輸出ルート",
    "Global export route map": "世界輸出ルートマップ",
    "Global Export Network map": "世界輸出ネットワークマップ",
    "ESHA Apparels": "ESHA Apparels",
    "India collection": "インド コレクション",
    "USA collection": "米国 コレクション",
    "Japan collection": "日本 コレクション",
    "UK collection": "英国 コレクション",
    "South Africa collection": "南アフリカ コレクション",
    "[Country] collection": "[国名] コレクション",
    "Manufacturing Origin": "製造拠点",
    "Commercial Woven Dress": "商業向けウーブンドレス",
    "Printed Cotton Midi Dress": "プリントコットン・ミディドレス",
    "Retail Range Top": "リテール向けトップス",
    "Casual Western Tunic": "カジュアルウェスタンチュニック",
    "[Design name]": "[デザイン名]",
    "Women’s woven fashion": "婦人向けウーブンファッション",
    "Printed woven fabric": "プリント織物",
    "Cotton Slub": "コットンスラブ",
    "Viscose / Cotton blend": "ビスコース / コットン混",
    "[Fabric name]": "[生地名]",
    "Design, sampling and bulk production base": "デザイン、サンプル、量産の拠点",
    "Export-oriented buyer programme": "輸出向けバイヤープログラム",
    "Bulk export programme": "量産輸出プログラム",
    "Commercial retail range review": "商業リテールレンジの検討",
    "Buyer-market programme to be verified": "確認予定のバイヤー市場プログラム",
    "[Production note]": "[生産メモ]",
    "Fabric": "生地",
    "Market": "市場",
    "Production": "生産",
    "Buyer / Company": "バイヤー / 企業",
    "ESHA Apparels garment image": "ESHA Apparels 商品画像",
    "USA garment image": "米国向け商品画像",
    "Japan garment image": "日本向け商品画像",
    "UK garment image": "英国向け商品画像",
    "South Africa garment image": "南アフリカ向け商品画像",
    "[Country] garment image": "[国名] 商品画像",
    "Market experience": "市場対応経験",
    "International brief. Market-aware execution.": "国際的なブリーフを、市場感覚を持って実行。",
    "India": "インド",
    "Japan": "日本",
    "USA": "米国",
    "Europe": "欧州",
    "South Africa": "南アフリカ",
    "UK": "英国",
    "English-language communication": "英語でのコミュニケーション",
    "Sampling coordination": "サンプル調整",
    "Order tracking": "注文進行管理",
    "Packing instructions": "梱包指示対応",
    "Labelling requirements": "ラベル要件対応",
    "Barcode and tag support": "バーコード・タグ対応",
    "Export documentation coordination": "輸出書類の調整",
    "Buyer-specific quality manuals": "バイヤー別品質マニュアル対応",
    "Product data sharing": "商品データ共有",
    "Events": "イベント",
    "Buyer-Facing Moments, Past and Future": "過去と今後のバイヤー向け機会",
    "Past Participation and Upcoming Opportunities": "過去の参加実績と今後の機会",
    "Past Events": "過去のイベント",
    "Future Events": "今後のイベント",
    "Awards and Achievements": "受賞・実績",
    "Recognition": "表彰",
    "Awarded Performance in Women’s Garment Export": "婦人服輸出における評価実績",
    "Award & recognition": "受賞・表彰",
    "Reliance Best Vendor Award 2022–23": "Reliance Best Vendor Award 2022–23",
    "Best Vendor Performance 2022–2023 · Mass-Wovens Category": "Best Vendor Performance 2022–2023・Mass-Wovens Category",
    "ESHA Apparels was recognised by Reliance for vendor performance during the 2022–2023 period. This recognition supports ESHA Apparels’ positioning as a dependable women’s garment manufacturing partner for buyer-led programmes.": "ESHA Apparelsは2022〜2023年のベンダーパフォーマンスにおいてRelianceより評価されました。この表彰は、バイヤー主導のプログラムに対応する信頼できる婦人服製造パートナーとしての当社の位置づけを支えるものです。",
    "Contact Us": "お問い合わせ",
    "Buyer enquiry": "バイヤーお問い合わせ",
    "Let’s Evaluate Your Next Collection": "次のコレクションを確認しましょう",
    "Share your category, quantity and key product requirement so ESHA Apparels can evaluate the enquiry.": "カテゴリー、数量、主要な商品要件を共有いただければ、ESHA Apparelsが対応可能性を確認します。",
    "Start a buyer enquiry": "バイヤーお問い合わせを開始",
    "Share Your Product Brief": "商品ブリーフを共有",
    "Tell us about the product category, quantity and key requirements so the ESHA Apparels team can evaluate the enquiry.": "商品カテゴリー、数量、主要要件をお知らせください。ESHA Apparelsチームが内容を確認します。",
    "Share the Essentials for Costing Review": "見積確認に必要な基本情報を共有",
    "Share the product category, approximate quantity, target market and key requirements so the ESHA Apparels team can evaluate commercial feasibility.": "商品カテゴリー、おおよその数量、対象市場、主要要件を共有いただくことで、ESHA Apparelsチームが商業的な対応可能性を確認できます。",
    "Business email": "ビジネスメール",
    "WhatsApp": "WhatsApp",
    "Phone": "電話",
    "Office address": "オフィス住所",
    "Factory One address": "第1工場住所",
    "Factory Two address": "第2工場住所",
    "Social channels": "SNS",
    "Buyer brief": "バイヤーブリーフ",
    "Product development enquiry": "商品開発のお問い合わせ",
    "Required fields are marked with an asterisk.": "必須項目にはアスタリスクが付いています。",
    "Interface preview": "入力フォームプレビュー",
    "Buyer enquiry essentials": "バイヤーお問い合わせの基本情報",
    "Short, practical details for first feasibility review.": "初期の対応可否確認に必要な、簡潔で実務的な情報です。",
    "First review": "初回確認",
    "Email-ready": "メール送信対応",
    "Buyer name": "バイヤー名",
    "Company name": "会社名",
    "Country": "国",
    "Email": "メール",
    "Phone or WhatsApp": "電話またはWhatsApp",
    "Your full name": "お名前",
    "Your business or brand": "会社名またはブランド名",
    "name@company.com": "name@company.com",
    "Include country code": "国番号を含めて入力",
    "Buyer type": "バイヤー種別",
    "Select buyer type": "バイヤー種別を選択",
    "Retail chain": "小売チェーン",
    "Fashion brand": "ファッションブランド",
    "Importer": "輸入業者",
    "Distributor": "販売代理店",
    "Buying house": "バイイングハウス",
    "Wholesaler": "卸売業者",
    "Department store": "百貨店",
    "E-commerce business": "ECファッション事業者",
    "Emerging brand": "新興ブランド",
    "Product category": "商品カテゴリー",
    "Select product category": "商品カテゴリーを選択",
    "Estimated order quantity": "予定注文数量",
    "Approximate pieces per style": "1型あたりのおおよその枚数",
    "Approx. pieces per style or total order": "1型あたり、または合計注文のおおよその枚数",
    "Standard MOQ is approximately 700 pieces per style, subject to requirements.": "標準MOQは1型あたり約700枚ですが、要件により異なります。",
    "Expected shipment window": "出荷希望時期の目安",
    "Month, season or approximate timing": "月、シーズン、またはおおよその時期",
    "Approximate timing is enough; final lead time is reviewed after design and material details.": "おおよその時期で問題ありません。最終納期はデザインと素材詳細の確認後に検討します。",
    "Message": "メッセージ",
    "Describe your collection, quantity, target market and key requirements": "コレクション、数量、対象市場、主要要件をご記入ください",
    "Describe category, style direction, quantity split, target market, size range and key workmanship or packing needs": "カテゴリー、スタイル方向性、数量内訳、対象市場、サイズ展開、主要な仕様または梱包要件をご記入ください",
    "Detailed costing is prepared after reviewing the design, workmanship, quantity, packing and order requirements.": "詳細な見積は、デザイン、仕様、数量、梱包、注文要件を確認したうえで作成します。",
    "Detailed costing is prepared after reviewing the product category, design, workmanship, quantity, size and colour split, packing and order requirements.": "詳細な見積は、商品カテゴリー、デザイン、仕様、数量、サイズ・カラー内訳、梱包、注文要件を確認したうえで作成します。",
    "I confirm that I am authorised to share this enquiry and agree to be contacted about it.": "この問い合わせを共有する権限があり、本件について連絡を受けることに同意します。",
    "Send Buyer Enquiry": "お問い合わせを送信",
    "Your email app should now open with the enquiry details prepared for ESHA Apparels.": "ESHA Apparels宛のお問い合わせ内容を入力したメールアプリが開きます。",
    "Frequently Asked Questions": "よくある質問",
    "Complete profile": "完全版プロフィール",
    "Review online or save the full profile as a PDF.": "オンラインで確認、またはPDFとして保存できます。",
    "Print / Save PDF": "印刷 / PDF保存",
    "Company profile summary": "会社案内サマリー",
    "ESHA Apparels Company Profile": "ESHA Apparels 会社案内",
    "A concise buyer-facing reference for women’s garment manufacturing, export-ready production, two-factory infrastructure, quality checkpoints and confirmed commercial positioning.": "婦人服製造、輸出対応の生産体制、2工場インフラ、品質チェックポイント、確認済みの商業的位置づけをまとめた、バイヤー向けの簡潔な資料です。",
    "Specialisation": "専門分野",
    "Women’s western wear and fast-fashion garments": "婦人向けウェスタンウェアとファストファッション衣料",
    "Production capacity": "生産能力",
    "Up to 250,000 pieces per month": "月産最大250,000枚",
    "Manufacturing base": "製造拠点",
    "Two factories in Sitapura, Jaipur": "ジャイプール・シタプラの2工場",
    "575 industrial sewing machines": "工業用ミシン575台",
    "FOB positioning": "FOB価格帯",
    "Approx. USD 3–12 per piece": "1枚あたり約3〜12米ドル",
    "Standard MOQ": "標準MOQ",
    "Approx. 700 pieces per style": "1型あたり約700枚",
    "Help": "ヘルプ",
    "Need help?": "お困りですか？",
    "Open ESHA help concierge": "ESHAヘルプコンシェルジュを開く",
    "Close help concierge": "ヘルプコンシェルジュを閉じる",
    "ESHA Concierge": "ESHAコンシェルジュ",
    "Find your path": "目的別ナビ",
    "Buyer Navigation": "バイヤーナビゲーション",
    "What are you looking for?": "何をお探しですか？",
    "Choose a path. I’ll take you to the exact section.": "目的を選ぶと、該当セクションへ移動します。",
    "Compare": "比較",
    "Fast buyer review": "バイヤー向け確認",
    "Categories + gallery": "カテゴリー・ギャラリー",
    "Factories": "工場",
    "Capacity + setup": "生産能力・体制",
    "QC + compliance": "品質管理・コンプライアンス",
    "Enquiry": "お問い合わせ",
    "Send requirements": "要件を送信",
    "Buyer review": "バイヤーレビュー",
    "Jump to the proof buyers usually check first.": "バイヤーが最初に確認する根拠へ移動します。",
    "Capacity, product fit, quality and recognition — no long browsing needed.": "生産力、商品適合性、品質、受賞情報をすぐ確認できます。",
    "Company snapshot": "会社概要",
    "Numbers and positioning": "数値・ポジション",
    "Buyer decision flow": "バイヤー判断フロー",
    "Best-fit sourcing path": "最適な調達判断ルート",
    "Factory setup": "工場体制",
    "Two facilities and scale": "2工場・生産規模",
    "QC checkpoints": "品質チェックポイント",
    "Award proof": "受賞証明",
    "Reliance recognition": "Reliance表彰",
    "Send enquiry": "問い合わせる",
    "Share quantity + category": "数量・カテゴリーを共有",
    "Production scale": "生産規模",
    "2 factories · 575 machines · up to 250,000 pcs/month.": "2工場・575台のミシン・月産最大250,000枚。",
    "Capacity depends on style mix, fabric, workmanship and planning.": "実際の生産能力はスタイル構成、生地、仕様、生産計画により異なります。",
    "Open facilities": "工場設備を開く",
    "Factory details": "工場詳細",
    "Production process": "生産工程",
    "Factory workflow": "工場ワークフロー",
    "Ask production": "生産相談",
    "Send requirement": "要件を送信",
    "Where should we take you?": "どこへ移動しますか？",
    "Commercial women’s western wear, fast-fashion and export-ready woven styles.": "商業向け婦人ウェスタンウェア、ファストファッション、輸出対応の織物スタイル。",
    "Categories": "カテゴリー",
    "Dresses, tops, co-ords": "ドレス・トップス・セットアップ",
    "Style examples": "スタイル例",
    "Fabrics": "生地",
    "Materials + value-adds": "素材・付加価値",
    "Enquire style": "スタイル相談",
    "Share product brief": "商品ブリーフを共有",
    "Buyer assurance": "バイヤー安心材料",
    "Quality, compliance and responsible manufacturing.": "品質、コンプライアンス、責任ある製造。",
    "Choose the evidence area you want to review.": "確認したい証明領域を選んでください。",
    "Compliance": "コンプライアンス",
    "Audit readiness": "監査対応",
    "Sustainability": "サステナビリティ",
    "Responsible practices": "責任ある取り組み",
    "Ask for documents": "資料を依頼",
    "Review markets, buyers and export support.": "市場、バイヤー、輸出支援を確認します。",
    "Jump to the map or supporting market details.": "輸出マップまたは市場詳細へ移動します。",
    "Export map": "輸出マップ",
    "Global network": "グローバルネットワーク",
    "Market support": "市場サポート",
    "Buyer services": "バイヤー支援",
    "Reliance award": "Reliance表彰",
    "Begin enquiry": "問い合わせ開始",
    "Welcome to ESHA Apparels. What would you like to review first?": "ESHA Apparelsへようこそ。まず何を確認しますか？",
    "Choose the path closest to your visit. You can move back at any time.": "目的に近い項目を選んでください。いつでも戻れます。",
    "I'm comparing manufacturers": "製造パートナーを比較中",
    "I need capability, price and production confidence.": "対応力、価格、生産面の安心感を確認したい。",
    "Show product categories": "商品カテゴリーを見る",
    "Review women’s garment categories and selected styles.": "婦人服カテゴリーと選定スタイルを確認します。",
    "Check factory capacity": "工場・生産能力を確認",
    "See factories, machines and production scale.": "工場、設備、生産規模を確認します。",
    "Review quality and compliance": "品質・コンプライアンスを確認",
    "Understand QC, audit readiness and documentation.": "品質管理、監査対応、書類体制を確認します。",
    "See export markets": "輸出市場を見る",
    "View international market experience and buyer support.": "海外市場経験とバイヤー支援を確認します。",
    "Share product category, quantity and message.": "商品カテゴリー、数量、メッセージを共有します。",
    "Manufacturer comparison": "製造パートナー比較",
    "Which confidence area matters most right now?": "今もっとも確認したい安心材料はどれですか？",
    "I can take you straight to the evidence a sourcing team usually checks first.": "調達チームが最初に確認する情報へ直接ご案内します。",
    "Production strength": "生産力",
    "Two factories, monthly capacity and operational setup.": "2工場体制、月間生産能力、運営体制。",
    "Commercial fit": "商業条件の適合性",
    "MOQ, price range and buyer feasibility.": "MOQ、価格帯、バイヤー要件との適合性。",
    "Recognition": "受賞・評価",
    "Reliance Best Vendor Award and proof images.": "Reliance Best Vendor Awardと証明画像。",
    "Talk to ESHA": "ESHAへ相談",
    "Go to enquiry form.": "お問い合わせフォームへ進みます。",
    "Production capability": "生産対応力",
    "ESHA Apparels operates two factories with 575 sewing machines and capacity of up to 250,000 pieces per month, subject to style mix and planning.": "ESHA Apparelsは2工場、575台のミシン、月産最大250,000枚の生産能力を備えています。実際の対応はスタイル構成と生産計画により異なります。",
    "Best for buyers checking whether a programme can be handled at scale.": "量産対応の可否を確認したいバイヤーに最適です。",
    "Open facilities page": "工場設備ページを開く",
    "Factory locations, area and production structure.": "工場所在地、面積、生産体制。",
    "Compare product fit": "商品適合性を確認",
    "Go to product categories.": "商品カテゴリーへ進みます。",
    "Ask about production": "生産について問い合わせる",
    "Send quantity and category details.": "数量とカテゴリー情報を送ります。",
    "Product direction": "商品方向性",
    "Which product area should we open?": "どの商品領域を開きますか？",
    "ESHA Apparels focuses on commercial women’s western wear, fast-fashion and export-ready woven styles.": "ESHA Apparelsは商業性の高い婦人向けウェスタンウェア、ファストファッション、輸出対応の織物スタイルに注力しています。",
    "Dresses and woven styles": "ドレス・織物スタイル",
    "Open the product category page.": "商品カテゴリーページを開きます。",
    "Tops, tunics and co-ords": "トップス・チュニック・セットアップ",
    "Review core women’s fashion categories.": "主要な婦人服カテゴリーを確認します。",
    "Skirts and bottoms": "スカート・ボトムス",
    "See scalable commercial categories.": "量産対応可能な商業カテゴリーを確認します。",
    "Selected gallery": "選定ギャラリー",
    "Browse editable product examples.": "編集可能な商品例を閲覧します。",
    "Quality route": "品質ルート",
    "Quality control is structured across material review, pre-production, inline checking, finishing, inspection and packing verification.": "品質管理は素材確認、量産前確認、インラインチェック、仕上げ、検品、梱包確認まで体系化されています。",
    "Useful for buyers reviewing reliability, compliance readiness and documentation needs.": "信頼性、コンプライアンス対応、書類要件を確認するバイヤーに役立ちます。",
    "Quality system": "品質管理体制",
    "Open quality and compliance page.": "品質・コンプライアンスページを開きます。",
    "Open compliance details.": "コンプライアンス詳細を開きます。",
    "Responsible manufacturing": "責任ある製造",
    "Open sustainability page.": "サステナビリティページを開きます。",
    "Export route": "輸出ルート",
    "ESHA Apparels supports export-oriented production and international buyer requirements.": "ESHA Apparelsは輸出向け生産と海外バイヤー要件に対応します。",
    "Review markets, buyer-support capabilities and the Global Export Network.": "市場、バイヤー支援体制、世界への輸出ネットワークを確認します。",
    "Open export page.": "輸出ページを開きます。",
    "Awards and proof": "受賞・証明",
    "Open awards page.": "受賞ページを開きます。",
    "Contact team": "担当チームへ連絡",
    "Begin enquiry.": "お問い合わせを開始します。",
    "Back": "戻る",
    "Start over": "最初に戻る",
    "A manufacturing conversation": "製造に関するご相談",
    "Quality": "品質",
    "Markets + buyers": "市場・バイヤー",
    "About ESHA Apparels | Company Profile": "ESHA Apparels 会社概要",
    "ESHA Apparels | Company Profile": "ESHA Apparels 会社案内",
    "ESHA Apparels | Women’s Fashion Manufacturing at Scale": "ESHA Apparels｜婦人服の量産製造",
    "Manufacturing Facilities | ESHA Apparels": "工場設備｜ESHA Apparels",
    "Women’s Product Categories | ESHA Apparels": "婦人服商品カテゴリー｜ESHA Apparels",
    "Quality and Compliance | ESHA Apparels": "品質・コンプライアンス｜ESHA Apparels",
    "Sustainability | ESHA Apparels": "サステナビリティ｜ESHA Apparels",
    "Export Experience | ESHA Apparels": "輸出実績｜ESHA Apparels",
    "Events | ESHA Apparels": "イベント｜ESHA Apparels",
    "Awards and Achievements | ESHA Apparels": "受賞・実績｜ESHA Apparels",
    "Contact ESHA Apparels | Buyer Enquiry": "お問い合わせ｜ESHA Apparels",
    "Complete Company Profile | ESHA Apparels": "完全版会社案内｜ESHA Apparels",
    "Track ESHA Apparels’ completed events, recognition moments and upcoming trade fair, buyer meeting or sourcing opportunities.": "ESHA Apparelsの完了済みイベント、表彰機会、今後の展示会・バイヤーミーティング・調達機会を管理・掲載します。",
    "Buyer support and the partners we can evaluate.": "バイヤー支援と対応可能な取引先タイプ。",
    "Two-factory infrastructure, production flow and operating scale.": "2工場のインフラ、生産工程、運営規模。",
    "Women’s western-wear categories, materials and selected styles.": "婦人向けウェスタンウェアのカテゴリー、素材、選定スタイル。",
    "Structured checkpoints, verification fields and buyer requirements.": "体系的な検品ポイント、確認項目、バイヤー要件。",
    "Responsible manufacturing awareness and practical efficiency initiatives.": "責任ある製造への意識と実務的な効率化施策。",
    "International sourcing support and confirmed Japanese-market experience.": "国際調達支援と日本市場での確認済み経験。",
    "Past participation and upcoming buyer-facing event opportunities.": "過去の参加実績と今後のバイヤー向け機会。",
    "Verified recognition and supporting award evidence.": "確認済みの受賞実績と証明資料。",
    "Share a category, quantity and product requirement.": "カテゴリー、数量、商品要件を共有。",
    "Review ESHA Apparels’ two-factory infrastructure and clearly marked editable factory information.": "ESHA Apparelsの2工場インフラと、明確に表示された編集可能な工場情報をご確認ください。",
    "Explore Our Facilities": "工場設備を見る",
    "Start a Buyer Enquiry": "バイヤーお問い合わせを開始",
    "ESHA Apparels operates two dedicated manufacturing units in Sitapura, Jaipur, supported by one showroom. The business profile describes the manufacturing infrastructure as global-standard units equipped with modern machinery and technology.": "ESHA Apparelsはジャイプール・シタプラに2つの専用製造ユニットを運営し、1つのショールームを備えています。会社資料では、現代的な機械・技術を備えたグローバル基準の製造インフラとして紹介されています。",
    "Factory One is located in the E.P.I.P Garment Zone at Sitapura, Jaipur.": "第1工場はジャイプール・シタプラのE.P.I.P Garment Zoneにあります。",
    "Factory Two is located in Sitapura, near Bombay Hospital, Jaipur.": "第2工場はジャイプールのBombay Hospital近く、シタプラにあります。",
    "22,000 sq. ft.": "22,000平方フィート",
    "28,000 sq. ft.": "28,000平方フィート",
    "USA / Global": "米国 / グローバル",
    "Cutting floor": "裁断フロア",
    "Stitching lines": "縫製ライン",
    "Finishing section": "仕上げセクション",
    "Packing area": "梱包エリア",
    "Production floor": "生産フロア",
    "Sampling department": "サンプル部門",
    "Inspection area": "検品エリア",
    "Dispatch area": "出荷エリア",
    "Replace with verified Factory One photography": "確認済みの第1工場写真に差し替え",
    "Replace with verified Factory Two photography": "確認済みの第2工場写真に差し替え",
    "MOQ": "MOQ",
    "Commercial day, casual and collection-led dress concepts developed around the buyer’s silhouette and market brief.": "バイヤーのシルエット要件と市場ブリーフに合わせて開発する、商業向けデイ・カジュアル・コレクション系ドレス。",
    "Versatile woven tops and blouses suited to retail and coordinated range development.": "小売向けやコーディネートレンジ開発に適した、汎用性の高い織物トップス・ブラウス。",
    "Relaxed and structured tunic options with commercially adaptable proportions and detailing.": "商業的に調整しやすいバランスとディテールを備えた、リラックス感と構築感のあるチュニック。",
    "Coordinated tops and bottoms designed as commercially cohesive sets or separable range pieces.": "セット商品としても単品レンジとしても展開できる、トップスとボトムスのコーディネート商品。",
    "Commercial skirt silhouettes ranging from clean everyday styles to tiered and printed options.": "シンプルな日常向けスタイルからティアード・プリント仕様まで対応する商業向けスカートシルエット。",
    "Women’s woven bottoms developed for coordinated collections and everyday commercial ranges.": "コーディネートコレクションや日常向け商業レンジに対応する婦人向け織物ボトムス。",
    "Easy, trend-aware styles developed for commercially relevant everyday collections.": "日常向けコレクションに適した、取り入れやすくトレンド感のあるスタイル。",
    "Elevated but commercially considered styles using detail, proportion and value addition.": "ディテール、バランス、付加価値加工を活かした、上品で商業性のあるスタイル。",
    "Dresses, skirts and tunics developed with controlled volume, gathering and tier construction.": "ボリューム、ギャザー、ティアード構造をコントロールして開発するドレス、スカート、チュニック。",
    "Print-led dresses, tops, tunics, skirts and sets coordinated to the buyer’s collection direction.": "バイヤーのコレクション方向性に合わせて組み立てる、プリント主体のドレス、トップス、チュニック、スカート、セット商品。",
    "Commercial silhouettes enhanced with considered lace placement and feminine detailing.": "レース配置とフェミニンなディテールで価値を高めた商業向けシルエット。",
    "Styles incorporating embroidery or selected surface details to build commercial visual value.": "刺繍や表面ディテールを取り入れ、見た目の商業価値を高めるスタイル。",
    "Length, sleeve, neckline, print, trim and construction details can be reviewed for custom development.": "丈、袖、ネックライン、プリント、付属、縫製仕様はカスタム開発に向けて確認できます。",
    "Necklines, sleeves, plackets, trims and surface details can be adapted to the approved brief.": "ネックライン、袖、前立て、付属、表面ディテールは承認ブリーフに合わせて調整できます。",
    "Length, side openings, yokes, sleeves and decorative elements can be developed to specification.": "丈、脇開き、ヨーク、袖、装飾要素は仕様に合わせて開発できます。",
    "Top-to-bottom proportion, colour, print placement and mix-and-match options can be reviewed.": "上下のバランス、色、プリント配置、ミックスアンドマッチの可能性を確認できます。",
    "Length, waistband, volume, panel, tier and closure options can be evaluated.": "丈、ウエストベルト、ボリューム、パネル、ティア、開閉仕様を評価できます。",
    "Fit, rise, leg shape, waistband and pocket construction can be developed from the buyer brief.": "フィット、股上、レッグシルエット、ウエストベルト、ポケット仕様をバイヤーブリーフから開発できます。",
    "Silhouette, wash, colour, print and trim direction can be aligned to buyer requirements.": "シルエット、洗い、色、プリント、付属方向性をバイヤー要件に合わせられます。",
    "Detail level, construction and workmanship can be cost-engineered for the agreed positioning.": "ディテール量、構造、仕様は合意した価格ポジションに合わせてコスト調整できます。",
    "Tier count, placement, fullness, length and seam detailing can be adjusted to the style.": "ティアの数、位置、分量、丈、縫い目ディテールをスタイルに合わせて調整できます。",
    "Print selection, scale, colourway and placement are subject to sourcing, MOQ and approval.": "プリント選定、柄サイズ、配色、配置は調達条件、MOQ、承認状況により異なります。",
    "Lace type, placement, width, colour and construction can be developed subject to availability.": "レースの種類、配置、幅、色、縫製仕様は調達可能性に応じて開発できます。",
    "Motif, placement, thread, trim and workmanship are reviewed against cost and production needs.": "モチーフ、配置、糸、付属、仕様はコストと生産要件に照らして確認します。",
    "Full-length portrait dress image": "全身が見える縦長ドレス写真",
    "Editorial portrait or styled flat lay": "編集感のある人物写真またはスタイリング平置き",
    "Portrait garment image showing silhouette": "シルエットが分かる縦長の商品写真",
    "Full coordinated outfit": "コーディネート全体が分かる写真",
    "Movement-led portrait or detailed flat lay": "動きのある人物写真またはディテール平置き",
    "Full-length styling image showing fit": "フィット感が分かる全身スタイリング写真",
    "Lifestyle or clean lookbook image": "ライフスタイル写真またはクリーンなルックブック画像",
    "Elevated portrait with workmanship visible": "仕様が見える上品な人物写真",
    "Movement image clearly showing tier construction": "ティアード構造が分かる動きのある写真",
    "Colour-accurate image with print scale visible": "プリントサイズが分かる色再現性の高い写真",
    "Close editorial crop showing lace workmanship": "レース仕様が見える編集感のあるクローズアップ",
    "Detail-led image showing embroidery quality": "刺繍品質が分かるディテール写真",
    "End-to-end support": "一貫サポート",
    "From Buyer Brief to Shipment Coordination": "バイヤーブリーフから出荷調整まで",
    "A clear development and manufacturing workflow helps align product, quality, price and delivery requirements before bulk execution.": "明確な開発・製造ワークフローにより、量産前に商品、品質、価格、納期要件をすり合わせます。",
    "Buyer enquiry and brief": "バイヤーお問い合わせ・ブリーフ",
    "Review product category, design direction, quantity and order needs.": "商品カテゴリー、デザイン方向性、数量、注文要件を確認します。",
    "Trend and product discussion": "トレンド・商品打ち合わせ",
    "Align the commercial direction, target customer and range priorities.": "商業的な方向性、対象顧客、レンジの優先事項をすり合わせます。",
    "Fabric and trim sourcing": "生地・付属調達",
    "Evaluate suitable materials and components against design, availability and cost.": "デザイン、調達可能性、コストに照らして適切な素材・付属を確認します。",
    "Design interpretation": "デザイン解釈",
    "Translate references, sketches or specifications into a manufacturable style direction.": "参考資料、スケッチ、仕様を製造可能なスタイル方向へ落とし込みます。",
    "Costing and commercial review": "原価・商業条件確認",
    "Review fabric, workmanship, quantity, packing and target positioning.": "生地、仕様、数量、梱包、目標ポジションを確認します。",
    "Sampling and fit development": "サンプル・フィット開発",
    "Develop samples and incorporate agreed fit or construction corrections.": "サンプルを作成し、合意したフィットや構造修正を反映します。",
    "Order confirmation": "注文確認",
    "Confirm approved specifications, commercials, quantity and timeline.": "承認済み仕様、商業条件、数量、スケジュールを確認します。",
    "Pre-production approval": "量産前承認",
    "Align approved references, materials, measurements and packing instructions.": "承認済み資料、素材、寸法、梱包指示をすり合わせます。",
    "Cutting and manufacturing": "裁断・製造",
    "Plan and execute bulk production against approved specifications.": "承認済み仕様に基づき量産を計画・実行します。",
    "In-line quality checks": "インライン品質チェック",
    "Monitor measurements and workmanship during production so issues can be addressed early.": "生産中に寸法と仕様を確認し、問題を早期に対応できるようにします。",
    "Final inspection": "最終検品",
    "Review finished goods and relevant packing requirements before release.": "出荷前に完成品と関連する梱包要件を確認します。",
    "Packing and shipment coordination": "梱包・出荷調整",
    "Coordinate approved packing, order documentation and export handover requirements.": "承認済み梱包、注文書類、輸出引き渡し要件を調整します。",
    "Production capability": "生産対応力",
    "From Approved Sample to Scalable Production": "承認サンプルから量産へ",
    "Bulk production is organised around the approved product specification, material readiness, manufacturing plan and quality requirements.": "量産は、承認済み商品仕様、素材準備、生産計画、品質要件を軸に進行します。",
    "Pattern development": "パターン開発",
    "Marker planning": "マーカー計画",
    "Cutting": "裁断",
    "Bundling": "仕分け",
    "Stitching": "縫製",
    "In-line checking": "インライン確認",
    "Thread trimming": "糸切り",
    "Finishing": "仕上げ",
    "Measurement inspection": "寸法検品",
    "Final quality check": "最終品質確認",
    "Dispatch": "出荷",
    "Review incoming fabric against applicable requirements.": "入荷生地を該当要件に照らして確認します。",
    "Prepare or refine production patterns from approved inputs.": "承認済み情報から量産用パターンを準備・調整します。",
    "Plan marker placement for production requirements.": "生産要件に合わせてマーカー配置を計画します。",
    "Cut approved fabric according to the production marker.": "量産マーカーに沿って承認済み生地を裁断します。",
    "Organise cut components for controlled line movement.": "裁断パーツをライン移動しやすいよう整理します。",
    "Assemble garments against approved construction details.": "承認済み縫製仕様に沿って衣服を組み立てます。",
    "Check workmanship and relevant measurements during sewing.": "縫製中に仕様と関連寸法を確認します。",
    "Remove loose threads and prepare garments for finishing.": "余分な糸を取り除き、仕上げ工程へ進めます。",
    "Complete applicable finishing operations.": "該当する仕上げ作業を完了します。",
    "Verify relevant garment measurements against the approved reference.": "承認基準に照らして関連寸法を確認します。",
    "Review finished garments against agreed requirements.": "完成品を合意済み要件に照らして確認します。",
    "Pack goods according to confirmed buyer instructions.": "確認済みのバイヤー指示に従って梱包します。",
    "Coordinate completed goods for the agreed shipment handover.": "完成品を合意した出荷引き渡しに向けて調整します。",
    "Cutting tables": "裁断台",
    "Production lines": "生産ライン",
    "Daily output": "日産数量",
    "Sampling capacity": "サンプル対応力",
    "Lead time": "納期",
    "Fabric inspection activity": "生地検品作業",
    "Marker or cutting table": "マーカーまたは裁断台",
    "Active production line": "稼働中の生産ライン",
    "In-line workmanship review": "インライン仕様確認",
    "Finishing activity": "仕上げ作業",
    "Finished packing or dispatch preparation": "梱包済み商品または出荷準備",
    "Review the production checkpoints, buyer-specific quality fields and clearly identified compliance-verification areas.": "生産チェックポイント、バイヤー別品質項目、明確に区分されたコンプライアンス確認エリアをご確認ください。",
    "ESHA Apparels approaches sustainability through responsible-manufacturing awareness, material options, production efficiency and evidence-led communication.": "ESHA Apparelsは、責任ある製造への意識、素材選択、生産効率、証拠に基づくコミュニケーションを通じてサステナビリティに取り組みます。",
    "Quality-control workflow": "品質管理ワークフロー",
    "Evidence category": "証拠カテゴリー",
    "Status / documentation": "状況 / 書類",
    "Evidence-led compliance profile verification fields": "証拠に基づくコンプライアンスプロフィール確認項目",
    "Review available material options where sourcing, MOQ and buyer requirements permit.": "調達、MOQ、バイヤー要件が許す範囲で、利用可能な素材選択肢を確認します。",
    "Add verified waste-reduction activity and measurable outcomes when available.": "確認済みの廃棄削減活動と測定可能な成果がある場合に追加します。",
    "Add initiatives, measurements and credentials only after supporting information is available.": "裏付け情報がある場合のみ、取り組み、測定値、認証情報を追加してください。",
    "Verified workplace, material optimisation or waste-reduction activity": "確認済みの職場環境、素材最適化、廃棄削減活動",
    "Sustainability image slot": "サステナビリティ画像枠",
    "Understand ESHA Apparels’ export-oriented buyer support, documentation coordination and confirmed experience with the Japanese market.": "ESHA Apparelsの輸出向けバイヤー支援、書類調整、日本市場での確認済み経験をご確認ください。",
    "Confirmed Japanese market experience": "確認済みの日本市場経験",
    "AmeriMark Direct LLC · Kmart · Eric Jay Ltd.": "AmeriMark Direct LLC・Kmart・Eric Jay Ltd.",
    "Primark · Peacocks · George": "Primark・Peacocks・George",
    "Replace with approved Japan-market garment image and verified product details": "日本市場向け承認済み商品画像と確認済み商品詳細に差し替え",
    "Replace with approved USA-market garment image and verified product details": "米国市場向け承認済み商品画像と確認済み商品詳細に差し替え",
    "Replace with approved UK-market garment image and verified product details": "英国市場向け承認済み商品画像と確認済み商品詳細に差し替え",
    "Replace with approved South Africa-market garment image and verified product details": "南アフリカ市場向け承認済み商品画像と確認済み商品詳細に差し替え",
    "collection": "コレクション",
    "Use this page to present trade fairs, buyer meetings, sourcing events, award ceremonies and future participation plans in one clear buyer-facing view.": "このページでは、展示会、バイヤーミーティング、調達イベント、授賞式、今後の参加予定をバイヤー向けに分かりやすく掲載できます。",
    "ESHA Apparels received Reliance Best Vendor / Best Vendor Performance recognition, supporting the company’s profile as a dependable garment manufacturing partner.": "ESHA ApparelsはReliance Best Vendor / Best Vendor Performanceの表彰を受けており、信頼できる衣料製造パートナーとしての会社プロフィールを支える実績です。",
    "Reliance vendor recognition": "Relianceベンダー表彰",
    "India Apparel & Accessories Fair 2026": "India Apparel & Accessories Fair 2026",
    "29–31 July 2026": "2026年7月29日〜31日",
    "Confirmed participation": "参加確定",
    "ESHA Apparels will participate in the India Apparel & Accessories Fair 2026 at Shinjuku Sumitomo Building Triangle Square, Tokyo, Japan. Visit Booth No. 11 to discuss women’s garment manufacturing, export-ready production and upcoming buyer requirements.": "ESHA Apparelsは、東京・新宿住友ビル三角広場で開催されるIndia Apparel & Accessories Fair 2026に出展します。ブース番号11にて、婦人服製造、輸出対応の量産体制、今後のバイヤー要件についてご相談いただけます。",
    "Completed participation, recognition and buyer-facing moments.": "完了済みの参加実績、表彰、バイヤー向け機会。",
    "Planned opportunities to be added after schedule confirmation.": "スケジュール確定後に今後の機会を追加します。",
    "[Month / Year]": "[月 / 年]",
    "[Planned month / year]": "[予定月 / 年]",
    "[Planned date]": "[予定日]",
    "View ESHA Apparels’ Reliance Best Vendor recognition, supported by the award trophy, certificate and ceremony photograph.": "トロフィー、証明書、授賞式写真とともに、ESHA ApparelsのReliance Best Vendor表彰をご確認ください。",
    "Complete selected gallery": "選定ギャラリー全体",
    "View More Products": "さらに商品を見る",
    "of": "件中",
    "Fabric and trim library": "生地・付属ライブラリー",
    "Colour-accurate cotton texture macro": "色再現性の高いコットン素材のマクロ写真",
    "Portrait garment photograph showing full silhouette": "全体のシルエットが分かる縦長の商品写真",
    "Portrait or on-model top photograph": "縦長または着用イメージのトップス写真",
    "Portrait garment photograph with trim visible": "付属ディテールが見える縦長の商品写真",
    "Full outfit image showing both coordinated pieces": "上下のコーディネート全体が分かる写真",
    "Portrait or movement image showing skirt shape": "スカートの形が分かる縦長または動きのある写真",
    "Full-length image showing fit and leg shape": "フィットとレッグシルエットが分かる全身写真",
    "Portrait image with embroidery detail visible": "刺繍ディテールが見える縦長写真",
    "Clean on-model or flat-lay image": "クリーンな着用写真または平置き写真",
    "Full garment image with embroidery in focus": "刺繍を中心に見せる全体商品写真",
    "Full coordinated outfit in a portrait frame": "縦長フレームで見せるコーディネート全体写真",
    "Portrait image with lace placement visible": "レース配置が分かる縦長写真",
    "Full-length image showing print and fit": "プリントとフィットが分かる全身写真",
    "Editorial portrait with garment detail preserved": "商品ディテールを保った編集感のある人物写真",
    "Portrait crop showing surface workmanship": "表面仕様が分かる縦長のクローズアップ",
    "Relaxed on-model image showing silhouette": "リラックス感のある着用シルエット写真",
    "Placeholder for women’s printed dress style 01": "婦人向けプリントドレス スタイル01のプレースホルダー",
    "Placeholder for women’s solid top style 01": "婦人向け無地トップス スタイル01のプレースホルダー",
    "Placeholder for women’s lace-detail tunic style 01": "婦人向けレースディテールチュニック スタイル01のプレースホルダー",
    "Placeholder for women’s printed co-ord set style 01": "婦人向けプリントセットアップ スタイル01のプレースホルダー",
    "Placeholder for women’s tiered skirt style 01": "婦人向けティアードスカート スタイル01のプレースホルダー",
    "Placeholder for women’s solid bottom style 01": "婦人向け無地ボトムス スタイル01のプレースホルダー",
    "Placeholder for women’s embroidered dress style 02": "婦人向け刺繍ドレス スタイル02のプレースホルダー",
    "Placeholder for women’s printed blouse style 02": "婦人向けプリントブラウス スタイル02のプレースホルダー",
    "Placeholder for women’s embroidered tunic style 02": "婦人向け刺繍チュニック スタイル02のプレースホルダー",
    "Placeholder for women’s solid co-ord set style 02": "婦人向け無地セットアップ スタイル02のプレースホルダー",
    "Placeholder for women’s lace-detail skirt style 02": "婦人向けレースディテールスカート スタイル02のプレースホルダー",
    "Placeholder for women’s printed bottom style 02": "婦人向けプリントボトムス スタイル02のプレースホルダー",
    "Placeholder for women’s lace-detail dress style 03": "婦人向けレースディテールドレス スタイル03のプレースホルダー",
    "Placeholder for women’s embroidered top style 03": "婦人向け刺繍トップス スタイル03のプレースホルダー",
    "Placeholder for women’s casual solid tunic style 01": "婦人向けカジュアル無地チュニック スタイル01のプレースホルダー",
    "Our standard MOQ is approximately 700 pieces per style. Final feasibility depends on fabric, design, colour split and order requirements.": "標準MOQは1型あたり約700枚です。最終的な可否は生地、デザイン、色分け、注文要件により異なります。",
    "Our approximate FOB positioning is USD 3–12 per piece, depending on style, fabric, workmanship, packing and order volume.": "FOB価格帯の目安は1枚あたり3〜12米ドルで、スタイル、生地、仕様、梱包、注文数量により異なります。",
    "Yes. We can evaluate buyer references, sketches or specifications for development, subject to technical feasibility and agreed ownership requirements.": "はい。技術的な実現可能性と所有権条件の合意を前提に、バイヤーの参考資料、スケッチ、仕様書をもとに開発可否を確認できます。",
    "Fabric and trim options can be reviewed against the design, season, sourcing conditions and quantity.": "生地・付属の選択肢は、デザイン、シーズン、調達条件、数量に照らして確認できます。",
    "ESHA Apparels has capacity of up to 250,000 pieces per month across two factories, supported by 575 sewing machines and subject to style mix and production planning.": "ESHA Apparelsは2工場合計で月産最大250,000枚、575台のミシンを備えています。実際の対応力はスタイル構成と生産計画により異なります。",
    "Repeat orders can be evaluated against fabric availability, line planning, approved specifications and the required delivery window.": "リピート注文は、生地の在庫・調達可能性、ライン計画、承認済み仕様、希望納期に照らして確認できます。",
    "Exclusive product development can be considered subject to a clear written agreement, commercial feasibility and ownership terms.": "専用商品の開発は、明確な書面合意、商業的な実現可能性、所有権条件を前提に検討できます。",
    "ESHA Apparels has international export experience, including the Japanese market. Additional verified markets will be added to this profile.": "ESHA Apparelsは日本市場を含む海外輸出の経験があります。追加の確認済み市場は今後プロフィールに追記します。",
    "Quality checkpoints cover fabric, pre-production review, in-line inspection, measurements, finishing, final inspection and packing verification.": "品質チェックポイントは、生地確認、量産前確認、インライン検品、寸法確認、仕上げ、最終検品、梱包確認を含みます。",
    "Please share the product category, design direction, fabric or material notes where available, size range, quantity, colour split, packing and delivery requirements.": "商品カテゴリー、デザイン方向、生地・素材メモ、サイズレンジ、数量、色分け、梱包、納品要件をご共有ください。",
    "Factory meeting requests can be reviewed in advance. Visit timing, location and access details are confirmed directly with ESHA Apparels.": "工場面談のご希望は事前に確認できます。訪問日時、場所、入場条件はESHA Apparelsと直接確認します。",
    "Contact ESHA Apparels": "ESHA Apparelsへのお問い合わせ",
    "LinkedIn": "LinkedIn",
    "Instagram": "Instagram",
    "Other social media": "その他SNS",
    "[LinkedIn URL]": "[LinkedIn URL]",
    "[Instagram URL]": "[Instagram URL]",
    "[Social media URL]": "[SNS URL]",
    "Company logo for buyer contact section": "バイヤー問い合わせ欄用の会社ロゴ",
    "Print Profile": "プロフィールを印刷",
    "name@company.com": "name@company.com",
    "Your enquiry is ready for review. Connect a form service before sending live submissions.": "お問い合わせ内容を確認できる状態です。実際に送信するにはフォーム送信サービスを接続してください。",
    "Choose a JPG, JPEG, PNG or WebP image.": "JPG、JPEG、PNG、WebP画像を選択してください。",
    "Frequently asked buyer questions": "バイヤーからのよくある質問",
    "Gallery filters": "ギャラリーフィルター",
    "Let’s build your next collection": "次のコレクションを一緒に形にしましょう",
    "About ESHA Apparels": "ESHA Apparelsについて",
    "Award and recognition": "受賞・表彰",
    "Buyer segments we serve": "対応可能なバイヤー層",
    "Companies ESHA Apparels works with": "ESHA Apparelsが取引・関係する企業",
    "Compliance evidence and buyer requirements": "コンプライアンス証明とバイヤー要件",
    "Cover — Women’s Fashion Manufacturing at Scale": "カバー — 婦人服の量産製造",
    "ESHA Apparels at a glance": "ESHA Apparels 概要",
    "ESHA Apparels past, present and future": "ESHA Apparelsの過去・現在・未来",
    "ESHA Apparels quality-control process flow from order receiving to shipment dispatch": "受注から出荷までのESHA Apparels品質管理工程",
    "ESHA Apparels team member holding the Reliance award at the ceremony": "授賞式でReliance表彰を手にするESHA Apparelsチームメンバー",
    "Export and buyer experience": "輸出・バイヤー対応経験",
    "Fabrics and value additions": "生地・付加価値加工",
    "Selected collections and product gallery": "選定コレクション・商品ギャラリー",
    "Sustainability and responsible manufacturing": "サステナビリティと責任ある製造",
    "Two manufacturing factories": "2つの製造工場",
    "Two-factory system benefits": "2工場体制の利点",
    "Why buyers choose ESHA Apparels": "ESHA Apparelsが選ばれる理由",
    "ESHA Apparels logo": "ESHA Apparelsロゴ",
    "Image editing controls": "画像編集コントロール",
    "Breadcrumb": "パンくずリスト",
    "ESHA buyer help": "ESHAバイヤーヘルプ",
    "Language switcher": "言語切替",
    "Primary navigation": "メインナビゲーション",
    "Recommended ESHA Apparels garment, team or factory closing image": "ESHA Apparelsの衣料・チーム・工場クロージング画像",
    "Recommended ESHA Apparels team photograph": "ESHA Apparelsチーム写真",
    "Recommended Factory One exterior photograph": "第1工場外観写真",
    "Recommended Factory Two exterior photograph": "第2工場外観写真",
    "Recommended cotton fabric close-up": "コットン素材のクローズアップ",
    "Recommended responsible manufacturing photograph": "責任ある製造を示す写真",
    "Representative women’s woven dress for USA export market": "米国輸出市場向け婦人ウーブンドレス代表画像",
    "Representative printed cotton midi dress for Japan export market": "日本輸出市場向けプリントコットン・ミディドレス代表画像",
    "Representative women’s top for UK and Europe export market": "英国・欧州市場向け婦人トップス代表画像",
    "Representative women’s tunic for South Africa export market": "南アフリカ市場向け婦人チュニック代表画像",
    "Reliance Best Vendor Performance 2022–2023 award trophy and certificate for ESHA Apparels": "ESHA ApparelsのReliance Best Vendor Performance 2022–2023トロフィーと証明書",
    "AmeriMark Direct logo": "AmeriMark Directロゴ",
    "D-Mart logo": "D-Martロゴ",
    "Eric Jay Ltd. wordmark placeholder": "Eric Jay Ltd.ワードマークプレースホルダー",
    "Ethnicity logo": "Ethnicityロゴ",
    "George wordmark": "Georgeワードマーク",
    "Kmart logo": "Kmartロゴ",
    "Peacocks wordmark": "Peacocksワードマーク",
    "Primark wordmark": "Primarkワードマーク",
    "Reliance Retail logo": "Reliance Retailロゴ",
    "Japan — Confirmed Japanese market experience": "日本 — 確認済みの日本市場経験",
    "Marubeni": "丸紅",
    "Marubeni logo": "丸紅ロゴ",
    "Japan — Marubeni": "日本 — 丸紅",
    "South Africa — [Buyer / company name]": "南アフリカ — [バイヤー / 企業名]",
    "UK — Primark · Peacocks · George": "英国 — Primark・Peacocks・George",
    "USA — AmeriMark Direct LLC · Kmart · Eric Jay Ltd.": "米国 — AmeriMark Direct LLC・Kmart・Eric Jay Ltd.",
    "Choose image": "画像を選択",
    "Replace": "差し替え",
    "Remove": "削除",
    "Loading saved image…": "保存された画像を読み込み中…",
    "Closing image": "クロージング画像",
    "Wide team, garment collection or factory image with clear text area": "テキストを配置しやすい、チーム・商品コレクション・工場のワイド画像",
    "Profile": "プロフィール",
    "Capabilities": "対応力",
    "Contact placeholders": "連絡先プレースホルダー",
    "Women’s fashion manufacturing at scale.": "婦人服ファッションの量産対応。",
    "Commercial, trend-focused and export-ready women’s fashion for buyer programmes.": "バイヤープログラム向けの商業性、トレンド性、輸出対応を備えた婦人服。",
    "Items shown in square brackets are editable placeholders and must be verified before publication.": "角括弧内の項目は編集用プレースホルダーです。公開前に必ず確認してください。",
    "Company / team image": "会社・チーム画像",
    "Leadership, merchandising or cross-functional team": "経営、マーチャンダイジング、または部門横断チーム",
    "Women’s western wear and fast-fashion focus": "婦人向けウェスタンウェアとファストファッションに注力",
    "Two factories with up to 250,000 pieces monthly capacity": "2工場で月産最大250,000枚に対応",
    "575 sewing machines supporting scalable production": "575台のミシンで量産を支援",
    "Reliance Best Vendor recognition": "Reliance Best Vendor表彰",
    "Stronger trend-to-sample development support": "トレンドからサンプル化までの開発支援を強化",
    "More structured buyer communication and documentation": "より体系的なバイヤー連絡と書類対応",
    "Expanded repeat-order and range-development support": "リピート注文とレンジ開発支援の拡充",
    "Practical progress in responsible manufacturing": "責任ある製造に向けた実践的な進展",
    "Retail chains": "小売チェーン",
    "Category and collection programmes assessed by brief.": "カテゴリーやコレクション案件をブリーフに基づいて確認します。",
    "Fashion brands": "ファッションブランド",
    "Brand-led women’s wear development and production.": "ブランド主導の婦人服開発・生産。",
    "Importers": "輸入業者",
    "Export-oriented product and order coordination.": "輸出向けの商品・注文調整。",
    "Distributors": "販売代理店",
    "Commercial ranges evaluated for the target market.": "対象市場に合わせて商業レンジを確認します。",
    "Buying houses": "バイイングハウス",
    "Specification-led development and manufacturing support.": "仕様に基づく開発・製造支援。",
    "Wholesalers": "卸売業者",
    "Scalable commercial fashion programmes.": "量産対応可能な商業ファッションプログラム。",
    "Department stores": "百貨店",
    "Buyer-specific category opportunities reviewed by range.": "バイヤー別のカテゴリー機会をレンジごとに確認します。",
    "E-commerce fashion businesses": "ECファッション事業者",
    "Trend-focused product briefs assessed for feasible volume.": "トレンド重視の商品ブリーフを、実現可能な数量に照らして確認します。",
    "Emerging brands": "成長中のブランド",
    "Commercially viable orders reviewed against standard MOQ and development needs.": "標準MOQと開発要件に照らし、商業的に成立する注文を確認します。",
    "Factory exterior": "工場外観",
    "Manufacturing infrastructure": "製造インフラ",
    "Two Factories. One Integrated Production System.": "2つの工場、1つの統合生産システム。",
    "Factory cinemagraph — quiet precision in garment manufacturing": "工場シネマグラフ — 衣料製造における静かな精密さ",
    "Factory study · quiet precision": "工場の所作・静かな精密さ",
    "Craftsmanship in motion": "動きに宿る職人技",
    "Quiet Precision": "静かな精密さ",
    "A restrained portrait of the details behind every garment.": "一着一着を支える細部を、抑制された映像表現で描きます。",
    "Cinemagraph scenes": "シネマグラフのシーン",
    "Needle Rhythm": "針のリズム",
    "Needle, presser foot and thread move in a measured cadence while the machine remains perfectly composed.": "ミシン全体は静止したまま、針、押さえ金、糸だけが整ったリズムで動きます。",
    "Fabric & Stitch": "生地とステッチ",
    "Premium cloth advances almost imperceptibly as precise stitches form one by one.": "上質な生地がわずかに進み、精密なステッチが一針ずつ形になります。",
    "Hand & Material": "手と素材",
    "Fingertips gently settle the fabric, allowing the material to relax naturally.": "指先が生地を優しく整え、素材本来の自然な落ち着きを引き出します。",
    "Embroidery Detail": "刺繍ディテール",
    "Thread builds restrained surface detail through controlled, repeatable movement.": "制御された反復動作によって、糸が繊細な表面ディテールを形づくります。",
    "Quality Light": "品質を照らす光",
    "A soft inspection light reveals texture, stitching, buttons, lace and construction.": "柔らかな検品光が、生地感、縫製、ボタン、レース、構造の品質を映し出します。",
    "Considered Packing": "丁寧な梱包",
    "A folded garment, ribbon and shipment tag settle into their final presentation.": "畳まれた衣服、リボン、出荷タグが、最終的な姿へ静かに整います。",
    "Finished Form": "完成したフォルム",
    "The completed garment rests in quiet suspension with only natural fabric movement.": "完成した衣服は静かに浮かび、素材本来のごく小さな動きだけを見せます。",
    "Factory One": "第1工場",
    "Factory Two": "第2工場",
    "Address": "住所",
    "Area": "面積",
    "Unit type": "ユニット種別",
    "Dedicated manufacturing unit": "専用製造ユニット",
    "City": "都市",
    "Jaipur, India": "インド・ジャイプール",
    "Two dedicated manufacturing units": "2つの専用製造ユニット",
    "One showroom": "1つのショールーム",
    "Combined production area of 50,000 sq. ft.": "合計生産面積50,000平方フィート",
    "Sitapura, Jaipur manufacturing base": "ジャイプール・シタプラの製造拠点",
    "Dedicated production planning": "専任の生産計画",
    "Parallel order handling": "複数注文の並行対応",
    "Flexible style allocation": "柔軟なスタイル配分",
    "Quality standardisation": "品質標準化",
    "Production-risk management": "生産リスク管理",
    "Cotton": "コットン",
    "Cotton slub": "コットンスラブ",
    "Cotton dobby": "コットンドビー",
    "Cotton flax": "コットンフラックス",
    "Cotton salli": "コットンサリー",
    "Rayon": "レーヨン",
    "Viscose": "ビスコース",
    "Linen blends": "リネン混",
    "Printed woven fabrics": "プリント織物",
    "Textured fabrics": "表面感のある素材",
    "Lightweight summer fabrics": "軽量サマー素材",
    "Buyer-nominated fabrics": "バイヤー指定素材",
    "Cotton lace": "コットンレース",
    "Embroidery": "刺繍",
    "Frills": "フリル",
    "Tiering": "ティアード",
    "Pintucks": "ピンタック",
    "Gathers": "ギャザー",
    "Smocking": "スモッキング",
    "Fabric mixing": "素材ミックス",
    "Contrast panels": "配色パネル",
    "Decorative buttons": "装飾ボタン",
    "Trims": "付属",
    "Elasticated construction": "ゴム仕様",
    "Surface detailing": "表面ディテール",
    "Fabric": "生地",
    "Sizes": "サイズ",
    "Colours": "カラー",
    "Material optimisation": "素材の最適化",
    "Consider material use and marker planning within production requirements.": "生産要件に合わせて素材使用量とマーカー計画を検討します。",
    "Production efficiency": "生産効率",
    "Plan workflow and allocation with attention to operational efficiency.": "運用効率を意識して工程と配分を計画します。",
    "Waste-reduction initiatives": "廃棄削減の取り組み",
    "Sustainable fabric options": "サステナブル素材の選択肢",
    "Verified information only": "確認済み情報のみ",
    "Sustainability evidence area": "サステナビリティ証明エリア",
    "Verification area": "確認エリア",
    "Evidence-led compliance profile": "エビデンスに基づくコンプライアンスプロフィール",
    "Compliance certification": "コンプライアンス認証",
    "Social audit": "社会監査",
    "Factory audit status": "工場監査状況",
    "Environmental certification": "環境認証",
    "Sustainability initiative": "サステナビリティ施策",
    "Waste management": "廃棄物管理",
    "Renewable energy": "再生可能エネルギー",
    "Water saving": "節水",
    "Past Participation and Upcoming Opportunities": "過去の参加実績と今後の機会",
    "Completed participation, recognition and buyer-facing moments.": "完了済みの参加、表彰、バイヤー向け機会。",
    "Planned opportunities to be added after schedule confirmation.": "予定が確定次第、今後の機会を追加します。",
    "Editable placeholder": "編集用プレースホルダー",
    "Buyer questions": "バイヤーからのよくある質問",
    "What is your minimum order quantity?": "最小注文数量はどのくらいですか？",
    "What is your approximate price range?": "価格帯の目安はどのくらいですか？",
    "Can you develop products from references or sketches?": "参考画像やスケッチから商品開発できますか？",
    "Can you source fabrics and trims?": "生地や付属の調達は可能ですか？",
    "What is your monthly production capacity?": "月間生産能力はどのくらいですか？",
    "Can you handle repeat orders?": "リピート注文に対応できますか？",
    "Do you manufacture buyer-exclusive styles?": "バイヤー専用スタイルの製造は可能ですか？",
    "What markets do you export to?": "どの市場へ輸出していますか？",
    "How do you manage quality control?": "品質管理はどのように行っていますか？",
    "What information is required for costing?": "見積もりにはどの情報が必要ですか？",
    "Can buyers visit the factories?": "バイヤーは工場訪問できますか？",
    "Up to": "最大",
    "Approx.": "約",
    "USD": "米ドル",
    "Up to 250,000": "最大250,000",
    "USD 3–12": "3〜12米ドル",
    "Approx. 700": "約700",
    "International": "海外",
    "250,000+": "250,000枚以上",
    "700 pcs": "700枚",
    "USD $3–12": "3〜12米ドル",
    "Women's Fashion": "婦人服ファッション",
    "Monthly Production Capacity": "月間生産能力",
    "Industrial Sewing Machines": "工業用ミシン",
    "Manufacturing Facilities": "製造施設",
    "Standard MOQ per Style": "1型あたりの標準MOQ",
    "Typical FOB Price Range": "FOB価格帯の目安",
    "Manufacturing Specialist": "製造専門企業",
    "Rotating ESHA Apparels business metrics": "ESHA Apparelsの主要事業指標",
    "Responsible manufacturing awareness": "責任ある製造への意識",
    "Workplace standards": "職場基準",
    "Buyer-specific compliance support": "バイヤー別コンプライアンス対応",
    "Traceability and documentation support": "トレーサビリティ・書類対応",
    "RESPONSIBLE MANUFACTURING AWARENESS": "責任ある製造への意識",
    "WORKPLACE STANDARDS": "職場基準",
    "BUYER-SPECIFIC COMPLIANCE SUPPORT": "バイヤー別コンプライアンス対応",
    "TRACEABILITY AND DOCUMENTATION SUPPORT": "トレーサビリティ・書類対応",
    "Consider responsible production expectations within operational planning.": "責任ある生産に関する期待事項を、日々の運用計画の中で考慮します。",
    "Support the review of applicable workplace requirements and verified records.": "適用される職場要件と確認済み記録のレビューを支援します。",
    "Evaluate buyer compliance requirements against current factory capability and documentation.": "バイヤーのコンプライアンス要件を、現在の工場能力と書類体制に照らして確認します。",
    "Support applicable traceability and documentation requests where available.": "対応可能な範囲で、トレーサビリティおよび書類提出の要望を支援します。",
    "Certification and audit information remains clearly marked until documentary verification is supplied.": "認証および監査情報は、証明書類が提出されるまで明確に未確認として表示されます。",
    "[Compliance certification]": "[コンプライアンス認証]",
    "[Social audit]": "[社会監査]",
    "[Factory audit status]": "[工場監査状況]",
    "[Environmental certification]": "[環境認証]",
    "[Sustainability initiative]": "[サステナビリティ施策]",
    "[Waste management system]": "[廃棄物管理体制]",
    "[Renewable energy usage]": "[再生可能エネルギー利用]",
    "[Water-saving programme]": "[節水プログラム]",
    "[Country]": "[国名]",
    "[COUNTRY]": "[国名]",
    "Buyer-support services are confirmed programme by programme. Editable verification notes are retained in the central data file.": "バイヤー支援サービスはプログラムごとに確認します。編集可能な確認メモは中央データファイルで管理されます。",
    "Your full name": "お名前",
    "Your business or brand": "会社名またはブランド名",
    "Include country code": "国番号を含めて入力",
    "Approximate pieces per style": "1型あたりのおおよその枚数",
    "Describe your collection, quantity, target market and key requirements": "コレクション内容、数量、対象市場、主要要件をご記入ください",
    "Standard MOQ is approximately 700 pieces per style, subject to requirements.": "標準MOQは1型あたり約700枚です。最終的な可否は要件により異なります。",
    "I confirm that I am authorised to share this enquiry and agree to be contacted about it.": "この問い合わせ内容を共有する権限があり、本件について連絡を受けることに同意します。",
    "Detailed costing is prepared after reviewing the design, workmanship, quantity, packing and order requirements.": "詳細なお見積もりは、デザイン、仕様、数量、梱包、注文要件を確認したうえで作成します。",
    "Retail chain": "小売チェーン",
    "Fashion brand": "ファッションブランド",
    "Importer": "輸入業者",
    "Distributor": "販売代理店",
    "Buying house": "バイイングハウス",
    "Wholesaler": "卸売業者",
    "Department store": "百貨店",
    "E-commerce business": "EC事業者",
    "Emerging brand": "成長中ブランド",
    "[Other buyer type]": "[その他のバイヤー種別]",
    "[Other product category]": "[その他の商品カテゴリー]",
    "Reliance award proof": "Reliance表彰の証明",
    "Award ceremony": "授賞式",
    "Award ceremony photograph": "授賞式写真",
    "Reliance award trophy and certificate": "Reliance表彰トロフィーと証明書",
    "Reliance Best Vendor Award 2022–23": "Reliance ベストベンダー賞 2022–23",
    "Best Vendor Performance 2022–2023 · Mass-Wovens Category": "Best Vendor Performance 2022–2023・Mass-Wovensカテゴリー"
  };

  const japaneseTranslationsByLowercase = Object.fromEntries(
    Object.entries(japaneseTranslations).map(([key, value]) => [key.toLowerCase(), value]),
  );

  const originalTextNodes = new WeakMap();
  const originalAttributes = new WeakMap();
  const textAttributeNames = ['placeholder', 'aria-label', 'title', 'alt'];
  const ignoredTags = new Set(['SCRIPT', 'STYLE', 'NOSCRIPT', 'SVG']);

  function translateTextValue(value, language) {
    if (language === 'en') return value;
    const compact = value.replace(/\s+/g, ' ').trim();
    if (!compact) return value;
    const translated =
      japaneseTranslations[compact] ||
      japaneseTranslationsByLowercase[compact.toLowerCase()] ||
      translatePatternValue(compact) ||
      translateBracketPlaceholder(compact);
    if (!translated) return value;
    const leading = value.match(/^\s*/)?.[0] || '';
    const trailing = value.match(/\s*$/)?.[0] || '';
    return leading + translated + trailing;
  }

  function translatePatternValue(compact) {
    const fileReplacement = compact.match(/^Choose a JPG, PNG or WebP replacement for (.+)$/i);
    if (fileReplacement) {
      return 'JPG、PNG、WebP画像を選択して差し替え：' + translateTextValue(fileReplacement[1], 'ja');
    }
    const replacement = compact.match(/^Choose a replacement for: (.+)$/i);
    if (replacement) {
      return '差し替える画像を選択：' + translateTextValue(replacement[1], 'ja');
    }
    const openDetails = compact.match(/^Open details for (.+)$/i);
    if (openDetails) {
      return translateTextValue(openDetails[1], 'ja') + 'の詳細を開く';
    }
    const routeLabel = compact.match(/^(.+?)\\s+—\\s+(.+)$/);
    if (routeLabel) {
      return translateTextValue(routeLabel[1], 'ja') + ' — ' + translateTextValue(routeLabel[2], 'ja');
    }
    const logoLabel = compact.match(/^(.+?) logo$/i);
    if (logoLabel) {
      return logoLabel[1] + 'ロゴ';
    }
    const wordmarkLabel = compact.match(/^(.+?) wordmark$/i);
    if (wordmarkLabel) {
      return wordmarkLabel[1] + 'ワードマーク';
    }
    return '';
  }

  function translateBracketPlaceholder(compact) {
    const productName = compact.match(/^\[Product name (\d+)\]( image)?$/i);
    if (productName) {
      return productName[2] ? '[商品名 ' + productName[1] + '] 画像' : '[商品名 ' + productName[1] + ']';
    }
    const styleCode = compact.match(/^\[Style code (\d+)\]$/i);
    if (styleCode) return '[スタイルコード ' + styleCode[1] + ']';
    if (/^\[Approximate FOB price range\]$/i.test(compact)) return '[FOB価格帯の目安]';
    if (/^\[Fabric\]$/i.test(compact)) return '[生地]';
    if (/^\[MOQ\]$/i.test(compact)) return '[MOQ]';
    if (/^\[Available sizes\]$/i.test(compact)) return '[対応サイズ]';
    if (/^\[Colour options\]$/i.test(compact)) return '[カラー展開]';
    if (/^\[Short product note\]$/i.test(compact)) return '[商品メモ]';
    return '';
  }

  function walkTextNodes(root, callback) {
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
      acceptNode(node) {
        const parent = node.parentElement;
        if (!parent) return NodeFilter.FILTER_REJECT;
        if (ignoredTags.has(parent.tagName)) return NodeFilter.FILTER_REJECT;
        if (parent.closest('.language-switch')) return NodeFilter.FILTER_REJECT;
        if (!node.nodeValue || !node.nodeValue.trim()) return NodeFilter.FILTER_REJECT;
        return NodeFilter.FILTER_ACCEPT;
      },
    });
    const nodes = [];
    while (walker.nextNode()) nodes.push(walker.currentNode);
    nodes.forEach(callback);
  }

  function applyLanguage(language) {
    document.documentElement.lang = language === 'ja' ? 'ja' : 'en';
    document.body.dataset.language = language;

    walkTextNodes(document.body, (node) => {
      if (!originalTextNodes.has(node)) originalTextNodes.set(node, node.nodeValue);
      const original = originalTextNodes.get(node);
      node.nodeValue = language === 'en' ? original : translateTextValue(original, language);
    });

    document.querySelectorAll('*').forEach((element) => {
      if (element.closest('.language-switch')) return;
      textAttributeNames.forEach((attributeName) => {
        if (!element.hasAttribute(attributeName)) return;
        let store = originalAttributes.get(element);
        if (!store) {
          store = {};
          originalAttributes.set(element, store);
        }
        if (!store[attributeName]) store[attributeName] = element.getAttribute(attributeName);
        const original = store[attributeName];
        element.setAttribute(
          attributeName,
          language === 'en' ? original : translateTextValue(original, language),
        );
      });
    });

    document.querySelectorAll('[data-lang-option]').forEach((button) => {
      const active = button.getAttribute('data-lang-option') === language;
      button.classList.toggle('is-active', active);
      button.setAttribute('aria-pressed', String(active));
    });

    try {
      window.localStorage.setItem('esha-language', language);
    } catch {
      // Ignore storage errors in privacy-restricted browsers.
    }
  }

  document.querySelectorAll('[data-lang-option]').forEach((button) => {
    button.addEventListener('click', () => {
      applyLanguage(button.getAttribute('data-lang-option') || 'en');
    });
  });

  let savedLanguage = 'en';
  try {
    savedLanguage = window.localStorage.getItem('esha-language') || 'en';
  } catch {
    savedLanguage = 'en';
  }
  if (savedLanguage === 'ja') applyLanguage('ja');

  const conciergeRouteFiles = {
    "/": "index.html",
    "/about": "about.html",
    "/facilities": "facilities.html",
    "/products": "products.html",
    "/quality-compliance": "quality-compliance.html",
    "/sustainability": "sustainability.html",
    "/export": "export.html",
    "/events": "events.html",
    "/awards": "awards.html",
    "/contact": "contact.html",
    "/company-profile": "company-profile.html",
  };

  const conciergeSteps = {
    start: {
      eyebrow: "ESHA Concierge",
      message: "What are you looking for?",
      helper: "Choose a path. I’ll take you to the exact section.",
      options: [
        { label: "Compare", detail: "Fast buyer review", next: "comparison" },
        { label: "Products", detail: "Categories + gallery", next: "products" },
        { label: "Factories", detail: "Capacity + setup", next: "capacity" },
        { label: "Quality", detail: "QC + compliance", next: "quality" },
        { label: "Export", detail: "Markets + buyers", next: "export" },
        { label: "Enquiry", detail: "Send requirements", href: "/contact#contact", tone: "primary" },
      ],
    },
    comparison: {
      eyebrow: "Buyer review",
      message: "Jump to the proof buyers usually check first.",
      helper: "Capacity, product fit, quality and recognition — no long browsing needed.",
      options: [
        { label: "Company snapshot", detail: "Numbers and positioning", href: "/#snapshot" },
        { label: "Buyer decision flow", detail: "Best-fit sourcing path", href: "/#buyer-decision-flow" },
        { label: "Factory setup", detail: "Two facilities and scale", href: "/facilities#factories" },
        { label: "Quality system", detail: "QC checkpoints", href: "/quality-compliance#quality" },
        { label: "Award proof", detail: "Reliance recognition", href: "/awards#awards" },
        { label: "Send enquiry", detail: "Share quantity + category", href: "/contact#contact", tone: "primary" },
      ],
    },
    capacity: {
      eyebrow: "Production scale",
      message: "2 factories · 575 machines · up to 250,000 pcs/month.",
      helper: "Capacity depends on style mix, fabric, workmanship and planning.",
      options: [
        { label: "Open facilities", detail: "Factory details", href: "/facilities#factories", tone: "primary" },
        { label: "Production process", detail: "Factory workflow", href: "/facilities#process" },
        { label: "Ask production", detail: "Send requirement", href: "/contact#contact" },
      ],
    },
    products: {
      eyebrow: "Product direction",
      message: "Where should we take you?",
      helper: "Commercial women’s western wear, fast-fashion and export-ready woven styles.",
      options: [
        { label: "Categories", detail: "Dresses, tops, co-ords", href: "/products#products", tone: "primary" },
        { label: "Selected gallery", detail: "Style examples", href: "/products#gallery" },
        { label: "Fabrics", detail: "Materials + value-adds", href: "/products#materials" },
        { label: "Enquire style", detail: "Share product brief", href: "/contact#contact" },
      ],
    },
    quality: {
      eyebrow: "Buyer assurance",
      message: "Quality, compliance and responsible manufacturing.",
      helper: "Choose the evidence area you want to review.",
      options: [
        { label: "Quality system", detail: "QC process", href: "/quality-compliance#quality", tone: "primary" },
        { label: "Compliance", detail: "Audit readiness", href: "/quality-compliance#compliance" },
        { label: "Sustainability", detail: "Responsible practices", href: "/sustainability#sustainability" },
        { label: "Ask for documents", detail: "Contact team", href: "/contact#contact" },
      ],
    },
    export: {
      eyebrow: "Export route",
      message: "Review markets, buyers and export support.",
      helper: "Jump to the map or supporting market details.",
      options: [
        { label: "Export map", detail: "Global network", href: "/export#export-network", tone: "primary" },
        { label: "Market support", detail: "Buyer services", href: "/export#market-experience" },
        { label: "Award proof", detail: "Reliance award", href: "/awards#awards" },
        { label: "Contact team", detail: "Begin enquiry", href: "/contact#contact" },
      ],
    },
  };

  function conciergeTranslate(value) {
    return translateTextValue(value, document.body.dataset.language || savedLanguage || "en");
  }

  function conciergeHref(href) {
    if (!href) return "#";
    const match = href.match(/^([^?#]+)(.*)$/);
    const path = match ? match[1] : href;
    const suffix = match ? match[2] : "";
    return (conciergeRouteFiles[path] || href) + suffix;
  }

  function setupConcierge() {
    const concierge = document.querySelector("[data-concierge]");
    if (!concierge) return;

    const trigger = concierge.querySelector("[data-concierge-trigger]");
    const panel = concierge.querySelector(".concierge-panel");
    const close = concierge.querySelector("[data-concierge-close]");
    const back = concierge.querySelector("[data-concierge-back]");
    const restart = concierge.querySelector("[data-concierge-restart]");
    const eyebrow = concierge.querySelector("[data-concierge-eyebrow]");
    const message = concierge.querySelector("[data-concierge-message]");
    const helper = concierge.querySelector("[data-concierge-helper]");
    const options = concierge.querySelector("[data-concierge-options]");
    if (!trigger || !panel || !options || !message) return;

    let currentStep = "start";
    let history = [];

    const setOpen = (open) => {
      concierge.classList.toggle("is-open", open);
      trigger.setAttribute("aria-expanded", String(open));
      panel.setAttribute("aria-hidden", String(!open));
      if (open) {
        window.setTimeout(() => {
          const first = options.querySelector("button, a");
          first?.focus?.({ preventScroll: true });
        }, 80);
      }
    };

    const makeArrow = () => {
      const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
      svg.setAttribute("viewBox", "0 0 24 24");
      svg.setAttribute("aria-hidden", "true");
      const path = document.createElementNS("http://www.w3.org/2000/svg", "path");
      path.setAttribute("d", "M5 12h14m-6-6 6 6-6 6");
      path.setAttribute("fill", "none");
      path.setAttribute("stroke", "currentColor");
      path.setAttribute("stroke-width", "1.6");
      path.setAttribute("stroke-linecap", "round");
      path.setAttribute("stroke-linejoin", "round");
      svg.appendChild(path);
      return svg;
    };

    const renderStep = (stepId, pushHistory = true) => {
      const step = conciergeSteps[stepId] || conciergeSteps.start;
      if (pushHistory && stepId !== currentStep) history.push(currentStep);
      currentStep = stepId;
      concierge.setAttribute("data-concierge-current", currentStep);
      if (eyebrow) eyebrow.textContent = conciergeTranslate(step.eyebrow);
      message.textContent = conciergeTranslate(step.message);
      if (helper) helper.textContent = conciergeTranslate(step.helper || "");
      options.innerHTML = "";

      step.options.forEach((option) => {
        const node = document.createElement(option.href ? "a" : "button");
        node.className = "concierge-option" + (option.tone === "primary" ? " concierge-option--primary" : "");
        if (option.href) {
          node.setAttribute("href", conciergeHref(option.href));
        } else {
          node.setAttribute("type", "button");
          node.setAttribute("data-concierge-next", option.next || "");
          node.addEventListener("click", () => {
            if (option.next) renderStep(option.next);
          });
        }

        const text = document.createElement("span");
        const strong = document.createElement("strong");
        strong.textContent = conciergeTranslate(option.label);
        text.appendChild(strong);
        if (option.detail) {
          const detail = document.createElement("small");
          detail.textContent = conciergeTranslate(option.detail);
          text.appendChild(detail);
        }
        node.appendChild(text);
        node.appendChild(makeArrow());
        options.appendChild(node);
      });

      if (back) back.disabled = history.length === 0;
    };

    trigger.addEventListener("click", () => setOpen(true));
    close?.addEventListener("click", () => {
      setOpen(false);
      trigger.focus?.({ preventScroll: true });
    });
    back?.addEventListener("click", () => {
      const previous = history.pop();
      if (previous) renderStep(previous, false);
    });
    restart?.addEventListener("click", () => {
      history = [];
      renderStep("start", false);
    });
    document.addEventListener("keydown", (event) => {
      if (event.key === "Escape" && concierge.classList.contains("is-open")) setOpen(false);
    });
    document.querySelectorAll("[data-lang-option]").forEach((button) => {
      button.addEventListener("click", () => window.setTimeout(() => renderStep(currentStep, false), 0));
    });

    renderStep(currentStep, false);
  }

  setupConcierge();

  if (document.querySelector('[data-factory-cinemagraph]')) {
    const factoryCinemagraphScript = document.createElement('script');
    factoryCinemagraphScript.src = 'public/scripts/factory-cinemagraph.js';
    factoryCinemagraphScript.defer = true;
    document.head.appendChild(factoryCinemagraphScript);
  }

  document.querySelectorAll('[data-export-network]').forEach((network) => {
    const routeGroups = Array.from(network.querySelectorAll('.export-network__route-group[data-export-market]'));
    const labels = Array.from(network.querySelectorAll('.export-network__label[data-export-market]'));
    const marketRows = Array.from(document.querySelectorAll('.export-market[data-export-market]'));
    const slides = Array.from(network.querySelectorAll('[data-export-design-slide]'));
    const dots = Array.from(network.querySelectorAll('[data-export-design-dot]'));
    const interactiveItems = Array.from(network.querySelectorAll('[data-export-market]')).filter((item) => {
      return routeGroups.includes(item) || labels.includes(item);
    });
    const marketIds = routeGroups.map((group) => group.getAttribute('data-export-market')).filter(Boolean);
    if (!marketIds.length || !slides.length) return;

    const reducedMotion = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
    let activeId = marketIds[0];
    let rotationTimer = 0;
    let hasSequenced = false;
    let isPausedByUser = false;

    const setMarket = (marketId) => {
      if (!marketId || !marketIds.includes(marketId)) return;

      routeGroups.forEach((group) => {
        const isActive = group.getAttribute('data-export-market') === marketId;
        group.classList.toggle('is-active', isActive);
        group.classList.toggle('is-muted', !isActive);
      });
      labels.forEach((label) => {
        const isActive = label.getAttribute('data-export-market') === marketId;
        label.classList.toggle('is-active', isActive);
        label.classList.toggle('is-muted', !isActive);
      });
      marketRows.forEach((row) => {
        const isActive = row.getAttribute('data-export-market') === marketId;
        row.classList.toggle('is-active', isActive);
      });
      slides.forEach((slide) => {
        const isActive = slide.getAttribute('data-export-market') === marketId;
        const wasActive = slide.classList.contains('is-active');
        slide.classList.toggle('is-active', isActive);
        slide.setAttribute('aria-hidden', isActive ? 'false' : 'true');
        if (wasActive && !isActive) {
          slide.classList.add('is-exiting');
          window.setTimeout(() => slide.classList.remove('is-exiting'), 700);
        } else if (isActive) {
          slide.classList.remove('is-exiting');
        }
      });
      dots.forEach((dot) => {
        dot.classList.toggle('is-active', dot.getAttribute('data-export-market') === marketId);
      });
      activeId = marketId;
    };

    const nextMarket = () => {
      const activeIndex = Math.max(0, marketIds.indexOf(activeId));
      setMarket(marketIds[(activeIndex + 1) % marketIds.length]);
    };

    const startRotation = () => {
      if (reducedMotion || isPausedByUser || rotationTimer) return;
      rotationTimer = window.setInterval(nextMarket, 8200);
    };

    const stopRotation = () => {
      if (!rotationTimer) return;
      window.clearInterval(rotationTimer);
      rotationTimer = 0;
    };

    const runSequence = () => {
      if (hasSequenced) return;
      hasSequenced = true;
      network.classList.add('is-sequenced');
      if (reducedMotion) {
        routeGroups.forEach((group) => group.classList.remove('is-muted'));
        setMarket(marketIds[0]);
        return;
      }
      setMarket(marketIds[0]);
      window.setTimeout(startRotation, 5200);
    };

    interactiveItems.forEach((item) => {
      const select = () => {
        const marketId = item.getAttribute('data-export-market');
        if (marketId) setMarket(marketId);
      };
      item.addEventListener('mouseenter', () => {
        isPausedByUser = true;
        stopRotation();
        select();
      });
      item.addEventListener('focus', () => {
        isPausedByUser = true;
        stopRotation();
        select();
      });
      item.addEventListener('click', select);
      item.addEventListener('keydown', (event) => {
        if (event.key !== 'Enter' && event.key !== ' ') return;
        event.preventDefault();
        select();
      });
    });

    network.addEventListener('mouseenter', () => {
      isPausedByUser = true;
      stopRotation();
    });
    network.addEventListener('mouseleave', () => {
      isPausedByUser = false;
      startRotation();
    });
    network.addEventListener('focusout', () => {
      window.setTimeout(() => {
        if (network.contains(document.activeElement)) return;
        isPausedByUser = false;
        startRotation();
      }, 0);
    });

    setMarket(activeId);

    if ('IntersectionObserver' in window) {
      const observer = new IntersectionObserver((entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            runSequence();
            if (hasSequenced) startRotation();
          } else {
            stopRotation();
          }
        });
      }, { threshold: 0.22 });
      observer.observe(network);
    } else {
      runSequence();
    }
  });

  document.querySelectorAll('.editable-image').forEach((slot) => {
    const image = slot.querySelector('img');
    const input = slot.querySelector('input[type="file"]');
    const trigger = slot.querySelector('.editable-image__trigger');
    const controls = slot.querySelectorAll('.editable-image__control');
    const replace = controls[0];
    const remove = controls[1];
    if (!image || !input) return;
    const fallback = image.getAttribute('src');

    const choose = () => input.click();
    trigger?.addEventListener('click', choose);
    replace?.addEventListener('click', choose);
    input.addEventListener('change', () => {
      const file = input.files?.[0];
      if (!file) return;
      if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type)) {
        window.alert('Choose a JPG, JPEG, PNG or WebP image.');
        input.value = '';
        return;
      }
      const reader = new FileReader();
      reader.addEventListener('load', () => {
        image.src = String(reader.result);
        slot.classList.add('has-replacement');
        if (remove) {
          remove.disabled = false;
          remove.setAttribute('aria-disabled', 'false');
        }
      });
      reader.readAsDataURL(file);
    });
    remove?.addEventListener('click', () => {
      image.setAttribute('src', fallback);
      input.value = '';
      slot.classList.remove('has-replacement');
      remove.disabled = true;
      remove.setAttribute('aria-disabled', 'true');
    });
  });

  document.querySelectorAll('button').forEach((button) => {
    if (/print|save pdf/i.test(button.textContent || '')) {
      button.addEventListener('click', () => window.print());
    }
  });

  document.querySelector('.enquiry-form')?.addEventListener('submit', (event) => {
    event.preventDefault();
    const form = event.currentTarget;
    const formData = new FormData(form);
    const recipient = form.getAttribute('data-enquiry-email') || 'lakshbaheti59@gmail.com';
    const fieldLabels = Array.from(form.querySelectorAll('label[for]')).reduce((labels, label) => {
      labels[label.getAttribute('for')] = (label.textContent || '').replace('*', '').trim();
      return labels;
    }, {});
    const fieldLines = Array.from(form.elements)
      .filter((field) => field.name && !['button', 'submit', 'checkbox', 'file'].includes(field.type))
      .map((field) => {
        const label = fieldLabels[field.id] || field.name;
        const value = field.tagName === 'SELECT'
          ? field.selectedOptions?.[0]?.textContent?.trim()
          : formData.get(field.name);
        const cleanValue = typeof value === 'string' && value.trim() ? value.trim() : 'Not provided';
        return label + ': ' + cleanValue;
      });
    const company = String(formData.get('companyName') || '').trim();
    const country = String(formData.get('country') || '').trim();
    const subject = ['ESHA Apparels Buyer Enquiry', company, country].filter(Boolean).join(' · ');
    const body = [
      'Hello ESHA Apparels,',
      '',
      'Please review the following buyer enquiry:',
      '',
      ...fieldLines,
      '',
      'Submitted from the ESHA Apparels website.',
    ].join('\\n');
    window.location.href = 'mailto:' + recipient + '?subject=' + encodeURIComponent(subject) + '&body=' + encodeURIComponent(body);
    const message = 'Your email app should now open with the enquiry details prepared for ESHA Apparels.';
    window.alert(translateTextValue(message, document.body.dataset.language || 'en'));
  });
})();
</script>`

function rewriteDocument(html) {
  let output = html
    .replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi, '')
    .replace(/<link\b[^>]*rel="modulepreload"[^>]*\/?>/gi, '')
    .replaceAll('class="reveal ', 'class="reveal is-visible ')
    .replaceAll('href="/src/styles/global.css"', 'href="src/styles/global.css"')
    .replaceAll('href="/favicon.svg"', 'href="public/favicon.svg"')
    .replaceAll('href="/images/', 'href="public/images/')
    .replaceAll('src="/images/', 'src="public/images/')
    .replaceAll('content="/images/', 'content="public/images/')

  for (const [route, file] of routeFiles) {
    if (route === '/') {
      output = output.replaceAll('href="/"', `href="${file}"`)
      continue
    }

    output = output
      .replaceAll(`href="${route}"`, `href="${file}"`)
      .replaceAll(`href="${route}?`, `href="${file}?`)
      .replaceAll(`href="${route}#`, `href="${file}#`)
  }

  return output.replace('</body>', `${staticEnhancements}</body>`)
}

for (const [route, file] of pages) {
  const response = await fetch(`${baseUrl}${route}`)
  if (!response.ok) {
    throw new Error(`Could not export ${route}: HTTP ${response.status}`)
  }

  const html = rewriteDocument(await response.text())
  await writeFile(resolve(file), html)
  console.log(`Exported ${route} -> ${file}`)
}
