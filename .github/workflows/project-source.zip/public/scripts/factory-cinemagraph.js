(() => {
  'use strict'

  const canvases = document.querySelectorAll('[data-factory-cinemagraph]')
  if (!canvases.length) return

  const W = 1200
  const H = 680
  const TAU = Math.PI * 2
  const SCENE_DURATION = 9.8
  const DISSOLVE_DURATION = 1.85
  const SCENE_COUNT = 7

  const clamp = (value, min = 0, max = 1) => Math.min(max, Math.max(min, value))
  const mix = (from, to, amount) => from + (to - from) * amount
  const ease = (value) => {
    const t = clamp(value)
    return t * t * (3 - 2 * t)
  }

  function roundedRect(context, x, y, width, height, radius) {
    const r = Math.min(radius, width / 2, height / 2)
    context.beginPath()
    context.moveTo(x + r, y)
    context.lineTo(x + width - r, y)
    context.quadraticCurveTo(x + width, y, x + width, y + r)
    context.lineTo(x + width, y + height - r)
    context.quadraticCurveTo(x + width, y + height, x + width - r, y + height)
    context.lineTo(x + r, y + height)
    context.quadraticCurveTo(x, y + height, x, y + height - r)
    context.lineTo(x, y + r)
    context.quadraticCurveTo(x, y, x + r, y)
    context.closePath()
  }

  function fillRounded(context, x, y, width, height, radius, fill) {
    roundedRect(context, x, y, width, height, radius)
    context.fillStyle = fill
    context.fill()
  }

  function drawBackdrop(context, mood = 0) {
    context.fillStyle = '#151515'
    context.fillRect(0, 0, W, H)

    const pool = context.createRadialGradient(560, 260, 60, 560, 260, 780)
    pool.addColorStop(0, 'rgba(246,242,234,0.075)')
    pool.addColorStop(0.46, 'rgba(180,154,99,0.025)')
    pool.addColorStop(1, 'rgba(0,0,0,0)')
    context.fillStyle = pool
    context.fillRect(0, 0, W, H)

    context.fillStyle = mood ? '#1c1b19' : '#1b1b1a'
    context.fillRect(0, 542, W, 138)
    context.strokeStyle = 'rgba(216,204,192,0.09)'
    context.lineWidth = 1
    context.beginPath()
    context.moveTo(80, 542)
    context.lineTo(1120, 542)
    context.stroke()
  }

  function fabricGradient(context, top, bottom, warm = false) {
    const gradient = context.createLinearGradient(0, top, 0, bottom)
    if (warm) {
      gradient.addColorStop(0, '#c3ad9a')
      gradient.addColorStop(0.48, '#927c6c')
      gradient.addColorStop(1, '#665448')
    } else {
      gradient.addColorStop(0, '#aa9c8c')
      gradient.addColorStop(0.5, '#827466')
      gradient.addColorStop(1, '#5d5147')
    }
    return gradient
  }

  function clipFabric(context, x, y, width, height, time = 0, amp = 8) {
    context.beginPath()
    context.moveTo(x, y + 18)
    context.bezierCurveTo(x + width * 0.24, y - amp, x + width * 0.62, y + amp, x + width, y + 8)
    context.lineTo(x + width, y + height - 10)
    context.bezierCurveTo(
      x + width * 0.72,
      y + height + amp * 0.7,
      x + width * 0.3,
      y + height - amp * 0.3,
      x,
      y + height,
    )
    context.closePath()
  }

  function drawWeave(context, x, y, width, height, offset = 0, opacity = 0.14) {
    context.save()
    context.beginPath()
    context.rect(x, y, width, height)
    context.clip()
    context.lineWidth = 0.75
    context.strokeStyle = `rgba(246,242,234,${opacity})`
    for (let row = y - 20 + (offset % 14); row < y + height + 20; row += 14) {
      context.beginPath()
      context.moveTo(x - 12, row)
      context.bezierCurveTo(x + width * 0.26, row + 4, x + width * 0.72, row - 3, x + width + 12, row + 1)
      context.stroke()
    }
    context.strokeStyle = `rgba(31,31,29,${opacity * 0.72})`
    for (let column = x - 18 + ((offset * 0.62) % 18); column < x + width + 18; column += 18) {
      context.beginPath()
      context.moveTo(column, y - 10)
      context.lineTo(column + 2, y + height + 10)
      context.stroke()
    }
    context.restore()
  }

  function drawLightSweep(context, time, clip) {
    context.save()
    if (clip) clip()
    context.globalCompositeOperation = 'screen'
    const x = ((time * 30) % 1500) - 260
    const light = context.createLinearGradient(x, 0, x + 240, 0)
    light.addColorStop(0, 'rgba(246,242,234,0)')
    light.addColorStop(0.5, 'rgba(246,242,234,0.14)')
    light.addColorStop(1, 'rgba(246,242,234,0)')
    context.fillStyle = light
    context.fillRect(0, 0, W, H)
    context.restore()
  }

  function drawMachine(context, time, macro = false) {
    const baseX = macro ? 170 : 126
    const bodyY = macro ? 70 : 112
    const headX = macro ? 640 : 610
    const needleX = macro ? 656 : 646
    const fabricY = macro ? 474 : 500

    context.save()
    context.shadowColor = 'rgba(0,0,0,0.55)'
    context.shadowBlur = 34
    context.shadowOffsetY = 20

    const metal = context.createLinearGradient(baseX, 0, baseX + 730, 0)
    metal.addColorStop(0, '#292a2a')
    metal.addColorStop(0.18, '#73716c')
    metal.addColorStop(0.42, '#393a39')
    metal.addColorStop(0.68, '#a19b91')
    metal.addColorStop(1, '#242424')

    context.beginPath()
    context.moveTo(baseX, bodyY + 42)
    context.quadraticCurveTo(baseX, bodyY, baseX + 44, bodyY)
    context.lineTo(baseX + 612, bodyY)
    context.quadraticCurveTo(baseX + 664, bodyY, baseX + 680, bodyY + 52)
    context.lineTo(baseX + 706, bodyY + 178)
    context.lineTo(headX + 108, bodyY + 202)
    context.lineTo(headX + 40, bodyY + 104)
    context.lineTo(baseX + 244, bodyY + 104)
    context.lineTo(baseX + 244, fabricY - 58)
    context.lineTo(baseX, fabricY - 58)
    context.closePath()
    context.fillStyle = metal
    context.fill()
    context.shadowColor = 'transparent'

    context.strokeStyle = 'rgba(246,242,234,0.2)'
    context.lineWidth = 1.4
    context.stroke()

    const reflectX = baseX + 170 + Math.sin(time * 0.18) * 130
    drawLightSweep(context, time * 0.45, () => {
      context.beginPath()
      context.rect(reflectX - 110, bodyY, 220, 240)
      context.clip()
    })

    context.beginPath()
    context.arc(baseX + 624, bodyY + 62, macro ? 55 : 68, 0, TAU)
    context.fillStyle = '#262727'
    context.fill()
    context.lineWidth = macro ? 6 : 8
    context.strokeStyle = '#74716b'
    context.stroke()

    const cadence = Math.sin(time * TAU * 0.92)
    const needleTravel = cadence * (macro ? 17 : 13)
    const presserLift = Math.max(0, Math.sin(time * TAU * 0.46 - 0.35)) * (macro ? 5 : 3)

    context.strokeStyle = '#d7d2c8'
    context.lineWidth = macro ? 12 : 9
    context.beginPath()
    context.moveTo(needleX, bodyY + 122)
    context.lineTo(needleX, fabricY - 44 + needleTravel)
    context.stroke()

    context.strokeStyle = '#f6f2ea'
    context.lineWidth = 1.8
    context.beginPath()
    context.moveTo(needleX + 1.5, fabricY - 40 + needleTravel)
    context.lineTo(needleX + 1.5, fabricY + 18 + needleTravel)
    context.stroke()

    fillRounded(context, needleX - 52, fabricY - 24 - presserLift, 104, 18, 4, '#5f5f5b')
    context.strokeStyle = 'rgba(246,242,234,0.34)'
    context.lineWidth = 1
    context.strokeRect(needleX - 38, fabricY - 15 - presserLift, 76, 18)

    context.strokeStyle = '#d8ccc0'
    context.lineWidth = 1.25
    context.beginPath()
    context.moveTo(needleX - 118, bodyY + 30)
    context.bezierCurveTo(needleX - 42, bodyY + 34, needleX - 28, bodyY + 168, needleX + 1, fabricY - 28 + needleTravel)
    context.stroke()
    context.restore()

    return { needleX, fabricY }
  }

  function sceneMachine(context, time) {
    drawBackdrop(context)
    clipFabric(context, 0, 462, W, 150, time, 10)
    context.fillStyle = fabricGradient(context, 460, 615)
    context.fill()
    drawWeave(context, 0, 462, W, 150, time * 2.2, 0.12)

    const { needleX, fabricY } = drawMachine(context, time)
    const progress = clamp(time / 7.2)
    context.strokeStyle = 'rgba(234,219,221,0.78)'
    context.lineWidth = 2
    context.setLineDash([4, 10])
    context.lineDashOffset = -time * 8
    context.beginPath()
    context.moveTo(needleX - 150, fabricY + 8)
    context.lineTo(mix(needleX - 150, needleX + 180, progress), fabricY + 8)
    context.stroke()
    context.setLineDash([])
  }

  function sceneFabric(context, time) {
    drawBackdrop(context)
    clipFabric(context, 70, 164, 1060, 474, time, 12)
    context.fillStyle = fabricGradient(context, 150, 640, true)
    context.fill()
    drawWeave(context, 70, 164, 1060, 474, time * 2.8, 0.2)

    const { needleX, fabricY } = drawMachine(context, time, true)
    const stitchEnd = mix(250, 925, clamp(time / 7.4))
    context.strokeStyle = '#eadbdd'
    context.lineWidth = 3
    context.setLineDash([8, 13])
    context.beginPath()
    context.moveTo(250, fabricY + 10)
    context.lineTo(stitchEnd, fabricY + 10)
    context.stroke()
    context.setLineDash([])

    context.fillStyle = 'rgba(79,32,41,0.68)'
    context.beginPath()
    context.arc(needleX, fabricY + 10, 4, 0, TAU)
    context.fill()
  }

  function drawHand(context, x, y, mirror, time) {
    const settle = Math.sin(time * 0.55) * 2.2
    context.save()
    context.translate(x, y)
    context.scale(mirror ? -1 : 1, 1)
    context.shadowColor = 'rgba(0,0,0,0.34)'
    context.shadowBlur = 24
    context.shadowOffsetY = 14
    const skin = context.createLinearGradient(-190, -42, 150, 140)
    skin.addColorStop(0, '#d0ad93')
    skin.addColorStop(0.55, '#a98269')
    skin.addColorStop(1, '#6e5042')
    context.fillStyle = skin
    context.beginPath()
    context.moveTo(-194, -24)
    context.bezierCurveTo(-112, -48, -28, -36, 40, 2)
    context.bezierCurveTo(92, 31, 132, 68, 150, 106)
    context.bezierCurveTo(118, 135, 72, 128, 18, 106)
    context.bezierCurveTo(-56, 76, -116, 70, -194, 76)
    context.closePath()
    context.fill()
    context.shadowColor = 'transparent'
    for (let finger = 0; finger < 4; finger += 1) {
      const fingerX = 20 + finger * 30
      const fingerY = 54 + settle * (0.4 + finger * 0.12)
      fillRounded(context, fingerX, fingerY, 26, 76 - finger * 4, 14, '#b9937a')
      context.strokeStyle = 'rgba(246,242,234,0.16)'
      context.lineWidth = 1
      context.beginPath()
      context.moveTo(fingerX + 6, fingerY + 18)
      context.quadraticCurveTo(fingerX + 13, fingerY + 13, fingerX + 20, fingerY + 18)
      context.stroke()
    }
    context.restore()
  }

  function sceneHands(context, time) {
    drawBackdrop(context, 1)
    const relax = Math.sin(time * 0.36) * 5
    clipFabric(context, 0, 250 + relax, W, 430, time, 18)
    context.fillStyle = fabricGradient(context, 236, 680)
    context.fill()
    drawWeave(context, 0, 246, W, 434, time * 0.75, 0.12)

    context.strokeStyle = 'rgba(234,219,221,0.42)'
    context.lineWidth = 2
    context.beginPath()
    context.moveTo(190, 502 + relax)
    context.bezierCurveTo(382, 460, 732, 536, 1010, 486 - relax)
    context.stroke()
    drawHand(context, 354, 218, false, time)
    drawHand(context, 846, 220, true, time + 0.6)
    drawLightSweep(context, time * 0.72)
  }

  function embroideryPoint(progress) {
    const angle = progress * TAU * 3.25 - Math.PI / 2
    const radius = 68 + Math.sin(progress * TAU * 4) * 46
    return [600 + Math.cos(angle) * radius, 402 + Math.sin(angle) * radius]
  }

  function sceneEmbroidery(context, time) {
    drawBackdrop(context)
    context.save()
    context.translate(600, 402)
    context.beginPath()
    context.arc(0, 0, 294, 0, TAU)
    context.fillStyle = '#8c796a'
    context.fill()
    context.lineWidth = 28
    context.strokeStyle = '#433a34'
    context.stroke()
    context.lineWidth = 4
    context.strokeStyle = '#b49a63'
    context.stroke()
    context.restore()
    drawWeave(context, 310, 110, 580, 580, time * 0.55, 0.12)

    const progress = ease(time / 7.8)
    context.save()
    context.strokeStyle = '#7f3945'
    context.lineWidth = 6
    context.lineCap = 'round'
    context.lineJoin = 'round'
    context.beginPath()
    const steps = Math.max(2, Math.floor(progress * 220))
    for (let step = 0; step <= steps; step += 1) {
      const [x, y] = embroideryPoint(step / 220)
      if (step === 0) context.moveTo(x, y)
      else context.lineTo(x, y)
    }
    context.stroke()
    context.strokeStyle = '#b49a63'
    context.lineWidth = 2.2
    context.beginPath()
    context.arc(600, 402, 32, 0, TAU * progress)
    context.stroke()
    context.restore()

    const [nx, ny] = embroideryPoint(progress)
    const needle = Math.sin(time * TAU * 0.76) * 9 * (1 - ease((time - 7.7) / 1.2))
    context.strokeStyle = '#d9d4ca'
    context.lineWidth = 8
    context.beginPath()
    context.moveTo(nx, 60)
    context.lineTo(nx, ny - 26 + needle)
    context.stroke()
    context.strokeStyle = '#eadbdd'
    context.lineWidth = 1.5
    context.beginPath()
    context.moveTo(nx, ny - 26 + needle)
    context.lineTo(nx, ny)
    context.stroke()
  }

  function garmentPath(context, time, small = false) {
    const cx = 600
    const top = small ? 92 : 86
    const breath = Math.sin(time * 0.24) * 2.2
    const hem = Math.sin(time * 0.18 + 0.7) * 2.4
    context.beginPath()
    context.moveTo(cx - 78, top + 44)
    context.quadraticCurveTo(cx - 42, top + 6, cx, top + 8)
    context.quadraticCurveTo(cx + 42, top + 6, cx + 78, top + 44)
    context.lineTo(cx + 224, top + 142)
    context.quadraticCurveTo(cx + 244, top + 188, cx + 190, top + 226)
    context.lineTo(cx + 104, top + 190)
    context.quadraticCurveTo(cx + 120, top + 356, cx + 198 + hem, top + 500)
    context.quadraticCurveTo(cx, top + 544 + breath, cx - 198 - hem, top + 500)
    context.quadraticCurveTo(cx - 120, top + 356, cx - 104, top + 190)
    context.lineTo(cx - 190, top + 226)
    context.quadraticCurveTo(cx - 244, top + 188, cx - 224, top + 142)
    context.closePath()
  }

  function drawGarment(context, time, inspection = false) {
    context.save()
    context.shadowColor = 'rgba(0,0,0,0.56)'
    context.shadowBlur = 38
    context.shadowOffsetY = 24
    garmentPath(context, time)
    context.fillStyle = fabricGradient(context, 88, 610, true)
    context.fill()
    context.shadowColor = 'transparent'
    garmentPath(context, time)
    context.strokeStyle = 'rgba(246,242,234,0.32)'
    context.lineWidth = 1.6
    context.stroke()
    context.save()
    garmentPath(context, time)
    context.clip()
    drawWeave(context, 360, 70, 480, 560, time * 0.16, 0.1)
    context.restore()

    context.strokeStyle = 'rgba(246,242,234,0.42)'
    context.lineWidth = 1.5
    context.beginPath()
    context.moveTo(548, 108)
    context.quadraticCurveTo(600, 172, 652, 108)
    context.moveTo(600, 164)
    context.lineTo(600, 456)
    context.moveTo(455, 526)
    context.quadraticCurveTo(600, 558 + Math.sin(time * 0.24) * 3, 745, 526)
    context.stroke()

    context.fillStyle = '#e5d8ba'
    for (let index = 0; index < 5; index += 1) {
      context.beginPath()
      context.arc(600, 204 + index * 48, 6, 0, TAU)
      context.fill()
    }

    if (inspection) {
      context.setLineDash([4, 8])
      context.strokeStyle = 'rgba(229,216,186,0.48)'
      context.lineWidth = 1.4
      context.beginPath()
      context.moveTo(482, 286)
      context.lineTo(718, 286)
      context.moveTo(456, 452)
      context.lineTo(744, 452)
      context.stroke()
      context.setLineDash([])
    }
    context.restore()
  }

  function sceneInspection(context, time) {
    drawBackdrop(context)
    const panelX = 132
    const panelY = 116
    const panelW = 936
    const panelH = 404

    context.save()
    context.shadowColor = 'rgba(0,0,0,0.45)'
    context.shadowBlur = 34
    context.shadowOffsetY = 22
    fillRounded(context, panelX, panelY, panelW, panelH, 8, '#7e6b5e')
    context.shadowColor = 'transparent'
    roundedRect(context, panelX, panelY, panelW, panelH, 8)
    context.strokeStyle = 'rgba(246,242,234,0.18)'
    context.lineWidth = 1.2
    context.stroke()
    context.restore()

    drawWeave(context, panelX, panelY, panelW, panelH, time * 0.42, 0.18)

    const tapeY = 238
    context.save()
    context.translate(226, tapeY + Math.sin(time * 0.18) * 1.5)
    context.rotate(-0.018)
    fillRounded(context, 0, 0, 760, 42, 3, '#e5d8ba')
    context.fillStyle = '#4b4742'
    context.font = '700 10px Arial, sans-serif'
    for (let tick = 0; tick <= 38; tick += 1) {
      const x = 18 + tick * 19
      context.beginPath()
      context.moveTo(x, 0)
      context.lineTo(x, tick % 5 === 0 ? 22 : 12)
      context.strokeStyle = 'rgba(31,31,29,0.58)'
      context.lineWidth = tick % 5 === 0 ? 1.4 : 0.8
      context.stroke()
      if (tick % 5 === 0) context.fillText(String(tick), x - 3, 34)
    }
    context.restore()

    context.strokeStyle = 'rgba(234,219,221,0.55)'
    context.lineWidth = 2
    context.setLineDash([9, 12])
    context.lineDashOffset = -time * 3
    context.beginPath()
    context.moveTo(220, 356)
    context.bezierCurveTo(410, 332, 686, 388, 980, 350)
    context.stroke()
    context.setLineDash([])

    context.fillStyle = 'rgba(31,31,29,0.35)'
    context.fillRect(196, 408, 220, 42)
    context.fillStyle = '#f6f2ea'
    context.font = '700 15px Arial, sans-serif'
    context.letterSpacing = '2px'
    context.fillText('MEASUREMENT CHECK', 216, 435)

    drawLightSweep(context, time, () => {
      roundedRect(context, panelX, panelY, panelW, panelH, 8)
      context.clip()
    })
  }

  function scenePacking(context, time) {
    drawBackdrop(context, 1)
    context.fillStyle = '#242321'
    context.fillRect(104, 482, 992, 166)
    context.strokeStyle = 'rgba(216,204,192,0.14)'
    context.strokeRect(104, 482, 992, 166)

    context.save()
    context.shadowColor = 'rgba(0,0,0,0.54)'
    context.shadowBlur = 32
    context.shadowOffsetY = 22
    fillRounded(context, 278, 206, 648, 316, 10, '#786758')
    context.shadowColor = 'transparent'
    roundedRect(context, 278, 206, 648, 316, 10)
    context.strokeStyle = 'rgba(246,242,234,0.2)'
    context.stroke()
    drawWeave(context, 278, 206, 648, 316, time * 0.18, 0.1)

    const settle = Math.exp(-Math.min(time, 4.8) * 0.85) * Math.sin(time * 2.05) * 6
    context.fillStyle = '#6e2f3a'
    context.fillRect(558, 206, 88, 316)
    context.fillRect(278, 332 + settle, 648, 72)
    context.strokeStyle = 'rgba(234,219,221,0.34)'
    context.strokeRect(558, 206, 88, 316)
    context.strokeRect(278, 332 + settle, 648, 72)

    context.translate(842, 374)
    context.rotate(Math.sin(time * 0.58) * 0.018)
    context.strokeStyle = '#d8ccc0'
    context.lineWidth = 1.4
    context.beginPath()
    context.moveTo(-34, -68)
    context.quadraticCurveTo(6, -28, 8, 0)
    context.stroke()
    fillRounded(context, -30, 0, 120, 70, 4, '#e8e0d6')
    context.fillStyle = '#4f2029'
    context.font = '700 12px Arial, sans-serif'
    context.fillText('ESHA', -8, 30)
    context.fillStyle = '#6e6a64'
    context.font = '10px Arial, sans-serif'
    context.fillText('EXPORT READY', -8, 48)
    context.restore()
  }

  function sceneFinished(context, time) {
    drawBackdrop(context)
    context.strokeStyle = 'rgba(216,204,192,0.3)'
    context.lineWidth = 1.4
    context.beginPath()
    context.moveTo(600, 28)
    context.lineTo(600, 98)
    context.stroke()
    drawGarment(context, time)
    drawLightSweep(context, time * 0.35, () => {
      garmentPath(context, time)
      context.clip()
    })
  }

  const scenes = [
    sceneMachine,
    sceneFabric,
    sceneHands,
    sceneEmbroidery,
    sceneInspection,
    scenePacking,
    sceneFinished,
  ]

  function init(canvas) {
    const context = canvas.getContext('2d', { alpha: false, desynchronized: true })
    const shell = canvas.closest('[data-factory-cinemagraph-shell]')
    const captions = shell ? [...shell.querySelectorAll('[data-factory-cinemagraph-scene]')] : []
    const dots = shell ? [...shell.querySelectorAll('[data-factory-cinemagraph-dot]')] : []
    const counter = shell?.querySelector('[data-factory-cinemagraph-counter]')

    if (!context) {
      shell?.classList.add('is-fallback')
      return
    }

    const reducedMotion = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches
    let width = 0
    let height = 0
    let elapsed = 0
    let previous = 0
    let frame = 0
    let visible = true
    let pageVisible = !document.hidden
    let active = -1

    function resize() {
      const bounds = canvas.getBoundingClientRect()
      const ratio = Math.min(window.devicePixelRatio || 1, 1.55)
      const nextWidth = Math.max(1, Math.round(bounds.width * ratio))
      const nextHeight = Math.max(1, Math.round(bounds.height * ratio))
      if (nextWidth === width && nextHeight === height) return
      width = nextWidth
      height = nextHeight
      canvas.width = width
      canvas.height = height
    }

    function updateScene(index) {
      if (index === active) return
      active = index
      captions.forEach((caption, captionIndex) => {
        const selected = captionIndex === index
        caption.classList.toggle('is-active', selected)
        caption.setAttribute('aria-hidden', selected ? 'false' : 'true')
      })
      dots.forEach((dot, dotIndex) => dot.classList.toggle('is-active', dotIndex === index))
      if (counter) counter.textContent = String(index + 1).padStart(2, '0')
    }

    function drawScene(index, time, alpha, offsetY = 0) {
      context.save()
      context.globalAlpha = alpha
      const scale = Math.max(width / W, height / H)
      context.translate((width - W * scale) / 2, (height - H * scale) / 2 + offsetY * scale)
      context.scale(scale, scale)
      scenes[index](context, time)
      context.restore()
    }

    function render(totalTime) {
      resize()
      context.setTransform(1, 0, 0, 1, 0, 0)
      context.fillStyle = '#151515'
      context.fillRect(0, 0, width, height)

      if (reducedMotion) {
        updateScene(5)
        drawScene(5, 1.2, 1)
        shell?.classList.add('is-ready', 'is-reduced-motion')
        canvas.dataset.factoryCinemagraphReady = 'true'
        return
      }

      const cycle = totalTime % (SCENE_DURATION * SCENE_COUNT)
      const scenePosition = cycle / SCENE_DURATION
      const current = Math.floor(scenePosition) % SCENE_COUNT
      const next = (current + 1) % SCENE_COUNT
      const localTime = cycle - current * SCENE_DURATION
      const dissolve = ease((localTime - (SCENE_DURATION - DISSOLVE_DURATION)) / DISSOLVE_DURATION)
      const selected = dissolve > 0.5 ? next : current

      updateScene(selected)
      drawScene(current, localTime, 1 - dissolve, -dissolve * 4)
      if (dissolve > 0) drawScene(next, Math.max(0, localTime - (SCENE_DURATION - DISSOLVE_DURATION)), dissolve, (1 - dissolve) * 4)

      shell?.classList.add('is-ready')
      canvas.dataset.factoryCinemagraphReady = 'true'
    }

    function tick(now) {
      frame = 0
      if (!visible || !pageVisible || reducedMotion) return
      if (!previous) previous = now
      const delta = Math.min(50, now - previous)
      previous = now
      elapsed += delta / 1000
      render(elapsed)
      frame = window.requestAnimationFrame(tick)
    }

    function start() {
      if (reducedMotion || frame || !visible || !pageVisible) return
      previous = 0
      frame = window.requestAnimationFrame(tick)
    }

    function stop() {
      if (frame) window.cancelAnimationFrame(frame)
      frame = 0
      previous = 0
    }

    const resizeObserver = 'ResizeObserver' in window
      ? new ResizeObserver(() => render(elapsed))
      : null
    resizeObserver?.observe(canvas)

    if ('IntersectionObserver' in window) {
      const observer = new IntersectionObserver(
        (entries) => {
          entries.forEach((entry) => {
            visible = entry.isIntersecting
            if (visible) start()
            else stop()
          })
        },
        { threshold: 0.12 },
      )
      observer.observe(canvas)
    }

    document.addEventListener('visibilitychange', () => {
      pageVisible = !document.hidden
      if (pageVisible) start()
      else stop()
    })

    render(0.1)
    start()
  }

  canvases.forEach(init)
})()
