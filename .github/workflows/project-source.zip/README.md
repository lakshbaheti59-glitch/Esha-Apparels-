# ESHA Apparels Company Profile

A multi-page React and TypeScript company-profile website for ESHA Apparels, built with the Vinext App Router. It includes buyer-focused routes, editable image previews, and a complete browser-print/PDF route.

## Current company facts

The profile currently uses:

- Monthly production capacity: **Up to 250,000 pieces**
- Infrastructure: **Two manufacturing factories**
- Sewing infrastructure: **575 sewing machines**
- Main focus: Women’s western wear and fast-fashion garments
- Approximate FOB positioning: USD 3–12 per piece, subject to the product requirement
- Standard MOQ: Approximately 700 pieces per style, subject to fabric, design, and order requirements

The visible product catalogue intentionally excludes **Daywear**, **Beach wear**, and **Resort wear**. Do not restore these names in product categories, gallery filters, or gallery products unless the business scope changes.

## Routes

| Route | Purpose |
| --- | --- |
| `/` | Home overview, headline statistics, reasons to choose ESHA Apparels, and links into the profile |
| `/about` | Company introduction and buyer segments |
| `/facilities` | Two-factory infrastructure and production capability |
| `/products` | Product categories, fabrics/value additions, and selected-product gallery |
| `/quality-compliance` | Quality checkpoints, compliance support, and verification fields |
| `/sustainability` | Responsible manufacturing, material optimisation, efficiency, and sustainability evidence fields |
| `/export` | Export experience, market placeholders, and buyer-support capabilities |
| `/events` | Past and upcoming buyer-facing events |
| `/awards` | Reliance Best Vendor Award 2022–23 and supporting image areas |
| `/contact` | Buyer enquiry form, contact details, FAQs, and closing calls to action |
| `/company-profile` | Unlisted complete profile for review, printing, and PDF export |

Each route has its own title and description in its `app/<route>/page.tsx` file. Shared document metadata, Open Graph fields, and the favicon are in `app/layout.tsx`.

## Project structure

```text
app/
├── page.tsx
├── about/page.tsx
├── facilities/page.tsx
├── products/page.tsx
├── quality-compliance/page.tsx
├── sustainability/page.tsx
├── export/page.tsx
├── events/page.tsx
├── awards/page.tsx
├── contact/page.tsx
├── company-profile/page.tsx
└── layout.tsx
src/
├── App.tsx
├── components/EditableImage.tsx
├── data/companyData.ts
├── lib/imageStore.ts
└── styles/global.css
public/
├── favicon.svg
└── images/
scripts/prepare-hosting.mjs
.openai/hosting.json
index.html
```

The root `index.html` is a direct, offline-capable static version of the home page. Double-click it to open the profile without a server, ChatGPT account, permission prompt, or internet connection. Its navigation uses the companion root files such as `about.html`, `facilities.html`, and `products.html`.

The Vinext App Router remains the source of truth. After changing routed content, start the local app and regenerate the static files:

```bash
pnpm dev
# In a second terminal:
pnpm export:static
```

Keep the generated `.html` files together with `public/` and `src/styles/global.css`; those relative assets are required by the offline version.

## Run locally

Requirements:

- Node.js 22.12 or newer
- pnpm

```bash
corepack enable
pnpm install --frozen-lockfile
pnpm dev
```

Open the URL printed by Vinext. Use the route paths above to test each page directly.

Other commands:

```bash
pnpm typecheck
pnpm lint
pnpm build
pnpm preview
```

Run `pnpm build` before `pnpm preview`.

## Update company information

The central editable content source is:

```text
src/data/companyData.ts
```

It contains company facts, statistics, navigation, factory data, product categories, gallery products, process steps, quality fields, compliance/sustainability information, export markets, award content, FAQs, enquiry fields, contact details, downloads, and image paths.

Edit values without renaming typed object keys. Run `pnpm typecheck` after every structural change.

Useful update locations:

- Company facts: `companyData.brand`
- Route-specific banner images: `companyData.pageBanners`
- Home statistics: `companyData.hero` and `companyData.atAGlance`
- Factory details: `companyData.factories.profiles`
- Production data: `companyData.production.operationalData`
- Categories: `companyData.productCategories.items`
- Gallery filters/products: `companyData.gallery`
- Quality fields: `companyData.quality`
- Compliance and sustainability evidence: `companyData.compliance`
- Export markets/support: `companyData.exports`
- Contact details: `companyData.contact`
- Enquiry fields: `companyData.enquiry`

The 250,000-piece capacity and 575-machine count appear in several buyer-facing summaries and route descriptions. If either changes, audit every occurrence:

```bash
rg -n '250,000|575' src/data/companyData.ts app
```

Values in square brackets are deliberate verification placeholders. Replace them only with confirmed information. Do not add unsupported addresses, factory figures, customer names, countries, audit results, certifications, or logos.

### Factory, contact, and certification updates

- Update each factory’s location, categories, lines, capacity, workforce, machinery, and quality team inside `companyData.factories.profiles`.
- Update email, phone/WhatsApp, website, addresses, social links, and QR-code data inside `companyData.contact`.
- Update certification and audit fields inside `companyData.compliance.verificationFields` only after documentary verification.
- Add a certification logo only when ESHA Apparels holds the credential and has permission to display it.

## Image folders

Committed media lives under:

```text
public/images/
├── hero/
├── company/
├── factory-one/
├── factory-two/
├── products/
├── fabrics/
├── process/
├── quality/
├── award/
├── team/
├── export/
└── contact/
```

Public paths begin with `/images`, for example:

```ts
image: {
  src: "/images/products/product-dress-01.jpg",
  alt: "Front view of a printed women’s dress",
  recommendedShot: "Portrait garment photograph",
}
```

For permanent changes:

1. Replace the existing public file with an approved image of the same name and extension; or
2. Add a new JPG, PNG, or WebP file and update its `src` in `companyData.ts`.
3. Update the alt text and recommended-shot note.
4. Commit, rebuild, and verify the image under `dist/client/images`.

Keep natural aspect ratios, optimise file sizes, use portrait photography for garments and wide photography for hero/factory areas, and never stretch an image to fit.

## Click-to-edit image previews

Editable image areas support temporary browser-side replacement:

1. Select the image itself or choose **Replace**.
2. Choose a JPG/JPEG, PNG, or WebP file.
3. The replacement appears immediately and is saved in IndexedDB when browser storage is available.
4. Choose **Remove** to delete that saved replacement and restore the bundled image.

Important behavior:

- Replacements are stored in the browser database `esha-apparels-editable-images`, keyed by each image area’s stable `storageKey`.
- They persist only for the same browser profile and website origin.
- Local development, a preview server, and the production domain use different browser origins and therefore separate saved replacements.
- They do not upload a file, modify `public/images`, edit `companyData.ts`, enter Git, or deploy to other users.
- They do not sync between browsers or devices.
- Clearing site data, using private browsing, exceeding browser storage limits, or blocking IndexedDB can remove or prevent saved replacements.
- If storage fails, the selected image may remain available only for the current tab session.
- **Remove** never deletes a committed public image; it restores that fallback.
- No application-level file-size limit is enforced, so use compressed assets and remain within browser storage quotas.

Use this feature for local review and buyer-specific mockups. Use the permanent workflow above for published assets.

## Add gallery products

Copy an existing entry in `companyData.gallery.products` and update:

- Unique `id` and `styleCode`
- Image path, alt text, and recommended shot
- Product title and category
- `filters`
- Fabric
- Available sizes
- Approximate price range
- MOQ
- Colour options
- Product note

Every filter must exist in the `GalleryFilter` type and `companyData.gallery.filters`. The current filters are:

```text
All Products, Dresses, Tops, Tunics, Co-ords, Skirts, Bottoms,
Printed, Solid, Lace, Embroidered, Casual
```

Keep prices and MOQs qualified. Test filtering, load-more behavior, image replacement, the lightbox, and the enquiry link after adding products.

## Print or save as PDF

Open:

```text
/company-profile
```

This route assembles the full profile, expands the FAQ content, and includes the complete configured gallery. Select **Print / Save PDF**, or use:

- macOS: `Command + P`
- Windows/Linux: `Ctrl + P`

Choose **Save as PDF**, enable background graphics, and inspect page breaks, dark sections, image crops, and text contrast before saving. The route is marked `noindex` and is not part of the primary navigation.

Browser-local image replacements can appear in the PDF made from that browser. For a reproducible company PDF, first commit the approved files to `public/images`, rebuild, and print from the production preview.

## Buyer enquiry form

The form on `/contact` is an interface preview. Browser-required fields work, but the site does not yet send email, upload files, store enquiries, or notify ESHA Apparels.

Before using it as a live lead channel:

1. Connect an approved backend or trusted form service.
2. Add server-side validation, secure upload limits/types, spam protection, privacy information, and consent handling.
3. Show success only after the server confirms receipt.
4. Test successful delivery, validation errors, upload failures, and service outages.

Do not ask buyers to send confidential tech packs through the unconfigured form.

## SEO and sharing

Shared metadata is in `app/layout.tsx`; page-specific titles and descriptions are in each route’s `page.tsx`.

Current assets:

- Favicon: `public/favicon.svg`
- Open Graph image: `public/images/hero/esha-apparels-open-graph.jpg`
- Editable SEO reference data: `companyData.seo`

When the production domain is final, add the canonical URL, keep `companyData.seo` consistent with the route metadata, and test the public Open Graph image URL.

## Build and deploy

Create the server-backed Vinext build:

```bash
pnpm install --frozen-lockfile
pnpm typecheck
pnpm lint
pnpm build
```

Expected output:

```text
dist/
├── server/index.js
├── client/
└── .openai/hosting.json
```

`scripts/prepare-hosting.mjs` verifies `dist/server/index.js` and copies the existing Sites binding into the build. Do not deploy `dist/client` alone; the Vinext server runtime and client assets are both required.

Artifact checks:

```bash
test -f dist/server/index.js
test -d dist/client
test -f dist/.openai/hosting.json
cmp .openai/hosting.json dist/.openai/hosting.json
test -f dist/client/images/hero/hero-main.jpg
```

Run `pnpm preview` and test direct loading and refreshes for every route.

For Codex Sites:

1. Keep the opaque `project_id` in `.openai/hosting.json`.
2. Commit and push the exact source state being released.
3. Build or archive that exact commit.
4. Save a Sites version using the matching pushed commit SHA.
5. Deploy only the saved version.
6. Wait for terminal deployment status, then smoke-test the production URL.

A Sites URL is production. The hosting file binds this repository to its existing project but does not prove that the latest source has been deployed.

## Placeholder and asset audits

```bash
# Bracketed business-information placeholders
rg -n '\[[^][]+\]' src/data/companyData.ts

# Editorial markers
rg -n -i 'TODO|TBD|REPLACE ME|placeholder|example only' \
  src/data/companyData.ts app

# Removed category names must not return from active source
rg -n -i 'daywear|beach wear|resort wear' src/data/companyData.ts src/App.tsx app

# Local image and URL references
rg -n '(/images/|/favicon\.svg|https?://)' src app

# Source and built images
find public/images -type f | sort
find dist/client/images -type f | sort
```

Verify referenced image paths:

```bash
rg -o --no-filename '"/images/[^"]+"' \
  src/data/companyData.ts app/layout.tsx \
  | tr -d '"' \
  | sort -u \
  | while IFS= read -r path; do
      test -f "public$path" || echo "Missing: public$path"
    done

test -f public/favicon.svg
```

Review every result. Form hint text and clearly labelled verification fields may intentionally contain placeholder wording.

## Final QA checklist

- [ ] Node.js is 22.12 or newer and the lockfile installs with `pnpm install --frozen-lockfile`
- [ ] `pnpm typecheck`, `pnpm lint`, and `pnpm build` pass
- [ ] All 10 public routes and `/company-profile` load directly and after refresh
- [ ] Double-clicking root `index.html` opens locally without a sign-in or permission prompt
- [ ] Every companion static `.html` page opens from the offline navigation
- [ ] Desktop, tablet, and mobile navigation highlights the correct route
- [ ] Up to 250,000 pieces and 575 sewing machines appear consistently
- [ ] Daywear, Beach wear, and Resort wear are absent from active categories and filters
- [ ] All remaining bracketed facts are intentional and clearly labelled
- [ ] Factory, contact, compliance, certification, award, and export details are verified
- [ ] Every source image loads with useful alt text and without stretching or accidental duplication
- [ ] Clicking an editable image opens the file chooser
- [ ] JPG/JPEG, PNG, and WebP replacements display and persist after reload in the same browser/origin
- [ ] Unsupported image files are rejected with clear text
- [ ] **Remove** restores the bundled fallback and deletes the saved browser override
- [ ] Gallery filters, load-more, lightbox, and product enquiry links work
- [ ] FAQs work on `/contact` and expand fully on `/company-profile`
- [ ] The `/company-profile` print preview includes all intended content with readable page breaks and contrast
- [ ] The enquiry form remains clearly marked as a non-sending preview until its backend is configured
- [ ] Keyboard focus, reduced motion, colour contrast, and touch targets are usable
- [ ] Each page has an accurate title and description; favicon and Open Graph image load
- [ ] `dist/server/index.js`, `dist/client`, and `dist/.openai/hosting.json` exist and match the intended release
- [ ] The production deployment uses the exact pushed commit and passes a complete smoke test
