import {
  PageHeader,
  ProfileShell,
  SustainabilitySection,
} from '../../src/App'
import { companyData } from '../../src/data/companyData'

export default function SustainabilityPage() {
  return (
    <>
      <title>Sustainability | ESHA Apparels</title>
      <meta
        name="description"
        content="Responsible manufacturing awareness, material optimisation, efficiency and clearly verified sustainability initiatives."
      />
      <ProfileShell
        activePath="/sustainability"
        pageTitle="Sustainability"
        className="sustainability-page"
      >
        <PageHeader
          eyebrow="Responsible manufacturing"
          title="Practical Progress, Supported by Verified Information"
          introduction="ESHA Apparels approaches sustainability through responsible-manufacturing awareness, material options, production efficiency and evidence-led communication."
          image={companyData.pageBanners.sustainability}
          current="Sustainability"
        />
        <SustainabilitySection />
      </ProfileShell>
    </>
  )
}
