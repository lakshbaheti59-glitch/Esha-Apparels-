import {
  BuyerSegmentsSection,
  ClientAssociationsSection,
  CompanyIntroduction,
  PageHeader,
  PastPresentFutureSection,
  ProfileShell,
} from '../../src/App'
import { companyData } from '../../src/data/companyData'

export default function AboutPage() {
  return (
    <>
      <title>About ESHA Apparels | Company Profile</title>
      <meta
        name="description"
        content="Learn about ESHA Apparels, its women’s fashion focus, buyer support and scalable manufacturing model."
      />
      <ProfileShell activePath="/about" pageTitle="About Us">
        <PageHeader
          eyebrow="Company profile"
          title="Built for Fashion. Structured for Scale."
          introduction="Meet ESHA Apparels, understand how we support buyers, and see the commercial relationships our manufacturing model is designed to evaluate."
          image={companyData.pageBanners.about}
          current="About Us"
        />
        <CompanyIntroduction />
        <PastPresentFutureSection />
        <ClientAssociationsSection />
        <BuyerSegmentsSection />
      </ProfileShell>
    </>
  )
}
