import {
  FactorySection,
  PageHeader,
  ProfileShell,
} from '../../src/App'
import { companyData } from '../../src/data/companyData'

export default function FacilitiesPage() {
  return (
    <>
      <title>Manufacturing Facilities | ESHA Apparels</title>
      <meta
        name="description"
        content="Explore ESHA Apparels’ two-factory manufacturing infrastructure and editable factory information."
      />
      <ProfileShell
        activePath="/facilities"
        pageTitle="Manufacturing Facilities"
      >
        <PageHeader
          eyebrow="Manufacturing infrastructure"
          title="Two Factories. One Integrated Production System."
          introduction="Review ESHA Apparels’ two-factory infrastructure and clearly marked editable factory information."
          image={companyData.pageBanners.facilities}
          current="Manufacturing Facilities"
        />
        <FactorySection />
      </ProfileShell>
    </>
  )
}
