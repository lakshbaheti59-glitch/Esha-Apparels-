import {
  EventsSection,
  PageHeader,
  ProfileShell,
} from '../../src/App'
import { companyData } from '../../src/data/companyData'

export default function EventsPage() {
  return (
    <>
      <title>Events | ESHA Apparels</title>
      <meta
        name="description"
        content="Past events, recognition moments and upcoming event placeholders for ESHA Apparels buyer-facing activity."
      />
      <ProfileShell activePath="/events" pageTitle="Events">
        <PageHeader
          eyebrow="Events"
          title="Buyer-Facing Moments, Past and Future"
          introduction="Track ESHA Apparels’ completed events, recognition moments and upcoming trade fair, buyer meeting or sourcing opportunities."
          image={companyData.pageBanners.events}
          current="Events"
        />
        <EventsSection />
      </ProfileShell>
    </>
  )
}
