import { CompleteProfilePage } from '../../src/App'

export default function CompanyProfileDownloadPage() {
  return (
    <>
      <title>Complete Company Profile | ESHA Apparels</title>
      <meta name="robots" content="noindex" />
      <CompleteProfilePage />
    </>
  )
}
