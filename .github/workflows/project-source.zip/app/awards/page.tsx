import {
  AwardSection,
  PageHeader,
  ProfileShell,
} from '../../src/App'
import { companyData } from '../../src/data/companyData'

export default function AwardsPage() {
  return (
    <>
      <title>Awards and Achievements | ESHA Apparels</title>
      <meta
        name="description"
        content="Reliance Best Vendor Award 2022–23, Women’s Category – Garment Export."
      />
      <ProfileShell activePath="/awards" pageTitle="Awards and Achievements">
        <PageHeader
          eyebrow="Recognition"
          title="Awarded Performance in Women’s Garment Export"
          introduction="View ESHA Apparels’ Reliance Best Vendor recognition, supported by the award trophy, certificate and ceremony photograph."
          image={companyData.pageBanners.awards}
          current="Awards and Achievements"
        />
        <AwardSection />
      </ProfileShell>
    </>
  )
}
