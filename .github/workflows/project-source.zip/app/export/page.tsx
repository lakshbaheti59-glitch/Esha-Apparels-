import {
  ExportSection,
  PageHeader,
  ProfileShell,
} from '../../src/App'
import { companyData } from '../../src/data/companyData'

export default function ExportExperiencePage() {
  return (
    <>
      <title>Export Experience | ESHA Apparels</title>
      <meta
        name="description"
        content="Export-oriented buyer support, documentation coordination and confirmed experience with the Japanese market."
      />
      <ProfileShell
        activePath="/export"
        pageTitle="Export Experience"
        className="export-page"
      >
        <PageHeader
          eyebrow="International sourcing"
          title="Designed for International Sourcing Requirements"
          introduction="Understand ESHA Apparels’ export-oriented buyer support, documentation coordination and confirmed experience with the Japanese market."
          image={companyData.pageBanners.exportExperience}
          current="Export Experience"
        />
        <ExportSection />
      </ProfileShell>
    </>
  )
}
