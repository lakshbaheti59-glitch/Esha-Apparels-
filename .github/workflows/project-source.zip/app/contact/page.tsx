import {
  EnquirySection,
  FAQSection,
  PageHeader,
  ProfileShell,
} from '../../src/App'
import { companyData } from '../../src/data/companyData'

export default function ContactPage() {
  return (
    <>
      <title>Contact ESHA Apparels | Buyer Enquiry</title>
      <meta
        name="description"
        content="Share a product category, estimated quantity and buyer requirement with ESHA Apparels."
      />
      <ProfileShell activePath="/contact" pageTitle="Contact Us">
        <PageHeader
          eyebrow="Buyer enquiry"
          title="Let’s Evaluate Your Next Collection"
          introduction="Share your category, quantity and key product requirement so ESHA Apparels can evaluate the enquiry."
          image={companyData.pageBanners.contact}
          current="Contact Us"
        />
        <EnquirySection />
        <FAQSection />
      </ProfileShell>
    </>
  )
}
