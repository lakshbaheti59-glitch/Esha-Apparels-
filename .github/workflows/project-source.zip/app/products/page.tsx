import {
  MaterialsSection,
  PageHeader,
  ProductGallery,
  ProfileShell,
} from '../../src/App'
import { companyData } from '../../src/data/companyData'

export default function ProductsPage() {
  return (
    <>
      <title>Women’s Product Categories | ESHA Apparels</title>
      <meta
        name="description"
        content="Explore dresses, tops, tunics, co-ords, skirts, bottoms and value-added women’s western-wear categories."
      />
      <ProfileShell activePath="/products" pageTitle="Product Categories">
        <PageHeader
          eyebrow="Women’s western wear"
          title="Commercial Product Categories for Buyer Programmes"
          introduction="Explore the women’s product categories, fabric directions, value additions and editable selected-style gallery."
          image={companyData.pageBanners.products}
          current="Product Categories"
        />
        <MaterialsSection />
        <ProductGallery />
      </ProfileShell>
    </>
  )
}
