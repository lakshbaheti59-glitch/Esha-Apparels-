import type { ReactNode } from 'react'
import '../src/styles/global.css'

const organizationStructuredData = {
  '@context': 'https://schema.org',
  '@type': 'Organization',
  name: 'ESHA Apparels',
  description:
    'Women’s garment manufacturing and export company focused on western wear, fast-fashion garments and export-ready production.',
  email: 'lakshbaheti59@gmail.com',
  telephone: '+91-9214446669',
  address: {
    '@type': 'PostalAddress',
    streetAddress: 'G1-165, E.P.I.P, Garment Zone, Sitapura',
    addressLocality: 'Jaipur',
    addressCountry: 'IN',
  },
}

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <head>
        <title>ESHA Apparels | Company Profile</title>
        <meta
          name="description"
          content="ESHA Apparels — export-ready women’s western wear manufacturing, product development, quality control and scalable production."
        />
        <meta name="theme-color" content="#1F1F1D" />
        <meta name="robots" content="index, follow" />
        <meta name="format-detection" content="telephone=yes,email=yes,address=yes" />
        <meta
          property="og:title"
          content="ESHA Apparels | Women’s Fashion Manufacturing at Scale"
        />
        <meta
          property="og:description"
          content="Commercial, trend-focused and scalable women’s garment manufacturing for international buyers."
        />
        <meta property="og:type" content="website" />
        <meta
          property="og:image"
          content="/images/hero/esha-apparels-open-graph.jpg"
        />
        <meta name="twitter:card" content="summary_large_image" />
        <link rel="icon" href="/favicon.svg" type="image/svg+xml" />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify(organizationStructuredData),
          }}
        />
      </head>
      <body>{children}</body>
    </html>
  )
}
