import App from '../src/App'

export default function CompanyProfilePage() {
  return (
    <>
      <title>ESHA Apparels | Women’s Fashion Manufacturing at Scale</title>
      <meta
        name="description"
        content="Women’s western-wear manufacturing and export with two factories, 575 sewing machines and capacity of up to 250,000 pieces per month."
      />
      <App />
    </>
  )
}
