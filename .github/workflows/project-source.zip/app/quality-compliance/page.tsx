import {
  ComplianceSection,
  PageHeader,
  ProfileShell,
  QualitySection,
} from '../../src/App'
import { companyData } from '../../src/data/companyData'

export default function QualityCompliancePage() {
  return (
    <>
      <title>Quality and Compliance | ESHA Apparels</title>
      <meta
        name="description"
        content="Review ESHA Apparels’ structured quality checkpoints and evidence-led compliance information."
      />
      <ProfileShell
        activePath="/quality-compliance"
        pageTitle="Quality and Compliance"
        className="quality-compliance-page"
      >
        <PageHeader
          eyebrow="Controlled production"
          title="Quality Built into Every Stage"
          introduction="Review the production checkpoints, buyer-specific quality fields and clearly identified compliance-verification areas."
          image={companyData.pageBanners.qualityCompliance}
          current="Quality and Compliance"
        />
        <QualitySection />
        <ComplianceSection />
      </ProfileShell>
    </>
  )
}
